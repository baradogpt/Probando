from __future__ import annotations

import json
import re
from hashlib import sha1
from pathlib import Path
from typing import Any
from datetime import datetime, timezone
import unicodedata

import pandas as pd

from soccer_scraper.collectors.fbref import FBREF_COMPETITIONS
from soccer_scraper.collectors.fbref import FBrefCollector
from soccer_scraper.utils.io import ensure_dir, read_parquet_if_exists, write_csv, write_parquet
from soccer_scraper.utils.logging import get_logger


logger = get_logger(__name__)


def _norm_text(value: Any) -> str:
    s = str(value).strip().lower()
    s = s.replace("&", " and ")
    s = re.sub(r"[^a-z0-9]+", "_", s)
    return s.strip("_")


def _name_key(value: Any) -> str:
    s = unicodedata.normalize("NFKD", str(value).strip())
    s = "".join(ch for ch in s if not unicodedata.combining(ch))
    s = s.lower().replace("&", " and ")
    s = re.sub(r"[^a-z0-9]+", "_", s)
    key = s.strip("_")
    return {
        "deportivo_alaves": "alaves",
        "real_valladolid": "valladolid",
        "real_oviedo": "oviedo",
    }.get(key, key)


def _stable_id(*parts: Any) -> str:
    raw = "|".join(str(p) for p in parts)
    return f"fbref_{sha1(raw.encode('utf-8')).hexdigest()[:12]}"


def _team_id(name: Any) -> str:
    return _stable_id("team", name)


def _player_id(name: Any, team: Any = None) -> str:
    return _stable_id("player", team, name)


def _official_id(name: Any, role: Any = None) -> str:
    return _stable_id("official", role, name)


def _event_id(*parts: Any) -> str:
    return _stable_id("event", *parts)


def _normalize_columns(df: pd.DataFrame, source: str | None = None) -> pd.DataFrame:
    out = df.copy()
    cols: list[str] = []
    seen: set[str] = set()
    for col in out.columns:
        if isinstance(col, tuple):
            name = "_".join([_norm_text(c) for c in col if str(c) and not str(c).startswith("unnamed")])
        else:
            name = _norm_text(col)
        name = re.sub(r"_+", "_", name).strip("_") or "col"
        if source and name in seen:
            name = f"{source}__{name}"
        seen.add(name)
        cols.append(name)
    out.columns = cols
    return out


def _load(path: Path) -> pd.DataFrame | None:
    if not path.exists():
        return None
    df = read_parquet_if_exists(path)
    if df is None:
        return None
    return df


def _find_latest_file(root: Path, filename: str) -> Path | None:
    candidates = [p for p in root.rglob(filename) if p.is_file()]
    if not candidates:
        return None
    top_level = [p for p in candidates if not any(part.startswith("match_id=") for part in p.parts)]
    if top_level:
        candidates = top_level
    return max(candidates, key=lambda p: p.stat().st_mtime)


def _load_latest(root: Path, filename: str) -> pd.DataFrame | None:
    path = _find_latest_file(root, filename)
    if path is None:
        return None
    return _load(path)


def _load_all(root: Path, filename: str) -> pd.DataFrame:
    frames: list[pd.DataFrame] = []
    for path in sorted(root.rglob(filename)):
        df = _load(path)
        if df is not None and not df.empty:
            frames.append(df)
    if not frames:
        return pd.DataFrame()
    return pd.concat(frames, ignore_index=True, sort=False)


def _load_cached_fbref_extra_table(name: str) -> pd.DataFrame | None:
    html_path = Path("data/html/fbref/extra_pages") / f"{name}.html"
    if not html_path.exists():
        html_path = Path("data/cache/fbref_extra_pages") / f"{name}.html"
    if not html_path.exists():
        return None
    html = html_path.read_text(encoding="utf-8", errors="ignore")
    from bs4 import BeautifulSoup

    soup = BeautifulSoup(html, "html.parser")
    table = soup.find("table", id=re.compile(r"^stats_(?!squads).*"))
    if table is None:
        tables = soup.find_all("table")
        if not tables:
            return None
        table = tables[-1]
    try:
        df = pd.read_html(str(table))[0]
    except Exception:
        return None
    return _normalize_columns(df, source=name)


def _load_fbref_player_passing_extra() -> pd.DataFrame | None:
    html_path = Path("data/html/fbref/extra_pages/passing.html")
    if not html_path.exists():
        html_path = Path("data/cache/fbref_extra_pages/passing.html")
    if not html_path.exists():
        return None
    html = html_path.read_text(encoding="utf-8", errors="ignore")
    from bs4 import BeautifulSoup
    from io import StringIO

    soup = BeautifulSoup(html, "html.parser")
    table = soup.find("table", id="stats_passing")
    if table is None:
        return None
    try:
        df = pd.read_html(StringIO(str(table)))[0]
    except Exception:
        return None

    out = pd.DataFrame(
        {
            "player": df[('Unnamed: 1_level_0', 'Player')],
            "nation_raw": df[('Unnamed: 2_level_0', 'Nation')],
            "pos": df[('Unnamed: 3_level_0', 'Pos')],
            "team": df[('Unnamed: 4_level_0', 'Squad')],
            "age_raw": df[('Unnamed: 5_level_0', 'Age')],
            "born": df[('Unnamed: 6_level_0', 'Born')],
            "90s": df[('Unnamed: 7_level_0', '90s')],
            "passes_completed": df[('Total', 'Cmp')],
            "passes_attempted": df[('Total', 'Att')],
            "pass_cmp_pct": df[('Total', 'Cmp%')],
            "passes_total_dist": df[('Total', 'TotDist')],
            "passes_progressive_dist": df[('Total', 'PrgDist')],
            "short_passes_completed": df[('Short', 'Cmp')],
            "short_passes_attempted": df[('Short', 'Att')],
            "short_passes_cmp_pct": df[('Short', 'Cmp%')],
            "medium_passes_completed": df[('Medium', 'Cmp')],
            "medium_passes_attempted": df[('Medium', 'Att')],
            "medium_passes_cmp_pct": df[('Medium', 'Cmp%')],
            "long_passes_completed": df[('Long', 'Cmp')],
            "long_passes_attempted": df[('Long', 'Att')],
            "long_passes_cmp_pct": df[('Long', 'Cmp%')],
            "assists": df[('Unnamed: 22_level_0', 'Ast')],
            "xag": df[('Unnamed: 23_level_0', 'A-xAG')],
            "key_passes": df[('Unnamed: 24_level_0', 'KP')],
            "passes_into_final_third": df[('Unnamed: 25_level_0', '1/3')],
            "passes_into_penalty_area": df[('Unnamed: 26_level_0', 'PPA')],
            "crosses_into_penalty_area": df[('Unnamed: 27_level_0', 'CrsPA')],
        }
    )
    out = out[out["player"].astype(str).str.lower() != "player"].copy()
    out = out[out["team"].astype(str).str.lower() != "squad"].copy()
    out["player_id"] = out.apply(lambda r: _player_id(r.get("player"), r.get("team")), axis=1)
    out["team_id"] = out["team"].map(_team_id)
    out["source"] = "fbref"
    out["source_table"] = "stats_passing"
    out["parser_version"] = "1"
    return out


def _load_understat_tables(raw_dir: Path) -> dict[str, pd.DataFrame]:
    root = raw_dir / "understat"
    schedule = _load_latest(root, "schedule.parquet")
    if schedule is None:
        schedule = pd.DataFrame()
    player_season_stats = _load_latest(root, "player_season_stats.parquet")
    if player_season_stats is None:
        player_season_stats = pd.DataFrame()
    shot_events = _load_latest(root, "shot_events.parquet")
    if shot_events is None:
        shot_events = pd.DataFrame()
    return {
        "schedule": schedule,
        "team_match_stats": _load_all(root, "team_match_stats.parquet"),
        "player_match_stats": _load_all(root, "player_match_stats.parquet"),
        "lineups": _load_all(root, "lineups.parquet"),
        "player_season_stats": player_season_stats,
        "shot_events": shot_events,
    }


def _attach_understat_match_ids(df: pd.DataFrame, matches: pd.DataFrame) -> pd.DataFrame:
    if df.empty or matches.empty:
        return df
    out = df.copy()
    if "match_id" in out.columns and "understat_match_id" not in out.columns:
        out = out.rename(columns={"match_id": "understat_match_id"})
    required = {"date", "home_team", "away_team"}
    if not required.issubset(out.columns) or not required.issubset(matches.columns):
        return out

    left = out.copy()
    right = matches.loc[:, [c for c in ["match_id", "date", "home_team", "away_team", "league", "season", "home_team_id", "away_team_id", "home_score", "away_score"] if c in matches.columns]].copy()
    left["date_key"] = pd.to_datetime(left["date"], errors="coerce", format="mixed").dt.strftime("%Y-%m-%d")
    right["date_key"] = pd.to_datetime(right["date"], errors="coerce", format="mixed").dt.strftime("%Y-%m-%d")
    left["home_key"] = left["home_team"].map(_name_key)
    left["away_key"] = left["away_team"].map(_name_key)
    right["home_key"] = right["home_team"].map(_name_key)
    right["away_key"] = right["away_team"].map(_name_key)
    merged = left.merge(right, on=["date_key", "home_key", "away_key"], how="left", suffixes=("", "__match"))
    if "match_id__match" in merged.columns:
        merged["match_id"] = merged["match_id__match"].fillna(merged.get("match_id"))
        merged = merged.drop(columns=["match_id__match"])
    return merged.drop(columns=[c for c in ["date_key", "home_key", "away_key"] if c in merged.columns])


def _attach_whoscored_match_ids(df: pd.DataFrame, matches: pd.DataFrame) -> pd.DataFrame:
    if df.empty or matches.empty:
        return df
    out = df.copy()
    if "match_id" in out.columns and "whoscored_match_id" not in out.columns:
        out = out.rename(columns={"match_id": "whoscored_match_id"})
    required = {"match_date", "home_team", "away_team"}
    if not required.issubset(out.columns) or not {"date", "home_team", "away_team"}.issubset(matches.columns):
        return out
    left = out.copy()
    right = matches.loc[:, [c for c in ["match_id", "date", "home_team", "away_team", "league", "season", "home_team_id", "away_team_id", "home_score", "away_score"] if c in matches.columns]].copy()
    left["date_key"] = pd.to_datetime(left["match_date"], errors="coerce", format="mixed").dt.strftime("%Y-%m-%d")
    right["date_key"] = pd.to_datetime(right["date"], errors="coerce", format="mixed").dt.strftime("%Y-%m-%d")
    left["home_key"] = left["home_team"].map(_name_key)
    left["away_key"] = left["away_team"].map(_name_key)
    right["home_key"] = right["home_team"].map(_name_key)
    right["away_key"] = right["away_team"].map(_name_key)
    merged = left.merge(right, on=["date_key", "home_key", "away_key"], how="left", suffixes=("", "__match"))
    if "match_id__match" in merged.columns:
        merged["match_id"] = merged["match_id__match"].fillna(merged.get("match_id"))
        merged = merged.drop(columns=["match_id__match"])
    return merged.drop(columns=[c for c in ["date_key", "home_key", "away_key"] if c in merged.columns])


def _first_existing(paths: list[Path]) -> pd.DataFrame | None:
    for p in paths:
        df = _load(p)
        if df is not None and not df.empty:
            return df
    return None


def _parse_complex_metric(value: Any) -> dict[str, Any]:
    text = str(value).strip()
    out: dict[str, Any] = {"raw": value}
    m = re.search(r"^(\d+)\s+of\s+(\d+)", text)
    if m:
        out["made"] = int(m.group(1))
        out["attempts"] = int(m.group(2))
    pct = re.search(r"(\d+(?:\.\d+)?)%", text)
    if pct:
        out["pct"] = float(pct.group(1)) / 100.0
    return out


def _split_score(value: Any) -> tuple[Any, Any]:
    text = str(value)
    m = re.search(r"(\d+)\D+(\d+)", text)
    if not m:
        return None, None
    return int(m.group(1)), int(m.group(2))


def _parse_event_minute(text: str) -> dict[str, Any]:
    raw = text or ""
    m = re.search(r"(\d+)(?:\+(\d+))?", raw)
    minute = int(m.group(1)) if m else None
    extra = int(m.group(2)) if m and m.group(2) else 0
    stoppage = extra > 0
    period = None
    if minute is not None:
        if minute <= 45:
            period = 1
        elif minute <= 90:
            period = 2
        else:
            period = 3
    return {
        "minute": minute,
        "second": None,
        "period": period,
        "stoppage_time": stoppage,
    }


def _parse_scoreline(text: str) -> tuple[Any, Any]:
    m = re.search(r"(\d+)\s*[:\-]\s*(\d+)", text or "")
    if not m:
        return None, None
    return int(m.group(1)), int(m.group(2))


def _extract_balanced_object(text: str, anchor: str) -> str | None:
    start = text.find(anchor)
    if start == -1:
        return None
    brace_start = text.find("{", start)
    if brace_start == -1:
        return None
    depth = 0
    for idx in range(brace_start, len(text)):
        ch = text[idx]
        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                return text[brace_start : idx + 1]
    return None


def _parse_int_list(value: str | None) -> list[int]:
    if not value:
        return []
    return [int(x) for x in re.findall(r"\d+", value)]


def _formation_positions_es(formation: str) -> list[str]:
    f = re.sub(r"\D", "", formation or "")
    if not f:
        return []
    digits = [int(ch) for ch in f]
    if len(digits) == 3:
        d, m, a = digits
        defense = {
            2: ["Central derecho", "Central izquierdo"],
            3: ["Central derecho", "Central", "Central izquierdo"],
            4: ["Lateral derecho", "Central derecho", "Central izquierdo", "Lateral izquierdo"],
            5: ["Carrilero derecho", "Central derecho", "Central", "Central izquierdo", "Carrilero izquierdo"],
        }.get(d, ["Defensa"] * d)
        midfield = {
            1: ["Mediocentro"],
            2: ["Pivote derecho", "Pivote izquierdo"],
            3: ["Mediocentro derecho", "Mediocentro", "Mediocentro izquierdo"],
            4: ["Mediocentro derecho", "Mediocentro", "Mediocentro", "Mediocentro izquierdo"],
            5: ["Extremo derecho", "Mediocentro derecho", "Mediocentro", "Mediocentro izquierdo", "Extremo izquierdo"],
        }.get(m, ["Mediocentro"] * m)
        attack = {
            1: ["Delantero centro"],
            2: ["Delantero derecho", "Delantero izquierdo"],
            3: ["Delantero derecho", "Delantero centro", "Delantero izquierdo"],
        }.get(a, ["Delantero"] * a)
        return ["Portero"] + defense + midfield + attack
    if len(digits) == 4:
        d1, d2, d3, a = digits
        if d2 == 2 and d3 == 3 and a == 1:
            return ["Portero"] + ["Lateral derecho", "Central derecho", "Central izquierdo", "Lateral izquierdo"] + ["Pivote derecho", "Pivote izquierdo"] + ["Mediapunta derecho", "Mediapunta", "Mediapunta izquierdo"] + ["Delantero centro"]
        if d2 == 3 and d3 == 1 and a == 2:
            return ["Portero"] + ["Lateral derecho", "Central derecho", "Central izquierdo", "Lateral izquierdo"] + ["Mediocentro derecho", "Mediocentro", "Mediocentro izquierdo"] + ["Mediapunta"] + ["Delantero derecho", "Delantero izquierdo"]
        return ["Portero"] + ["Defensa"] * d1 + ["Mediocentro"] * (d2 + d3) + ["Delantero"] * a
    if len(digits) == 2:
        d, a = digits
        return ["Portero"] + ["Defensa"] * d + ["Ataque"] * a
    return ["Portero"] + ["Defensa"] * 4 + ["Mediocentro"] * 4 + ["Delantero"] * 2


def _parse_whoscored_match_meta(html: str, source_html_path: Path) -> pd.DataFrame:
    from bs4 import BeautifulSoup

    soup = BeautifulSoup(html, "html.parser")
    header_teams = soup.select("#match-centre-header .match-centre-header-team")
    if len(header_teams) < 2:
        return pd.DataFrame()

    home_team = header_teams[0].select_one(".team-name")
    away_team = header_teams[1].select_one(".team-name")
    home_formation = header_teams[0].select_one(".formation")
    away_formation = header_teams[1].select_one(".formation")

    data_anchor = _extract_balanced_object(html, "matchCentreData:")
    if data_anchor is None:
        return pd.DataFrame()

    try:
        match_data = json.loads(data_anchor)
    except Exception:
        return pd.DataFrame()

    start_date = pd.to_datetime(match_data.get("startDate"), errors="coerce")
    match_date = start_date.strftime("%Y-%m-%d") if not pd.isna(start_date) else None
    source_url = None
    url_match = re.search(r'https?://www\.whoscored\.com/matches/\d+/[^"\']+', html)
    if url_match:
        source_url = url_match.group(0)

    player_dict = {str(k): v for k, v in (match_data.get("playerIdNameDictionary") or {}).items()}
    rows: list[dict[str, Any]] = []
    for side, team_node, formation_node in [
        ("home", home_team, home_formation),
        ("away", away_team, away_formation),
    ]:
        team_name = team_node.get_text(" ", strip=True) if team_node is not None else None
        formation = formation_node.get_text(" ", strip=True) if formation_node is not None else None
        team_data = match_data.get(side) or {}
        formations = team_data.get("formations") or []
        formation_row = None
        if formations:
            formation_row = min(formations, key=lambda f: (int(f.get("startMinuteExpanded") or 10**9), int(f.get("period") or 10**9)))
        formation_name = str((formation_row or {}).get("formationName") or formation or "")
        player_ids = list((formation_row or {}).get("playerIds") or [])
        slots = list((formation_row or {}).get("formationSlots") or [])
        position_labels = _formation_positions_es(formation_name)

        for idx, player_id in enumerate(player_ids):
            player_name = player_dict.get(str(player_id))
            is_starter = bool(slots[idx]) if idx < len(slots) else idx < 11
            rows.append(
                {
                    "match_date": match_date,
                    "home_team": home_team.get_text(" ", strip=True) if home_team is not None else None,
                    "away_team": away_team.get_text(" ", strip=True) if away_team is not None else None,
                    "match_key": _name_key(match_date) + "|" + _name_key(home_team.get_text(" ", strip=True) if home_team is not None else "") + "|" + _name_key(away_team.get_text(" ", strip=True) if away_team is not None else ""),
                    "side": side,
                    "team": team_name,
                    "team_key": _name_key(team_name),
                    "player": player_name,
                    "player_key": _name_key(player_name),
                    "player_id_ws": player_id,
                    "formation": formation_name,
                    "lineup_order": idx,
                    "is_starter": is_starter,
                    "bench": not is_starter,
                    "called_up": True,
                    "played": is_starter,
                    "starting_position": position_labels[idx] if is_starter and idx < len(position_labels) else None,
                    "source": "whoscored",
                    "source_url": source_url,
                    "source_html_path": str(source_html_path),
                    "source_table": "match_centre_data",
                    "parser_version": "whoscored-1",
                }
            )

    return pd.DataFrame(rows)


def _load_whoscored_position_cache(root: Path) -> pd.DataFrame:
    if not root.exists():
        return pd.DataFrame()
    frames: list[pd.DataFrame] = []
    for html_path in sorted(root.glob("*.html")):
        try:
            html = html_path.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        df = _parse_whoscored_match_meta(html, html_path)
        if not df.empty:
            frames.append(df)
    if not frames:
        return pd.DataFrame()
    return pd.concat(frames, ignore_index=True, sort=False)


def _normalize_position_es(position: str | None) -> str | None:
    if position is None:
        return None
    p = str(position).upper()
    mapping = {
        "GK": "Portero",
        "RB": "Lateral derecho",
        "LB": "Lateral izquierdo",
        "CB": "Central",
        "RWB": "Carrilero derecho",
        "LWB": "Carrilero izquierdo",
        "DM": "Mediocentro defensivo",
        "CM": "Mediocentro",
        "AM": "Mediapunta",
        "RW": "Extremo derecho",
        "LW": "Extremo izquierdo",
        "FW": "Delantero",
        "SS": "Segundo delantero",
        "MF": "Mediocentro",
        "DF": "Defensa",
    }
    return mapping.get(p, str(position))


def _dedupe_first(df: pd.DataFrame, column: str) -> pd.DataFrame:
    if column not in df.columns:
        return df
    seen: set[str] = set()
    keep: list[bool] = []
    for value in df[column].astype(str).tolist():
        if value in seen:
            keep.append(False)
        else:
            seen.add(value)
            keep.append(True)
    return df.loc[keep].reset_index(drop=True)


def _is_missing_value(value: Any) -> bool:
    if value is None:
        return True
    if pd.isna(value):
        return True
    if isinstance(value, str) and not value.strip():
        return True
    return False


def _dedupe_coalesce(df: pd.DataFrame, keys: list[str]) -> pd.DataFrame:
    if df.empty:
        return df
    key_cols = [c for c in keys if c in df.columns]
    if not key_cols:
        return df.drop_duplicates().reset_index(drop=True)

    working = df.drop_duplicates().copy()

    def _first_valid(series: pd.Series) -> Any:
        for value in series.tolist():
            if not _is_missing_value(value):
                return value
        return None

    rows: list[dict[str, Any]] = []
    for _, group in working.groupby(key_cols, dropna=False, sort=False):
        row: dict[str, Any] = {}
        for col in working.columns:
            if col in key_cols:
                row[col] = group.iloc[0][col]
            else:
                row[col] = _first_valid(group[col])
        rows.append(row)

    out = pd.DataFrame(rows, columns=list(working.columns))
    return out.reset_index(drop=True)


def _merge_on_available(left: pd.DataFrame, right: pd.DataFrame, keys: list[str], suffix: str) -> pd.DataFrame:
    if left.empty or right.empty:
        return left
    common = [k for k in keys if k in left.columns and k in right.columns]
    if not common:
        return left
    overlap = [c for c in right.columns if c in left.columns and c not in common]
    right2 = right.copy()
    if overlap:
        right2.columns = [f"{suffix}__{c}" if c in overlap else c for c in right2.columns]
    return left.merge(right2, on=common, how="left")


def _build_match_table(raw_dir: Path, cached_fbref: dict[str, pd.DataFrame] | None = None) -> pd.DataFrame:
    fb_sched = _load_all(raw_dir / "fbref", "schedule_matches.parquet")
    fb_match = _load_latest(raw_dir / "fbref", "match_bundle.parquet")
    if fb_sched is not None and not fb_sched.empty:
        matches = fb_sched.copy()
        if "match_id" in matches.columns:
            matches["match_id"] = matches["match_id"].astype(str)
        if fb_match is not None and not fb_match.empty:
            fb_match = fb_match.copy()
            if "match_id" in fb_match.columns:
                fb_match["match_id"] = fb_match["match_id"].astype(str)
            if "match_report_url" in fb_match.columns and "match_report_url" in matches.columns:
                fb_match = fb_match.loc[~fb_match["match_report_url"].astype(str).duplicated()].reset_index(drop=True)
                matches = matches.merge(fb_match, on="match_report_url", how="left", suffixes=("", "__bundle"))
            elif "match_id" in fb_match.columns and "match_id" in matches.columns:
                fb_match = fb_match.loc[~fb_match["match_id"].astype(str).duplicated()].reset_index(drop=True)
                matches = matches.merge(fb_match, on="match_id", how="left", suffixes=("", "__bundle"))
    elif fb_match is not None and not fb_match.empty:
        matches = fb_match.copy()
    else:
        if cached_fbref is None and fb_sched is not None and not fb_sched.empty:
            cached_fbref = _parse_fbref_cached_match_pages(raw_dir, _normalize_columns(fb_sched, source="schedule_matches"))
        if cached_fbref and cached_fbref.get("match_bundle") is not None:
            matches = cached_fbref.get("match_bundle").copy()
        else:
            matches = pd.DataFrame()

    if cached_fbref and cached_fbref.get("match_bundle") is not None:
        cached_matches = cached_fbref.get("match_bundle").copy()
        if "match_id" in cached_matches.columns:
            cached_matches["match_id"] = cached_matches["match_id"].astype(str)
        matches = pd.concat([df for df in [matches, cached_matches] if df is not None and not df.empty], ignore_index=True, sort=False)

    understat = _load_latest(raw_dir / "understat", "schedule.parquet")
    if understat is not None and not understat.empty:
        us = understat.copy()
        us = _normalize_columns(us, source="understat")
        if "date" in us.columns:
            us["date"] = pd.to_datetime(us["date"], errors="coerce").dt.strftime("%Y-%m-%d")
        if "date" in matches.columns:
            matches["date"] = pd.to_datetime(matches["date"], errors="coerce").dt.strftime("%Y-%m-%d")
        for c in ["home_team", "away_team"]:
            if c in us.columns:
                us[c] = us[c].astype(str)
        if "date" in us.columns and "date" in matches.columns:
            if "home_xg" in us.columns:
                us["understat_home_xg"] = us["home_xg"]
            if "away_xg" in us.columns:
                us["understat_away_xg"] = us["away_xg"]
            matches = _merge_on_available(matches, us, ["date", "home_team", "away_team"], "understat")

    if "match_id" not in matches.columns and "match_report_url" in matches.columns:
        matches["match_id"] = matches["match_report_url"].map(lambda u: _stable_id(u))
    if "match_id" in matches.columns and "match_report_url" in matches.columns:
        missing_match_id = matches["match_id"].isna() | matches["match_id"].astype(str).str.lower().eq("nan")
        matches.loc[missing_match_id, "match_id"] = matches.loc[missing_match_id, "match_report_url"].map(
            lambda u: _stable_id(u) if not _is_missing_value(u) else None
        )

    if {"home", "away"}.issubset(matches.columns):
        header_mask = matches["home"].astype(str).str.strip().str.lower().eq("home") & matches["away"].astype(str).str.strip().str.lower().eq("away")
        matches = matches.loc[~header_mask].copy()
    if {"home_team", "away_team"}.issubset(matches.columns):
        header_mask = matches["home_team"].astype(str).str.strip().str.lower().eq("home") & matches["away_team"].astype(str).str.strip().str.lower().eq("away")
        matches = matches.loc[~header_mask].copy()
    if "match_report_url" in matches.columns:
        matches = matches.loc[matches["match_report_url"].notna()].copy()

    if "home_team" in matches.columns:
        matches["home_team_id"] = matches["home_team"].map(_team_id)
    if "away_team" in matches.columns:
        matches["away_team_id"] = matches["away_team"].map(_team_id)
    if "score" in matches.columns:
        scores = matches["score"].map(_split_score)
        matches["home_score"] = scores.map(lambda t: t[0])
        matches["away_score"] = scores.map(lambda t: t[1])
    meta = FBREF_COMPETITIONS.get(str(matches.iloc[0]["league"])) if not matches.empty and "league" in matches.columns else None
    if meta is not None:
        matches["competition_id"] = meta["comp_id"]

    if "source_url" not in matches.columns and "match_report_url" in matches.columns:
        matches["source_url"] = matches["match_report_url"]

    matches = _normalize_columns(matches, source="match")
    return _dedupe_coalesce(matches, ["match_id"])


def _parse_fbref_cached_match_pages(raw_dir: Path, matches: pd.DataFrame) -> dict[str, pd.DataFrame]:
    cache_root = Path("data/html/fbref")
    if not cache_root.exists():
        cache_root = Path("data/cache/fbref_html")
    if not cache_root.exists():
        return {}

    def _season_from_path(path: Path) -> str | None:
        parts = list(path.parts)
        for part in parts:
            if re.fullmatch(r"\d{4}-\d{4}", part):
                return part
        return None

    def _match_key(date: str | None, home: str | None, away: str | None) -> str:
        return f"{_name_key(date or '')}|{_name_key(home or '')}|{_name_key(away or '')}"

    schedule_lookup = pd.DataFrame()
    if not matches.empty:
        matches = matches.copy()
        if "date" in matches.columns:
            matches["date_key"] = pd.to_datetime(matches["date"], errors="coerce").dt.strftime("%Y-%m-%d")
        else:
            matches["date_key"] = None
        if "home_team" not in matches.columns and "home" in matches.columns:
            matches["home_team"] = matches["home"]
        if "away_team" not in matches.columns and "away" in matches.columns:
            matches["away_team"] = matches["away"]
        matches["match_key"] = matches.apply(lambda r: _match_key(r.get("date_key"), r.get("home_team"), r.get("away_team")), axis=1)
        schedule_lookup = matches.loc[:, [c for c in ["match_id", "match_key", "home_team", "away_team", "date", "season", "league", "match_report_url", "score"] if c in matches.columns]].copy()
        if "match_id" in schedule_lookup.columns:
            schedule_lookup = schedule_lookup.loc[~schedule_lookup["match_id"].duplicated()].reset_index(drop=True)

    parser = FBrefCollector(data_dir=raw_dir.parent, leagues=[], seasons=[], no_cache=True, no_store=True)
    match_rows: list[pd.DataFrame] = []
    team_rows: list[pd.DataFrame] = []
    player_rows: list[pd.DataFrame] = []
    keeper_rows: list[pd.DataFrame] = []
    lineup_rows: list[pd.DataFrame] = []
    official_rows: list[pd.DataFrame] = []

    for html_path in sorted(cache_root.rglob("match_*.html")):
        try:
            html = html_path.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        soup = None
        try:
            from bs4 import BeautifulSoup

            soup = BeautifulSoup(html, "html.parser")
        except Exception:
            soup = None
        if soup is None:
            continue

        title = soup.find("title").get_text(" ", strip=True) if soup.find("title") else ""
        title_match = re.search(r"^(.*?)\s+vs\.\s+(.*?)\s+Match Report", title)
        if not title_match:
            continue
        home_team = title_match.group(1).strip()
        away_team = title_match.group(2).strip()

        date_node = soup.find("span", class_="venuetime")
        match_date = date_node.get("data-venue-date") if date_node is not None else None
        match_key = _match_key(match_date, home_team, away_team)
        sched = schedule_lookup[schedule_lookup["match_key"].eq(match_key)] if not schedule_lookup.empty else pd.DataFrame()
        sched_row = sched.iloc[0] if not sched.empty else pd.Series(dtype=object)
        url_match = re.search(r'https?://www\.fbref\.com/en/matches/[^"\']+', html)
        source_url = url_match.group(0) if url_match else None
        match_report_url = str(sched_row.get("match_report_url") or source_url or "")
        match_id = str(sched_row.get("match_id") or (_stable_id(match_report_url) if match_report_url else _stable_id(str(html_path))))
        season = str(sched_row.get("season") or _season_from_path(html_path) or "")
        league = str(sched_row.get("league") or "ESP-La Liga")
        referee = parser._extract_referee_from_match_html(html)
        entities = parser._extract_match_entities(html, match_id, home_team, away_team)
        team_summary = parser._extract_team_summary(html, match_id, home_team, away_team)

        match_rows.append(
            pd.DataFrame(
                [
                    {
                        "match_id": match_id,
                        "league": league,
                        "season": season,
                        "match_report_url": match_report_url,
                        "home_team": home_team,
                        "away_team": away_team,
                        "referee": referee,
                        "source_schedule_referee": sched_row.get("Referee") if hasattr(sched_row, "index") and "Referee" in sched_row.index else None,
                        "source_html_path": str(html_path),
                        "team_summary_rows": 0 if team_summary.empty else len(team_summary),
                        "player_rows_x": 0 if entities["match_player_stats"].empty else len(entities["match_player_stats"]),
                        "keeper_rows_x": 0 if entities["match_keeper_stats"].empty else len(entities["match_keeper_stats"]),
                        "lineup_rows_x": 0 if entities["match_lineups"].empty else len(entities["match_lineups"]),
                    }
                ]
            )
        )
        if not team_summary.empty:
            team_rows.append(team_summary)
        if not entities["match_player_stats"].empty:
            player_rows.append(entities["match_player_stats"])
        if not entities["match_keeper_stats"].empty:
            keeper_rows.append(entities["match_keeper_stats"])
        if not entities["match_lineups"].empty:
            lineup_rows.append(entities["match_lineups"])
        if not entities["match_officials"].empty:
            official_rows.append(entities["match_officials"])

    out: dict[str, pd.DataFrame] = {}
    if match_rows:
        out["match_bundle"] = pd.concat(match_rows, ignore_index=True)
    if team_rows:
        out["match_team_summary"] = pd.concat(team_rows, ignore_index=True)
    if player_rows:
        out["match_player_stats"] = pd.concat(player_rows, ignore_index=True)
    if keeper_rows:
        out["match_keeper_stats"] = pd.concat(keeper_rows, ignore_index=True)
    if lineup_rows:
        out["match_lineups"] = pd.concat(lineup_rows, ignore_index=True)
    if official_rows:
        out["match_officials"] = pd.concat(official_rows, ignore_index=True)
    return out


def _build_team_match_table(raw_dir: Path, matches: pd.DataFrame, cached_fbref: dict[str, pd.DataFrame] | None = None) -> pd.DataFrame:
    fb_team_summary = _load_latest(raw_dir / "fbref", "match_team_summary.parquet")
    if cached_fbref is None and not matches.empty:
        cached_fbref = _parse_fbref_cached_match_pages(raw_dir, matches)
    cached_team_summary = cached_fbref.get("match_team_summary") if cached_fbref else None
    frames = [df for df in [fb_team_summary, cached_team_summary] if df is not None and not df.empty]
    if not frames:
        return pd.DataFrame()

    df = pd.concat(frames, ignore_index=True, sort=False)
    df = _normalize_columns(df, source="team_summary")
    out_rows: list[dict[str, Any]] = []
    for _, row in df.iterrows():
        metric = row.get("metric")
        home_team = row.get("home_team")
        away_team = row.get("away_team")
        match_id = row.get("match_id")
        out_rows.append({"match_id": match_id, "team_id": _team_id(home_team), "opponent_id": _team_id(away_team), "team": home_team, "opponent": away_team, "side": "home", "metric": metric, "value": row.get("home_value"), "source": "fbref"})
        out_rows.append({"match_id": match_id, "team_id": _team_id(away_team), "opponent_id": _team_id(home_team), "team": away_team, "opponent": home_team, "side": "away", "metric": metric, "value": row.get("away_value"), "source": "fbref"})

    out = pd.DataFrame(out_rows)
    if not matches.empty:
        keep_cols = [c for c in ["match_id", "league", "season", "home_team", "away_team", "referee", "match_report_url", "date", "time", "venue", "attendance", "score"] if c in matches.columns]
        match_lookup = matches.loc[:, keep_cols]
        if "match_id" in match_lookup.columns:
            match_lookup = match_lookup.loc[~match_lookup["match_id"].duplicated()].reset_index(drop=True)
        out = out.merge(match_lookup, on="match_id", how="left")
    if "value" in out.columns:
        parsed = out["value"].map(_parse_complex_metric)
        out["value_raw"] = out["value"]
        out["value_made"] = parsed.map(lambda d: d.get("made"))
        out["value_attempts"] = parsed.map(lambda d: d.get("attempts"))
        out["value_pct"] = parsed.map(lambda d: d.get("pct"))
    out = _normalize_columns(out, source="team_match")
    return _dedupe_coalesce(out, ["match_id", "side", "metric"])


def _build_player_tables(raw_dir: Path, matches: pd.DataFrame, cached_fbref: dict[str, pd.DataFrame] | None = None) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    player = _load_latest(raw_dir / "fbref", "match_player_stats.parquet")
    keeper = _load_latest(raw_dir / "fbref", "match_keeper_stats.parquet")
    lineup = _load_latest(raw_dir / "fbref", "match_lineups.parquet")
    officials = _load_latest(raw_dir / "fbref", "match_officials.parquet")
    cached = cached_fbref if cached_fbref is not None else (_parse_fbref_cached_match_pages(raw_dir, matches) if not matches.empty else {})
    if cached.get("match_player_stats") is not None and not cached.get("match_player_stats").empty:
        player = pd.concat([df for df in [player, cached.get("match_player_stats")] if df is not None and not df.empty], ignore_index=True, sort=False)
    if cached.get("match_keeper_stats") is not None and not cached.get("match_keeper_stats").empty:
        keeper = pd.concat([df for df in [keeper, cached.get("match_keeper_stats")] if df is not None and not df.empty], ignore_index=True, sort=False)
    if cached.get("match_lineups") is not None and not cached.get("match_lineups").empty:
        lineup = pd.concat([df for df in [lineup, cached.get("match_lineups")] if df is not None and not df.empty], ignore_index=True, sort=False)
    if cached.get("match_officials") is not None and not cached.get("match_officials").empty:
        officials = pd.concat([df for df in [officials, cached.get("match_officials")] if df is not None and not df.empty], ignore_index=True, sort=False)

    def _prep(df: pd.DataFrame | None, entity: str) -> pd.DataFrame:
        if df is None or df.empty:
            return pd.DataFrame()
        out = _normalize_columns(df, source=entity)
        if not matches.empty and "match_id" in out.columns:
            cols = [c for c in ["match_id", "league", "season", "home_team", "away_team", "referee", "match_report_url", "date", "score"] if c in matches.columns]
            match_lookup = matches.loc[:, cols]
            if "match_id" in match_lookup.columns:
                match_lookup = match_lookup.loc[~match_lookup["match_id"].duplicated()].reset_index(drop=True)
            out = out.merge(match_lookup, on="match_id", how="left")
        if "team" in out.columns:
            out["team_id"] = out["team"].map(_team_id)
        if "player" in out.columns:
            out["player_id"] = out.apply(lambda r: _player_id(r.get("player"), r.get("team")), axis=1)
        if entity == "officials" and "referee_name" in out.columns:
            out["official_id"] = out.apply(lambda r: _official_id(r.get("referee_name"), r.get("role")), axis=1)
        if entity == "lineup":
            out["is_starter"] = out.get("is_starter", False)
            out["is_substitute"] = out.get("is_substitute", False)
            out["bench"] = out.get("bench", False)
            out["called_up"] = out.get("called_up", False)
            out["played"] = out.get("played", False)
            out["minute_on"] = out.get("minute_on", None)
            out["minute_off"] = out.get("minute_off", None)
            out["position_start"] = out.get("position_start", None)
            if "lineup_side" not in out.columns and "side" in out.columns:
                out["lineup_side"] = out["side"]
        return out

    player_out = _dedupe_coalesce(_prep(player, "player"), ["match_id", "team_id", "player_id", "player"])
    keeper_out = _dedupe_coalesce(_prep(keeper, "keeper"), ["match_id", "team_id", "player_id", "player"])
    lineup_out = _dedupe_coalesce(_prep(lineup, "lineup"), ["match_id", "team_id", "player_id", "player", "side"])
    officials_out = _dedupe_coalesce(_prep(officials, "officials"), ["match_id", "official_id", "referee_name", "role"])
    return player_out, keeper_out, lineup_out, officials_out


def _build_events(raw_dir: Path, matches: pd.DataFrame, cached_fbref: dict[str, pd.DataFrame] | None = None) -> pd.DataFrame:
    fbref_bundle = _load_latest(raw_dir / "fbref", "match_bundle.parquet")
    fb_events: list[dict[str, Any]] = []
    if cached_fbref is None and not matches.empty:
        cached_fbref = _parse_fbref_cached_match_pages(raw_dir, matches)
    cached_bundle = cached_fbref.get("match_bundle") if cached_fbref else None
    if cached_bundle is not None and not cached_bundle.empty:
        fbref_bundle = pd.concat([df for df in [fbref_bundle, cached_bundle] if df is not None and not df.empty], ignore_index=True, sort=False)
    understat = _load_latest(raw_dir / "understat", "shot_events.parquet")
    whoscored = _load_latest(raw_dir / "whoscored", "events.parquet")
    frames: list[pd.DataFrame] = []
    match_lookup = pd.DataFrame()
    if not matches.empty and "match_id" in matches.columns:
        keep_cols = [c for c in ["match_id", "date", "home_team", "away_team", "home_team_id", "away_team_id", "home_score", "away_score"] if c in matches.columns]
        match_lookup = matches.loc[:, keep_cols].copy()
        match_lookup = match_lookup.loc[~match_lookup["match_id"].duplicated()].reset_index(drop=True)

    if fbref_bundle is not None and not fbref_bundle.empty and "source_html_path" in fbref_bundle.columns:
        for _, row in fbref_bundle.iterrows():
            html_path = Path(str(row.get("source_html_path", "")))
            if not html_path.exists():
                continue
            html = html_path.read_text(encoding="utf-8", errors="ignore")
            soup = None
            try:
                from bs4 import BeautifulSoup
                soup = BeautifulSoup(html, "html.parser")
            except Exception:
                soup = None
            if soup is None:
                continue
            match_id = str(row.get("match_id") or _stable_id(row.get("match_report_url")))
            lookup_row = match_lookup[match_lookup["match_id"].astype(str) == match_id]
            home_team = str(lookup_row.iloc[0]["home_team"]) if not lookup_row.empty and "home_team" in lookup_row.columns else str(row.get("home_team") or row.get("home") or "")
            away_team = str(lookup_row.iloc[0]["away_team"]) if not lookup_row.empty and "away_team" in lookup_row.columns else str(row.get("away_team") or row.get("away") or "")
            match_date = str(lookup_row.iloc[0]["date"]) if not lookup_row.empty and "date" in lookup_row.columns else str(row.get("date") or "")
            home_score = None
            away_score = None
            if not lookup_row.empty:
                home_score = lookup_row.iloc[0].get("home_score") if "home_score" in lookup_row.columns else None
                away_score = lookup_row.iloc[0].get("away_score") if "away_score" in lookup_row.columns else None
            soup_any: Any = soup
            event_blocks = soup_any.find_all("div", class_=re.compile(r"\bevent\s+[ab]\b"))
            for block in event_blocks:
                block_any: Any = block
                classes = block_any.get("class", [])
                side = "home" if isinstance(classes, list) and "a" in classes else "away"
                team = home_team if side == "home" else away_team
                children = [c for c in block_any.find_all("div", recursive=False)]
                if len(children) < 2:
                    continue
                minute_div: Any = children[0]
                detail_div: Any = children[1]
                minute_text = minute_div.get_text(" ", strip=True)
                detail_text = detail_div.get_text(" ", strip=True)
                text = f"{minute_text} {detail_text}".strip()
                minute_meta = _parse_event_minute(minute_text)

                icon = None
                icon_node = detail_div.find("div", class_=lambda c: c and "event_icon" in c)
                if icon_node is not None:
                    icon_classes = icon_node.get("class", [])
                    if isinstance(icon_classes, list):
                        for cls in icon_classes:
                            if cls != "event_icon":
                                icon = cls
                                break

                event_type = None
                if icon == "goal":
                    event_type = "goal"
                elif icon == "penalty_goal":
                    event_type = "penalty_goal"
                elif icon == "yellow_card":
                    event_type = "yellow_card"
                elif icon == "red_card":
                    event_type = "red_card"
                elif icon == "substitute_in":
                    event_type = "substitute_in"
                elif icon == "own_goal":
                    event_type = "own_goal"
                if event_type is None:
                    continue

                player_a = detail_div.find("a", href=re.compile(r"/en/players/"))
                player = player_a.get_text(" ", strip=True) if player_a else None

                assist_player_id = None
                for sm in detail_div.find_all("small"):
                    sm_text = sm.get_text(" ", strip=True)
                    if "assist" in sm_text.lower():
                        assist_a = sm.find("a", href=re.compile(r"/en/players/"))
                        if assist_a is not None:
                            assist_player = assist_a.get_text(" ", strip=True)
                            assist_player_id = _player_id(assist_player, team)
                        break

                related_player_id = None
                if event_type == "substitute_in":
                    for sm in detail_div.find_all("small"):
                        sm_text = sm.get_text(" ", strip=True)
                        if sm_text.lower().startswith("for"):
                            out_a = sm.find("a", href=re.compile(r"/en/players/"))
                            if out_a is not None:
                                out_player = out_a.get_text(" ", strip=True)
                                related_player_id = _player_id(out_player, team)
                            break

                score_div_text = minute_div.get_text(" ", strip=True)
                home_score_evt, away_score_evt = _parse_scoreline(score_div_text + " " + detail_text)
                score_after_event = f"{home_score_evt}:{away_score_evt}" if home_score_evt is not None and away_score_evt is not None else None

                fb_events.append(
                    {
                        "event_id": _event_id(match_id, side, team, player, minute_meta["minute"], event_type, text),
                        "match_id": match_id,
                        "competition_id": lookup_row.iloc[0].get("competition_id") if not lookup_row.empty and "competition_id" in lookup_row.columns else None,
                        "team_id": _team_id(team),
                        "opponent_id": _team_id(away_team if side == "home" else home_team),
                        "player_id": _player_id(player, team),
                        "source": "fbref",
                        "source_url": row.get("match_report_url"),
                        "side": side,
                        "team": team,
                        "player": player,
                        "minute": minute_meta["minute"],
                        "second": minute_meta["second"],
                        "period": minute_meta["period"],
                        "event_type": event_type,
                        "event_outcome": event_type,
                        "assist_player_id": assist_player_id,
                        "related_player_id": related_player_id,
                        "score_after_event": score_after_event,
                        "stoppage_time": minute_meta["stoppage_time"],
                        "home_score_after_event": home_score_evt if home_score_evt is not None else home_score,
                        "away_score_after_event": away_score_evt if away_score_evt is not None else away_score,
                        "raw_text": text,
                        "date": match_date,
                        "home_team": home_team,
                        "away_team": away_team,
                        "match_report_url": row.get("match_report_url"),
                    }
                )
    if 'fb_events' in locals() and fb_events:
        frames.append(pd.DataFrame(fb_events))

    if understat is not None and not understat.empty:
        us = _normalize_columns(understat, source="understat")
        if "date" in us.columns:
            us["date"] = pd.to_datetime(us["date"], errors="coerce").dt.strftime("%Y-%m-%d")
        if not matches.empty and {"date", "home_team", "away_team"}.issubset(matches.columns) and {"date", "home_team", "away_team"}.issubset(us.columns):
            match_lookup = matches.loc[:, ["match_id", "date", "home_team", "away_team"]]
            match_lookup = match_lookup.loc[~match_lookup["match_id"].duplicated()].reset_index(drop=True)
            us = us.merge(match_lookup, on=["date", "home_team", "away_team"], how="inner")
        if "match_id" not in us.columns and not matches.empty:
            us = pd.DataFrame()
        us["source"] = "understat"
        frames.append(us)
    if whoscored is not None and not whoscored.empty:
        ws = _normalize_columns(whoscored, source="whoscored")
        if "date" in ws.columns:
            ws["date"] = pd.to_datetime(ws["date"], errors="coerce").dt.strftime("%Y-%m-%d")
        if not matches.empty and {"date", "home_team", "away_team"}.issubset(matches.columns) and {"date", "home_team", "away_team"}.issubset(ws.columns):
            match_lookup = matches.loc[:, ["match_id", "date", "home_team", "away_team"]]
            match_lookup = match_lookup.loc[~match_lookup["match_id"].duplicated()].reset_index(drop=True)
            ws = ws.merge(match_lookup, on=["date", "home_team", "away_team"], how="inner")
        if "match_id" not in ws.columns and not matches.empty:
            ws = pd.DataFrame()
        ws["source"] = "whoscored"
        frames.append(ws)
    if not frames:
        return pd.DataFrame()
    events = pd.concat(frames, ignore_index=True, sort=False)
    return _dedupe_coalesce(events, ["event_id"])


def build_final_dataset(config: dict, output_name: str = "final_dataset") -> dict[str, Path]:
    project = config["project"]
    raw_dir = Path(project["data_dir"]) / "raw"
    curated_dir = ensure_dir(Path(project.get("final_dir", Path(project["data_dir"]) / "final")) / output_name)
    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")

    fbref_sched = _load_all(raw_dir / "fbref", "schedule_matches.parquet")
    cached_fbref = None
    if fbref_sched is not None and not fbref_sched.empty:
        cached_fbref = _parse_fbref_cached_match_pages(raw_dir, _normalize_columns(fbref_sched, source="schedule_matches"))
    matches = _build_match_table(raw_dir, cached_fbref)
    if matches.empty:
        if fbref_sched is not None and not fbref_sched.empty:
            parsed = cached_fbref or _parse_fbref_cached_match_pages(raw_dir, _normalize_columns(fbref_sched, source="schedule_matches"))
            if parsed:
                fbref_bundle = parsed.get("match_bundle", pd.DataFrame())
                if not fbref_bundle.empty:
                    matches = _normalize_columns(fbref_bundle, source="match")
    matches = _dedupe_coalesce(matches, ["match_id"])
    team_match = _build_team_match_table(raw_dir, matches, cached_fbref)
    player_stats, keeper_stats, lineups, officials = _build_player_tables(raw_dir, matches, cached_fbref)
    events = _build_events(raw_dir, matches, cached_fbref)

    def _coerce_match_id(df: pd.DataFrame) -> pd.DataFrame:
        if df.empty or "match_id" not in df.columns:
            return df
        out = df.copy()
        out["match_id"] = out["match_id"].astype(str)
        return out

    matches = _coerce_match_id(matches)
    team_match = _coerce_match_id(team_match)
    player_stats = _coerce_match_id(player_stats)
    keeper_stats = _coerce_match_id(keeper_stats)
    lineups = _coerce_match_id(lineups)
    officials = _coerce_match_id(officials)
    events = _coerce_match_id(events)
    if matches.empty:
        fbref_sched = _load_all(raw_dir / "fbref", "schedule_matches.parquet")
        if fbref_sched is not None and not fbref_sched.empty:
            parsed = _parse_fbref_cached_match_pages(raw_dir, _normalize_columns(fbref_sched, source="schedule_matches"))
            if parsed:
                if team_match.empty and parsed.get("match_team_summary") is not None:
                    team_match = parsed["match_team_summary"]
                if player_stats.empty and parsed.get("match_player_stats") is not None:
                    player_stats = parsed["match_player_stats"]
                if keeper_stats.empty and parsed.get("match_keeper_stats") is not None:
                    keeper_stats = parsed["match_keeper_stats"]
                if lineups.empty and parsed.get("match_lineups") is not None:
                    lineups = parsed["match_lineups"]
                if officials.empty and parsed.get("match_officials") is not None:
                    officials = parsed["match_officials"]
    fbref_passing_extra = _load_fbref_player_passing_extra()
    whoscored_player_stats = _load_latest(raw_dir / "whoscored", "match_player_stats.parquet")
    whoscored_team_stats = _load_latest(raw_dir / "whoscored", "match_team_stats.parquet")
    if whoscored_player_stats is None:
        whoscored_player_stats = pd.DataFrame()
    if whoscored_team_stats is None:
        whoscored_team_stats = pd.DataFrame()
    if not whoscored_player_stats.empty:
        whoscored_player_stats = _normalize_columns(whoscored_player_stats, source="whoscored")
        whoscored_player_stats = _attach_whoscored_match_ids(whoscored_player_stats, matches)
        if "player_name_ws" in whoscored_player_stats.columns and "player" not in whoscored_player_stats.columns:
            whoscored_player_stats["player"] = whoscored_player_stats["player_name_ws"]
    if not whoscored_team_stats.empty:
        whoscored_team_stats = _normalize_columns(whoscored_team_stats, source="whoscored")
        whoscored_team_stats = _attach_whoscored_match_ids(whoscored_team_stats, matches)
    elif not whoscored_player_stats.empty:
        fallback_cols = [c for c in ["match_id", "match_date", "home_team", "away_team", "league", "season", "team"] if c in whoscored_player_stats.columns]
        if fallback_cols:
            grouped = whoscored_player_stats.groupby(fallback_cols, dropna=False, as_index=False)
            whoscored_team_stats = grouped.agg(
                passes_completed=("passes_completed", "sum"),
                passes_attempted=("passes_attempted", "sum"),
                key_passes=("key_passes", "sum"),
                dribbles_completed=("dribbles_completed", "sum"),
                dribbles_attempted=("dribbles_attempted", "sum"),
                rating=("rating", "mean"),
            )

    def _whoscored_match_level(df: pd.DataFrame) -> pd.DataFrame:
        if df.empty or "match_id" not in df.columns or "side" not in df.columns:
            return pd.DataFrame()
        home = df.loc[df["side"].astype(str).str.lower().eq("home")].copy()
        away = df.loc[df["side"].astype(str).str.lower().eq("away")].copy()
        if home.empty or away.empty:
            return pd.DataFrame()
        home["match_id"] = home["match_id"].astype(str)
        away["match_id"] = away["match_id"].astype(str)
        keep_cols = [c for c in df.columns if c != "side"]
        home = home.loc[:, keep_cols].rename(columns={c: f"home_ws_{c}" for c in keep_cols if c != "match_id"})
        away = away.loc[:, keep_cols].rename(columns={c: f"away_ws_{c}" for c in keep_cols if c != "match_id"})
        merged = home.merge(away, on="match_id", how="inner", suffixes=("", ""))
        return merged

    def _understat_match_level(df: pd.DataFrame) -> pd.DataFrame:
        if df.empty or "match_id" not in df.columns or "side" not in df.columns:
            return pd.DataFrame()
        home = df.loc[df["side"].astype(str).str.lower().eq("home")].copy()
        away = df.loc[df["side"].astype(str).str.lower().eq("away")].copy()
        if home.empty or away.empty:
            return pd.DataFrame()
        home["match_id"] = home["match_id"].astype(str)
        away["match_id"] = away["match_id"].astype(str)

        metric_cols = [
            c
            for c in [
                "understat_match_id",
                "xg",
                "xga",
                "npxg",
                "npxga",
                "ppda_att",
                "ppda_def",
                "ppda_allowed_att",
                "ppda_allowed_def",
                "deep",
                "deep_allowed",
                "scored",
                "missed",
                "xpts",
                "result",
                "wins",
                "draws",
                "loses",
                "pts",
                "npxgd",
            ]
            if c in df.columns
        ]
        home = home.loc[:, ["match_id"] + metric_cols].rename(columns={c: f"understat_home_{c}" for c in metric_cols if c != "understat_match_id"})
        away = away.loc[:, ["match_id"] + [c for c in metric_cols if c != "understat_match_id"]].rename(
            columns={c: f"understat_away_{c}" for c in metric_cols if c != "understat_match_id"}
        )
        merged = home.merge(away, on="match_id", how="inner", suffixes=("", "__away"))
        if "understat_home_understat_match_id" in merged.columns:
            merged = merged.rename(columns={"understat_home_understat_match_id": "understat_match_id"})
        return merged

    whoscored_match_level = _whoscored_match_level(whoscored_team_stats)
    understat_tables = _load_understat_tables(raw_dir)
    understat_schedule = understat_tables["schedule"]
    if matches.empty and not understat_schedule.empty:
        matches = _normalize_columns(understat_schedule, source="match")

    understat_team_match = _attach_understat_match_ids(understat_tables["team_match_stats"], matches)
    understat_player_match = _attach_understat_match_ids(understat_tables["player_match_stats"], matches)
    understat_lineups = _attach_understat_match_ids(understat_tables["lineups"], matches)
    understat_shots = _attach_understat_match_ids(understat_tables["shot_events"], matches)
    understat_player_season = understat_tables["player_season_stats"]
    understat_match_level = _understat_match_level(understat_team_match)

    if not lineups.empty:
        lf = lineups.copy()
        if "match_id" in lf.columns and "team" in lf.columns:
            lf["_row_order"] = lf.groupby(["match_id", "team"]).cumcount()
            lf["is_starter"] = lf["_row_order"] < 11
            lf["bench"] = ~lf["is_starter"]
            lf["called_up"] = lf["player"].notna()
            lf["played"] = lf["is_starter"].fillna(False)
            lf["minute_on"] = lf.get("minute_on", None)
            lf["minute_off"] = lf.get("minute_off", None)
            if not events.empty and {"match_id", "player_id", "minute", "related_player_id", "event_type"}.issubset(events.columns):
                sub_in = events.loc[events["event_type"] == "substitute_in", ["match_id", "player_id", "minute"]].copy()
                sub_in.columns = ["match_id", "player_id", "minute_on_evt"]
                sub_out = events.loc[events["event_type"] == "substitute_in", ["match_id", "related_player_id", "minute"]].copy()
                sub_out.columns = ["match_id", "player_id", "minute_off_evt"]
                if not sub_in.empty:
                    lf = lf.merge(sub_in.drop_duplicates(), on=["match_id", "player_id"], how="left")
                    lf["minute_on"] = lf["minute_on"].fillna(lf["minute_on_evt"])
                    lf = lf.drop(columns=["minute_on_evt"])
                if not sub_out.empty:
                    lf = lf.merge(sub_out.drop_duplicates(), on=["match_id", "player_id"], how="left")
                    lf["minute_off"] = lf["minute_off"].fillna(lf["minute_off_evt"])
                    lf = lf.drop(columns=["minute_off_evt"])
        lineups = lf.drop(columns=["_row_order"])

    whoscored_positions = _load_whoscored_position_cache(Path(project["data_dir"]) / "html" / "whoscored" / "positions")
    if whoscored_positions.empty:
        whoscored_positions = _load_whoscored_position_cache(Path(project["data_dir"]) / "cache" / "whoscored_positions")
    if not lineups.empty and not whoscored_positions.empty:
        lineup_keys = lineups.copy()
        if "date" in lineup_keys.columns:
            lineup_keys["date_key"] = pd.to_datetime(lineup_keys["date"], errors="coerce").dt.strftime("%Y-%m-%d")
        else:
            lineup_keys["date_key"] = None
        lineup_keys["team_key"] = lineup_keys["team"].map(_name_key) if "team" in lineup_keys.columns else None
        lineup_keys["player_key"] = lineup_keys["player"].map(_name_key) if "player" in lineup_keys.columns else None
        if {"home_team", "away_team"}.issubset(lineup_keys.columns):
            lineup_keys["match_key"] = (
                lineup_keys["date_key"].fillna("").astype(str)
                + "|"
                + lineup_keys["home_team"].map(_name_key)
                + "|"
                + lineup_keys["away_team"].map(_name_key)
            )
        else:
            lineup_keys["match_key"] = None

        ws = whoscored_positions.copy()
        if "match_date" in ws.columns:
            ws["date_key"] = pd.to_datetime(ws["match_date"], errors="coerce").dt.strftime("%Y-%m-%d")
        ws["team_key"] = ws["team_key"] if "team_key" in ws.columns else ws["team"].map(_name_key)
        ws["player_key"] = ws["player_key"] if "player_key" in ws.columns else ws["player"].map(_name_key)
        ws["match_key"] = ws["match_key"] if "match_key" in ws.columns else (
            ws["date_key"].fillna("").astype(str)
            + "|"
            + ws["home_team"].map(_name_key)
            + "|"
            + ws["away_team"].map(_name_key)
        )

        ws_lookup = ws.loc[:, [c for c in ["match_key", "team_key", "player_key", "starting_position"] if c in ws.columns]].copy()
        ws_lookup = ws_lookup.rename(columns={"starting_position": "starting_position_ws"})
        lineup_keys = lineup_keys.merge(ws_lookup, on=["match_key", "team_key", "player_key"], how="left")
        if "starting_position_ws" in lineup_keys.columns:
            if "position_start" in lineup_keys.columns:
                lineup_keys["position_start"] = lineup_keys["position_start"].fillna(lineup_keys["starting_position_ws"])
            else:
                lineup_keys["position_start"] = lineup_keys["starting_position_ws"]
            lineup_keys["position_start_source"] = lineup_keys["starting_position_ws"].map(lambda v: "whoscored" if pd.notna(v) else None)
            lineup_keys = lineup_keys.drop(columns=["starting_position_ws"])
        lineups = lineup_keys.drop(columns=[c for c in ["date_key", "team_key", "player_key", "match_key"] if c in lineup_keys.columns])

    team_match = _dedupe_coalesce(team_match, ["match_id", "side", "metric"])
    player_stats = _dedupe_coalesce(player_stats, ["match_id", "team_id", "player_id", "player"])
    keeper_stats = _dedupe_coalesce(keeper_stats, ["match_id", "team_id", "player_id", "player"])
    lineups = _dedupe_coalesce(lineups, ["match_id", "team_id", "player_id", "player", "side"])
    officials = _dedupe_coalesce(officials, ["match_id", "official_id", "referee_name", "role"])
    events = _dedupe_coalesce(events, ["event_id"])

    # Canonical source tables used to build the final dataset.
    source_tables = {
        "matches": matches,
        "team_match_stats": team_match,
        "player_match_stats": player_stats,
        "keeper_match_stats": keeper_stats,
        "lineups": lineups,
        "officials": officials,
        "events": events,
        "whoscored_team_match_stats": whoscored_team_stats,
        "whoscored_player_match_stats": whoscored_player_stats,
        "understat_team_match_stats": understat_team_match,
        "understat_player_match_stats": understat_player_match,
        "understat_lineups": understat_lineups,
        "understat_shot_events": understat_shots,
        "understat_player_season_stats": understat_player_season,
    }
    if fbref_passing_extra is not None and not fbref_passing_extra.empty:
        source_tables["player_season_passing_extra"] = fbref_passing_extra.copy()

    clean_tables = {name: _normalize_columns(df, source=name) for name, df in source_tables.items()}

    def _team_metric_pivot(df: pd.DataFrame) -> pd.DataFrame:
        if df.empty or "match_id" not in df.columns or "side" not in df.columns or "metric" not in df.columns:
            return pd.DataFrame()
        pivot = df.pivot_table(index="match_id", columns=["side", "metric"], values="value_raw" if "value_raw" in df.columns else "value", aggfunc="first")
        pivot.columns = [f"{side}_{metric}" for side, metric in pivot.columns]
        return pivot.reset_index()

    wide = matches.copy()
    if not team_match.empty:
        wide = wide.merge(_team_metric_pivot(team_match), on="match_id", how="left")
    if not whoscored_match_level.empty:
        wide = wide.merge(whoscored_match_level, on="match_id", how="left")
    if not understat_match_level.empty:
        wide = wide.merge(understat_match_level, on="match_id", how="left", suffixes=("", "__understat"))
        for col in [c for c in understat_match_level.columns if c != "match_id"]:
            src_col = f"{col}__understat"
            if src_col in wide.columns:
                if col in wide.columns:
                    wide[col] = wide[col].combine_first(wide[src_col])
                    wide = wide.drop(columns=[src_col])
                else:
                    wide = wide.rename(columns={src_col: col})
    if not officials.empty and "match_id" in officials.columns:
        offici = officials[[c for c in officials.columns if c in {"match_id", "name", "role"}]].drop_duplicates()
        if "name" in offici.columns:
            offici = offici.assign(referee_name=offici["name"]).drop(columns=["name"])
        if "referee_name" in offici.columns:
            offici["official_id"] = offici.apply(lambda r: _official_id(r.get("referee_name"), r.get("role")), axis=1)
        wide = wide.merge(offici, on="match_id", how="left")
    if not player_stats.empty and "match_id" in player_stats.columns:
        player_counts = player_stats.groupby("match_id").size().to_frame(name="match_player_rows").reset_index()
        wide = wide.merge(player_counts, on="match_id", how="left")
    if not keeper_stats.empty and "match_id" in keeper_stats.columns:
        keeper_counts = keeper_stats.groupby("match_id").size().to_frame(name="match_keeper_rows").reset_index()
        wide = wide.merge(keeper_counts, on="match_id", how="left")
    if not lineups.empty and "match_id" in lineups.columns:
        lineup_counts = lineups.groupby("match_id").size().to_frame(name="match_lineup_rows").reset_index()
        wide = wide.merge(lineup_counts, on="match_id", how="left")
    if not events.empty and "match_id" in events.columns:
        event_counts = events.groupby("match_id").size().to_frame(name="match_event_rows").reset_index()
        wide = wide.merge(event_counts, on="match_id", how="left")

    if not lineups.empty:
        lineup_fix = lineups.copy()
        if "player" in lineup_fix.columns:
            lineup_fix["called_up"] = lineup_fix["player"].notna()
            if "is_starter" in lineup_fix.columns:
                lineup_fix["bench"] = ~lineup_fix["is_starter"].fillna(False)
            else:
                lineup_fix["bench"] = False
            if "minute_on" in lineup_fix.columns and "minute_off" in lineup_fix.columns:
                lineup_fix["played"] = lineup_fix["minute_on"].notna() | lineup_fix["is_starter"].fillna(False)
            else:
                lineup_fix["played"] = lineup_fix["is_starter"].fillna(False)
        lineups = lineup_fix
        source_tables["lineups"] = lineups
        clean_tables = {name: _normalize_columns(df, source=name) for name, df in source_tables.items()}

    wide["run_id"] = run_id
    wide["parser_version"] = "1"
    wide["parse_success"] = True
    wide["data_complete"] = True if not wide.empty else True

    write_parquet(wide, curated_dir / "match_wide.parquet")
    write_csv(wide, curated_dir / "match_wide.csv")
    if not wide.empty and "match_id" in wide.columns:
        for match_id, group in wide.groupby("match_id"):
            match_dir = ensure_dir(curated_dir / f"match_id={match_id}")
            write_parquet(group.reset_index(drop=True), match_dir / "match_wide.parquet")
            write_csv(group.reset_index(drop=True), match_dir / "match_wide.csv")

    # Curated dimensions and facts.
    dims_dir = ensure_dir(curated_dir / "dimensions")
    facts_dir = ensure_dir(curated_dir / "facts")
    teams_dim = pd.DataFrame()
    if not matches.empty:
        home = matches[[c for c in ["home_team", "home_team_id", "league", "season"] if c in matches.columns]].copy()
        away = matches[[c for c in ["away_team", "away_team_id", "league", "season"] if c in matches.columns]].copy()
        if "home_team" in home.columns:
            home.columns = ["team_name" if c == "home_team" else "team_id" if c == "home_team_id" else c for c in home.columns]
        if "away_team" in away.columns:
            away.columns = ["team_name" if c == "away_team" else "team_id" if c == "away_team_id" else c for c in away.columns]
        teams_dim = pd.DataFrame(pd.concat([home, away], ignore_index=True))
        teams_dim = _dedupe_first(teams_dim, "team_id")
        if not lineups.empty and "match_id" in lineups.columns and "player" in lineups.columns:
            lineup_lookup = lineups.loc[:, [c for c in ["match_id", "team", "team_id", "player", "player_id", "is_starter", "bench", "called_up", "played", "minute_on", "minute_off", "position_start", "lineup_side"] if c in lineups.columns]].copy()
            lineup_lookup = lineup_lookup.loc[~lineup_lookup[[c for c in ["match_id", "player_id"] if c in lineup_lookup.columns]].duplicated()].reset_index(drop=True)
    players_dim = pd.DataFrame()
    if not player_stats.empty and {"player_id", "player"}.issubset(player_stats.columns):
        cols = [c for c in ["player_id", "player", "team", "team_id", "match_id", "league", "season"] if c in player_stats.columns]
        players_dim = pd.DataFrame(player_stats.loc[:, cols])
        players_dim = _dedupe_first(players_dim, "player_id")
    if fbref_passing_extra is not None and not fbref_passing_extra.empty:
        extra_cols = [c for c in ["player_id", "team_id", "passes_completed", "passes_attempted", "pass_cmp_pct", "assists", "xag", "key_passes", "passes_into_final_third", "passes_into_penalty_area", "crosses_into_penalty_area"] if c in fbref_passing_extra.columns]
        pass_extra = fbref_passing_extra.loc[:, extra_cols].copy()
        pass_extra = pass_extra.rename(columns={"xag": "xag_proxy"})
        if players_dim.empty:
            players_dim = pass_extra
        else:
            players_dim = players_dim.merge(pass_extra, on=[c for c in ["player_id", "team_id"] if c in players_dim.columns and c in pass_extra.columns], how="left")
    officials_dim = pd.DataFrame()
    if not officials.empty and {"official_id", "referee_name"}.issubset(officials.columns):
        cols = [c for c in ["official_id", "referee_name", "role", "match_id", "league", "season"] if c in officials.columns]
        officials_dim = pd.DataFrame(officials.loc[:, cols])
        officials_dim = _dedupe_first(officials_dim, "official_id")
    write_parquet(teams_dim, dims_dir / "teams.parquet")
    write_csv(teams_dim, dims_dir / "teams.csv")
    write_parquet(players_dim, dims_dir / "players.parquet")
    write_csv(players_dim, dims_dir / "players.csv")
    write_parquet(officials_dim, dims_dir / "officials.parquet")
    write_csv(officials_dim, dims_dir / "officials.csv")

    fact_map = {
        "fact_team_match_stats": team_match,
        "fact_player_match_stats": player_stats,
        "fact_keeper_match_stats": keeper_stats,
        "fact_events": events,
        "fact_lineups": lineups,
    }
    if fbref_passing_extra is not None and not fbref_passing_extra.empty:
        fact_map["fact_player_season_passing_extra"] = fbref_passing_extra
    if not whoscored_player_stats.empty:
        fact_map["fact_whoscored_player_match_stats"] = whoscored_player_stats
    if not whoscored_team_stats.empty:
        fact_map["fact_whoscored_team_match_stats"] = whoscored_team_stats
    if not understat_team_match.empty:
        fact_map["fact_understat_team_match_stats"] = understat_team_match
    if not understat_player_match.empty:
        fact_map["fact_understat_player_match_stats"] = understat_player_match
    if not understat_lineups.empty:
        fact_map["fact_understat_lineups"] = understat_lineups
    if not understat_shots.empty:
        fact_map["fact_understat_shot_events"] = understat_shots
    if not understat_player_season.empty:
        fact_map["fact_understat_player_season_stats"] = understat_player_season
    for fname, df in fact_map.items():
        write_parquet(df, facts_dir / f"{fname}.parquet")
        write_csv(df, facts_dir / f"{fname}.csv")
        if not df.empty and "match_id" in df.columns:
            for match_id, group in df.groupby("match_id"):
                match_dir = ensure_dir(curated_dir / f"match_id={match_id}" / "facts")
                write_parquet(group.reset_index(drop=True), match_dir / f"{fname}.parquet")
                write_csv(group.reset_index(drop=True), match_dir / f"{fname}.csv")

    outputs = {
        "matches": curated_dir / "match_wide.parquet",
        "team_match_stats": curated_dir / "facts" / "fact_team_match_stats.parquet",
        "player_match_stats": curated_dir / "facts" / "fact_player_match_stats.parquet",
        "keeper_match_stats": curated_dir / "facts" / "fact_keeper_match_stats.parquet",
        "lineups": curated_dir / "facts" / "fact_lineups.parquet",
        "officials": curated_dir / "dimensions" / "officials.parquet",
        "events": curated_dir / "facts" / "fact_events.parquet",
        "whoscored_team_match_stats": curated_dir / "facts" / "fact_whoscored_team_match_stats.parquet",
        "whoscored_player_match_stats": curated_dir / "facts" / "fact_whoscored_player_match_stats.parquet",
        "understat_team_match_stats": curated_dir / "facts" / "fact_understat_team_match_stats.parquet",
        "understat_player_match_stats": curated_dir / "facts" / "fact_understat_player_match_stats.parquet",
        "understat_lineups": curated_dir / "facts" / "fact_understat_lineups.parquet",
        "understat_shot_events": curated_dir / "facts" / "fact_understat_shot_events.parquet",
        "understat_player_season_stats": curated_dir / "facts" / "fact_understat_player_season_stats.parquet",
        "teams_dim": dims_dir / "teams.parquet",
        "players_dim": dims_dir / "players.parquet",
        "officials_dim": dims_dir / "officials.parquet",
        "fact_team_match_stats": facts_dir / "fact_team_match_stats.parquet",
        "fact_player_match_stats": facts_dir / "fact_player_match_stats.parquet",
        "fact_keeper_match_stats": facts_dir / "fact_keeper_match_stats.parquet",
        "fact_events": facts_dir / "fact_events.parquet",
        "fact_whoscored_team_match_stats": facts_dir / "fact_whoscored_team_match_stats.parquet",
        "fact_whoscored_player_match_stats": facts_dir / "fact_whoscored_player_match_stats.parquet",
        "fact_lineups": facts_dir / "fact_lineups.parquet",
        "fact_understat_team_match_stats": facts_dir / "fact_understat_team_match_stats.parquet",
        "fact_understat_player_match_stats": facts_dir / "fact_understat_player_match_stats.parquet",
        "fact_understat_lineups": facts_dir / "fact_understat_lineups.parquet",
        "fact_understat_shot_events": facts_dir / "fact_understat_shot_events.parquet",
        "fact_understat_player_season_stats": facts_dir / "fact_understat_player_season_stats.parquet",
        "match_wide": curated_dir / "match_wide.parquet",
    }

    manifest_rows = []
    out_paths: dict[str, Path] = {}
    for name, path in outputs.items():
        out_paths[name] = path
        df = read_parquet_if_exists(path)
        manifest_rows.append({"artifact": name, "rows": 0 if df is None else len(df), "path": str(path)})

    manifest = pd.DataFrame(manifest_rows)
    write_parquet(manifest, curated_dir / "manifest.parquet")
    write_csv(manifest, curated_dir / "manifest.csv")
    out_paths["manifest"] = curated_dir / "manifest.parquet"

    logger.info("Dataset final creado en %s", curated_dir)
    return out_paths
