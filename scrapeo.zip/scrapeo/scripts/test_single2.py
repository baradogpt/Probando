import sys
from pathlib import Path
import os

import undetected_chromedriver as uc

# Absolute paths
BASE_DIR = Path(r"D:\Proyectos\soccer_scraper_project_b\data\html\whoscored\matches\2022-2023")

match_id = "1650596"
url = f"https://www.whoscored.com/matches/{match_id}/show/"

print(f"BASE_DIR: {BASE_DIR}")
print(f"BASE_DIR absolute: {BASE_DIR.absolute()}")

profile_dir = r"D:\Proyectos\soccer_scraper_sessions\whoscored_manual_visible_2022_2023"

print("Starting Chrome...")
options = uc.ChromeOptions()
options.add_argument(f"--user-data-dir={profile_dir}")

driver = uc.Chrome(options=options, version_main=146)

print(f"Getting {url}")
driver.get(url)

import time
time.sleep(5)

# Save show.html - use absolute path
match_dir = BASE_DIR / match_id
match_dir.mkdir(parents=True, exist_ok=True)

save_path = match_dir / "show.html"

print(f"Saving to absolute: {save_path.absolute()}")
html = driver.page_source
save_path.write_text(html, encoding="utf-8")

print(f"Saved! Size: {len(html)}")
print(f"File exists: {save_path.exists()}")
print(f"Full path: {save_path.absolute()}")

driver.quit()