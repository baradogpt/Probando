from __future__ import annotations

import gzip
import json
from hashlib import sha1
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

import pandas as pd

from soccer_scraper.collectors.base import BaseCollector


UNDERSTAT_LEAGUES = {
    "ENG-Premier League": "EPL",
    "ESP-La Liga": "La_liga",
    "ITA-Serie A": "Serie_A",
    "GER-Bundesliga": "Bundesliga",
    "FRA-Ligue 1": "Ligue_1",
    "RFPL": "RFPL",
}


def _stable_understat_id(kind: str, *parts: Any) -> str:
    raw = "|".join("" if p is None else str(p) for p in parts)
    return f"understat_{kind}_{sha1(raw.encode('utf-8')).hexdigest()[:12]}"


def _season_start(season: str | int) -> str:
    text = str(season).strip()
    if "-" in text:
        return text.split("-", 1)[0]
    return text


def _league_slug(league: str) -> str:
    return UNDERSTAT_LEAGUES.get(league, str(league).replace(" ", "_").replace("-", "_"))


def _to_frame(rows: list[dict[str, Any]]) -> pd.DataFrame:
    return pd.DataFrame(rows) if rows else pd.DataFrame()


def _safe_float(value: Any) -> float | None:
    try:
        if value is None:
            return None
        if pd.isna(value):
            return None
        return float(value)
    except Exception:
        return None


class UnderstatCollector(BaseCollector):
    def __init__(
        self,
        data_dir: str | Path,
        leagues: list[str],
        seasons: list[str | int],
        no_cache: bool = False,
        no_store: bool = False,
        max_matches_per_season: int | None = None,
    ) -> None:
        super().__init__(data_dir)
        self.leagues = leagues
        self.seasons = seasons
        self.no_cache = no_cache
        self.no_store = no_store
        self.max_matches_per_season = max_matches_per_season
        self.raw_root = Path(data_dir) / "html" / "understat"
        self.raw_root.mkdir(parents=True, exist_ok=True)

    def _save_raw_json(self, rel_path: str, payload: dict[str, Any]) -> None:
        path = self.raw_root / rel_path
        path.parent.mkdir(parents=True, exist_ok=True)
        try:
            path.write_text(json.dumps(payload, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
        except Exception:
            pass

    def _request_json(self, url: str, referer: str) -> dict[str, Any]:
        request = Request(
            url,
            headers={
                "User-Agent": "Mozilla/5.0",
                "Accept": "application/json, text/javascript, */*; q=0.01",
                "Accept-Encoding": "gzip, deflate",
                "X-Requested-With": "XMLHttpRequest",
                "Referer": referer,
            },
        )
        try:
            with urlopen(request, timeout=60) as response:
                raw = response.read()
                if response.headers.get("Content-Encoding", "").lower() == "gzip" or raw.startswith(b"\x1f\x8b"):
                    raw = gzip.decompress(raw)
                text = raw.decode("utf-8", errors="ignore")
                return json.loads(text)
        except (HTTPError, URLError, json.JSONDecodeError) as exc:
            raise RuntimeError(f"No pude leer Understat desde {url}: {exc}") from exc

    def _fetch_league_data(self, league: str, season: str | int) -> dict[str, Any]:
        slug = _league_slug(league)
        season_start = _season_start(season)
        url = f"https://understat.com/getLeagueData/{slug}/{season_start}"
        referer = f"https://understat.com/league/{slug}/{season_start}"
        return self._request_json(url, referer)

    def _fetch_match_data(self, match_id: str | int) -> dict[str, Any]:
        match_str = str(match_id)
        url = f"https://understat.com/getMatchData/{match_str}"
        referer = f"https://understat.com/match/{match_str}"
        return self._request_json(url, referer)

    def _build_schedule(self, league: str, season: str | int, payload: dict[str, Any]) -> pd.DataFrame:
        rows: list[dict[str, Any]] = []
        for item in payload.get("dates", []):
            home = item.get("h") or {}
            away = item.get("a") or {}
            goals = item.get("goals") or {}
            xg = item.get("xG") or {}
            forecast = item.get("forecast") or {}
            match_id = str(item.get("id"))
            rows.append(
                {
                    "match_id": _stable_understat_id("match", league, season, match_id),
                    "understat_match_id": match_id,
                    "league": league,
                    "season": str(season),
                    "home_team": home.get("title"),
                    "home_team_id": home.get("id"),
                    "away_team": away.get("title"),
                    "away_team_id": away.get("id"),
                    "home_short_title": home.get("short_title"),
                    "away_short_title": away.get("short_title"),
                    "match_datetime": item.get("datetime"),
                    "date": item.get("datetime"),
                    "is_result": item.get("isResult"),
                    "home_goals": goals.get("h"),
                    "away_goals": goals.get("a"),
                    "home_xg": xg.get("h"),
                    "away_xg": xg.get("a"),
                    "forecast_w": forecast.get("w"),
                    "forecast_d": forecast.get("d"),
                    "forecast_l": forecast.get("l"),
                    "source": "understat",
                    "source_url": f"https://understat.com/match/{match_id}",
                    "source_table": "schedule",
                    "parser_version": "understat-1",
                }
            )
        return _to_frame(rows)

    def _build_team_match_stats(self, league: str, season: str | int, payload: dict[str, Any], schedule: pd.DataFrame) -> pd.DataFrame:
        if schedule.empty:
            return pd.DataFrame()

        schedule_lookup = schedule.copy()
        schedule_lookup["match_datetime"] = pd.to_datetime(schedule_lookup["match_datetime"], errors="coerce")
        schedule_lookup["match_date_key"] = schedule_lookup["match_datetime"].dt.strftime("%Y-%m-%d %H:%M:%S")

        rows: list[dict[str, Any]] = []
        for team in payload.get("teams", {}).values():
            team_title = team.get("title")
            team_id = team.get("id")
            history = team.get("history", [])
            team_history = pd.DataFrame(history)
            if team_history.empty:
                continue
            team_history = team_history.copy()
            team_history["match_datetime"] = pd.to_datetime(team_history["date"], errors="coerce")
            team_history["match_date_key"] = team_history["match_datetime"].dt.strftime("%Y-%m-%d %H:%M:%S")
            team_history["side"] = team_history["h_a"].apply(lambda v: "home" if v == "h" else "away" if v == "a" else None)
            merged = team_history.merge(
                schedule_lookup[
                    [
                        "match_id",
                        "understat_match_id",
                        "home_team",
                        "away_team",
                        "home_team_id",
                        "away_team_id",
                        "match_date_key",
                        "league",
                        "season",
                    ]
                ],
                on="match_date_key",
                how="left",
            )
            for _, row in merged.iterrows():
                home_team = row.get("home_team")
                away_team = row.get("away_team")
                side = row.get("side")
                opponent = away_team if side == "home" else home_team
                opponent_id = row.get("away_team_id") if side == "home" else row.get("home_team_id")
                ppda = row.get("ppda") or {}
                ppda_allowed = row.get("ppda_allowed") or {}
                rows.append(
                    {
                        "match_id": row.get("match_id"),
                        "understat_match_id": row.get("understat_match_id"),
                        "home_team": home_team,
                        "away_team": away_team,
                        "home_team_id": row.get("home_team_id"),
                        "away_team_id": row.get("away_team_id"),
                        "team_id": _stable_understat_id("team", league, season, team_id),
                        "understat_team_id": team_id,
                        "team": team_title,
                        "opponent_id": _stable_understat_id("team", league, season, opponent_id),
                        "opponent": opponent,
                        "side": side,
                        "date": row.get("date"),
                        "league": league,
                        "season": str(season),
                        "h_a": row.get("h_a"),
                        "xg": row.get("xG"),
                        "xga": row.get("xGA"),
                        "npxg": row.get("npxG"),
                        "npxga": row.get("npxGA"),
                        "ppda_att": ppda.get("att"),
                        "ppda_def": ppda.get("def"),
                        "ppda_allowed_att": ppda_allowed.get("att"),
                        "ppda_allowed_def": ppda_allowed.get("def"),
                        "deep": row.get("deep"),
                        "deep_allowed": row.get("deep_allowed"),
                        "scored": row.get("scored"),
                        "missed": row.get("missed"),
                        "xpts": row.get("xpts"),
                        "result": row.get("result"),
                        "wins": row.get("wins"),
                        "draws": row.get("draws"),
                        "loses": row.get("loses"),
                        "pts": row.get("pts"),
                        "npxgd": row.get("npxGD"),
                        "source": "understat",
                        "source_url": f"https://understat.com/league/{_league_slug(league)}/{_season_start(season)}",
                        "source_table": "team_match_stats",
                        "parser_version": "understat-1",
                    }
                )

        return _to_frame(rows)

    def _build_player_season_stats(self, league: str, season: str | int, payload: dict[str, Any]) -> pd.DataFrame:
        rows: list[dict[str, Any]] = []
        for player in payload.get("players", []):
            rows.append(
                {
                    "player_id": _stable_understat_id("player", league, season, player.get("id")),
                    "understat_player_id": player.get("id"),
                    "player": player.get("player_name"),
                    "team": player.get("team_title"),
                    "team_id": _stable_understat_id("team", league, season, player.get("team_title")),
                    "league": league,
                    "season": str(season),
                    "games": player.get("games"),
                    "time": player.get("time"),
                    "goals": player.get("goals"),
                    "xg": player.get("xG"),
                    "assists": player.get("assists"),
                    "xa": player.get("xA"),
                    "shots": player.get("shots"),
                    "key_passes": player.get("key_passes"),
                    "yellow_cards": player.get("yellow_cards"),
                    "red_cards": player.get("red_cards"),
                    "position": player.get("position"),
                    "npg": player.get("npg"),
                    "npxg": player.get("npxG"),
                    "xgchain": player.get("xGChain"),
                    "xgbuildup": player.get("xGBuildup"),
                    "source": "understat",
                    "source_url": f"https://understat.com/league/{_league_slug(league)}/{_season_start(season)}",
                    "source_table": "player_season_stats",
                    "parser_version": "understat-1",
                }
            )
        return _to_frame(rows)

    def _build_player_match_stats(self, league: str, season: str | int, schedule_row: pd.Series, match_payload: dict[str, Any]) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        match_id = str(schedule_row.get("match_id"))
        understat_match_id = str(schedule_row.get("understat_match_id"))
        home_team = schedule_row.get("home_team")
        away_team = schedule_row.get("away_team")
        home_team_id = schedule_row.get("home_team_id")
        away_team_id = schedule_row.get("away_team_id")
        match_date = schedule_row.get("date")

        rosters = match_payload.get("rosters", {})
        shots = match_payload.get("shots", {})

        roster_rows: list[dict[str, Any]] = []
        lineup_rows: list[dict[str, Any]] = []
        shot_rows: list[dict[str, Any]] = []

        for side in ["h", "a"]:
            team = home_team if side == "h" else away_team
            opponent = away_team if side == "h" else home_team
            team_id = _stable_understat_id("team", league, season, home_team_id if side == "h" else away_team_id)
            opponent_id = _stable_understat_id("team", league, season, away_team_id if side == "h" else home_team_id)
            roster_list = list((rosters.get(side) or {}).values()) if isinstance(rosters.get(side), dict) else list(rosters.get(side) or [])
            for row in roster_list:
                position_order = row.get("positionOrder")
                position_order_value = _safe_float(position_order)
                is_starter = position_order_value is not None and int(position_order_value) <= 11
                time_value = _safe_float(row.get("time"))
                played = time_value is not None and time_value > 0
                roster_rows.append(
                    {
                        "match_id": match_id,
                        "understat_match_id": understat_match_id,
                        "home_team": home_team,
                        "away_team": away_team,
                        "home_team_id": home_team_id,
                        "away_team_id": away_team_id,
                        "team_id": team_id,
                        "understat_team_id": row.get("team_id"),
                        "team": team,
                        "opponent_id": opponent_id,
                        "opponent": opponent,
                        "side": "home" if side == "h" else "away",
                        "player_id": _stable_understat_id("player", league, season, row.get("player_id")),
                        "understat_player_id": row.get("player_id"),
                        "player": row.get("player"),
                        "position": row.get("position"),
                        "position_order": position_order,
                        "time": row.get("time"),
                        "goals": row.get("goals"),
                        "own_goals": row.get("own_goals"),
                        "shots": row.get("shots"),
                        "xg": row.get("xG"),
                        "yellow_card": row.get("yellow_card"),
                        "red_card": row.get("red_card"),
                        "key_passes": row.get("key_passes"),
                        "assists": row.get("assists"),
                        "xa": row.get("xA"),
                        "xgchain": row.get("xGChain"),
                        "xgbuildup": row.get("xGBuildup"),
                        "roster_in": row.get("roster_in"),
                        "roster_out": row.get("roster_out"),
                        "is_starter": is_starter,
                        "played": played,
                        "minute_on": None,
                        "minute_off": None,
                        "league": league,
                        "season": str(season),
                        "date": match_date,
                        "source": "understat",
                        "source_url": f"https://understat.com/match/{understat_match_id}",
                        "source_table": "player_match_stats",
                        "parser_version": "understat-1",
                    }
                )
                lineup_rows.append(
                    {
                        "match_id": match_id,
                        "understat_match_id": understat_match_id,
                        "home_team": home_team,
                        "away_team": away_team,
                        "home_team_id": home_team_id,
                        "away_team_id": away_team_id,
                        "team_id": team_id,
                        "understat_team_id": row.get("team_id"),
                        "team": team,
                        "opponent_id": opponent_id,
                        "opponent": opponent,
                        "side": "home" if side == "h" else "away",
                        "player_id": _stable_understat_id("player", league, season, row.get("player_id")),
                        "understat_player_id": row.get("player_id"),
                        "player": row.get("player"),
                        "position": row.get("position"),
                        "position_start": row.get("position"),
                        "position_order": position_order,
                        "is_starter": is_starter,
                        "bench": not is_starter,
                        "called_up": True,
                        "played": played,
                        "minute_on": None,
                        "minute_off": None,
                        "league": league,
                        "season": str(season),
                        "date": match_date,
                        "source": "understat",
                        "source_url": f"https://understat.com/match/{understat_match_id}",
                        "source_table": "lineups",
                        "parser_version": "understat-1",
                    }
                )

        for side in ["h", "a"]:
            team = home_team if side == "h" else away_team
            opponent = away_team if side == "h" else home_team
            team_id = _stable_understat_id("team", league, season, home_team_id if side == "h" else away_team_id)
            opponent_id = _stable_understat_id("team", league, season, away_team_id if side == "h" else home_team_id)
            shot_list = list(shots.get(side) or [])
            for shot in shot_list:
                result = shot.get("result")
                minute_raw = shot.get("minute")
                minute = None
                if minute_raw is not None:
                    try:
                        minute = int(str(minute_raw).split("+")[0])
                    except Exception:
                        minute = None
                player_name = shot.get("player")
                assist_name = shot.get("player_assisted")
                player_id = _stable_understat_id("player", league, season, shot.get("player_id"))
                assist_player_id = None
                if assist_name:
                    assist_row = next((r for r in roster_rows if r.get("match_id") == match_id and r.get("team") == team and r.get("player") == assist_name), None)
                    if assist_row is not None:
                        assist_player_id = assist_row.get("player_id")
                shot_rows.append(
                    {
                        "event_id": _stable_understat_id("event", match_id, side, shot.get("id"), minute, player_name),
                        "match_id": match_id,
                        "understat_match_id": understat_match_id,
                        "home_team": home_team,
                        "away_team": away_team,
                        "home_team_id": home_team_id,
                        "away_team_id": away_team_id,
                        "competition_id": _stable_understat_id("competition", league),
                        "team_id": team_id,
                        "understat_team_id": shot.get("team_id"),
                        "opponent_id": opponent_id,
                        "team": team,
                        "opponent": opponent,
                        "side": "home" if side == "h" else "away",
                        "player_id": player_id,
                        "understat_player_id": shot.get("player_id"),
                        "player": player_name,
                        "assist_player_id": assist_player_id,
                        "assist_player": assist_name,
                        "minute": minute,
                        "second": None,
                        "period": 1 if minute is not None and minute <= 45 else 2 if minute is not None and minute <= 90 else 3 if minute is not None else None,
                        "event_type": "shot",
                        "event_outcome": result,
                        "shot_type": shot.get("shotType"),
                        "situation": shot.get("situation"),
                        "last_action": shot.get("lastAction"),
                        "xg": shot.get("xG"),
                        "date": shot.get("date") or match_date,
                        "home_team": home_team,
                        "away_team": away_team,
                        "home_goals": shot.get("h_goals"),
                        "away_goals": shot.get("a_goals"),
                        "source": "understat",
                        "source_url": f"https://understat.com/match/{understat_match_id}",
                        "source_table": "shot_events",
                        "parser_version": "understat-1",
                    }
                )

        return _to_frame(roster_rows), _to_frame(lineup_rows), _to_frame(shot_rows)

    def collect(self, **kwargs: Any) -> dict[str, pd.DataFrame]:
        schedule_frames: list[pd.DataFrame] = []
        team_match_frames: list[pd.DataFrame] = []
        player_match_frames: list[pd.DataFrame] = []
        lineup_frames: list[pd.DataFrame] = []
        shot_frames: list[pd.DataFrame] = []
        player_season_frames: list[pd.DataFrame] = []

        for league in self.leagues:
            for season in self.seasons:
                self.logger.info("Leyendo Understat league data para %s %s", league, season)
                payload = self._fetch_league_data(league, season)
                self._save_raw_json(f"{league}/{season}/league.json", payload)
                schedule = self._build_schedule(league, season, payload)
                if not schedule.empty:
                    schedule_frames.append(schedule)
                team_match = self._build_team_match_stats(league, season, payload, schedule)
                if not team_match.empty:
                    team_match_frames.append(team_match)
                player_season = self._build_player_season_stats(league, season, payload)
                if not player_season.empty:
                    player_season_frames.append(player_season)

                processed_matches = 0
                for _, sched_row in schedule.iterrows():
                    if self.max_matches_per_season is not None and processed_matches >= self.max_matches_per_season:
                        break
                    understat_match_id = sched_row.get("understat_match_id")
                    if understat_match_id is None:
                        continue
                    try:
                        self.logger.info("Leyendo Understat match data %s", understat_match_id)
                        match_payload = self._fetch_match_data(understat_match_id)
                        self._save_raw_json(f"{league}/{season}/matches/{understat_match_id}.json", match_payload)
                        player_match, lineup, shots = self._build_player_match_stats(league, season, sched_row, match_payload)
                        if not player_match.empty:
                            player_match_frames.append(player_match)
                        if not lineup.empty:
                            lineup_frames.append(lineup)
                        if not shots.empty:
                            shot_frames.append(shots)
                        processed_matches += 1
                    except Exception as exc:
                        self.logger.warning("No pude leer el partido Understat %s: %s", understat_match_id, exc)

        return {
            "schedule": pd.concat(schedule_frames, ignore_index=True, sort=False) if schedule_frames else pd.DataFrame(),
            "team_match_stats": pd.concat(team_match_frames, ignore_index=True, sort=False) if team_match_frames else pd.DataFrame(),
            "player_match_stats": pd.concat(player_match_frames, ignore_index=True, sort=False) if player_match_frames else pd.DataFrame(),
            "lineups": pd.concat(lineup_frames, ignore_index=True, sort=False) if lineup_frames else pd.DataFrame(),
            "player_season_stats": pd.concat(player_season_frames, ignore_index=True, sort=False) if player_season_frames else pd.DataFrame(),
            "shot_events": pd.concat(shot_frames, ignore_index=True, sort=False) if shot_frames else pd.DataFrame(),
        }
