from __future__ import annotations

import numpy as np
import pandas as pd


def _safe_to_datetime(df: pd.DataFrame, column: str) -> pd.Series:
    return pd.to_datetime(df[column], utc=True, errors="coerce")


def _pick_col(df: pd.DataFrame, candidates: list[str]) -> str | None:
    for c in candidates:
        if c in df.columns:
            return c
    return None


def build_match_features(
    matches: pd.DataFrame,
    team_match_stats: pd.DataFrame | None = None,
    shot_events: pd.DataFrame | None = None,
    missing_players: pd.DataFrame | None = None,
    elo_df: pd.DataFrame | None = None,
    rolling_window: int = 5,
    congestion_window_days: int = 14,
    draw_elo_threshold: float = 35.0,
    low_total_goals_threshold: float = 2.35,
) -> pd.DataFrame:
    """
    Construye un dataset orientado a modelado 1X2 / draw.

    La idea es ser robusto ante diferencias de columnas entre fuentes.
    """
    df = matches.copy()

    date_col = _pick_col(df, ["date", "game_date", "kickoff", "datetime", "start_time"])
    home_col = _pick_col(df, ["home_team", "team_home", "home"])
    away_col = _pick_col(df, ["away_team", "team_away", "away"])
    hg_col = _pick_col(df, ["home_goals", "gf_home", "score_home", "home_score"])
    ag_col = _pick_col(df, ["away_goals", "gf_away", "score_away", "away_score"])
    league_col = _pick_col(df, ["league", "competition"])

    if date_col is None or home_col is None or away_col is None:
        raise ValueError("No encuentro columnas mínimas de partido para construir features.")

    df["match_date"] = _safe_to_datetime(df, date_col)
    df["home_team"] = df[home_col].astype(str)
    df["away_team"] = df[away_col].astype(str)

    if hg_col and ag_col:
        df["home_goals"] = pd.to_numeric(df[hg_col], errors="coerce")
        df["away_goals"] = pd.to_numeric(df[ag_col], errors="coerce")
        df["goal_diff"] = df["home_goals"] - df["away_goals"]
        df["total_goals"] = df["home_goals"] + df["away_goals"]
        df["target"] = np.select(
            [df["home_goals"] > df["away_goals"], df["home_goals"] == df["away_goals"]],
            ["1", "X"],
            default="2",
        )

    if league_col:
        df["league"] = df[league_col].astype(str)
    else:
        df["league"] = "unknown"

    # Base largo por equipo para rolling features.
    long_rows = []
    if hg_col and ag_col:
        home_rows = df[["match_date", "league", "home_team", "away_team", "home_goals", "away_goals"]].copy()
        home_rows.columns = ["match_date", "league", "team", "opponent", "goals_for", "goals_against"]
        home_rows["is_home"] = 1

        away_rows = df[["match_date", "league", "away_team", "home_team", "away_goals", "home_goals"]].copy()
        away_rows.columns = ["match_date", "league", "team", "opponent", "goals_for", "goals_against"]
        away_rows["is_home"] = 0

        long_rows = [home_rows, away_rows]

    team_long = pd.concat(long_rows, ignore_index=True) if long_rows else pd.DataFrame()

    if not team_long.empty:
        team_long = team_long.sort_values(["team", "match_date"]).reset_index(drop=True)
        team_long["points"] = np.select(
            [team_long["goals_for"] > team_long["goals_against"], team_long["goals_for"] == team_long["goals_against"]],
            [3, 1],
            default=0,
        )
        team_long["goal_diff"] = team_long["goals_for"] - team_long["goals_against"]
        team_long["prev_match_date"] = team_long.groupby("team")["match_date"].shift(1)
        team_long["rest_days"] = (team_long["match_date"] - team_long["prev_match_date"]).dt.days

        def _roll(group: pd.DataFrame) -> pd.DataFrame:
            g = group.copy()
            g["points_last_n"] = g["points"].shift(1).rolling(rolling_window, min_periods=1).sum()
            g["goal_diff_last_n"] = g["goal_diff"].shift(1).rolling(rolling_window, min_periods=1).sum()
            g["goals_for_last_n"] = g["goals_for"].shift(1).rolling(rolling_window, min_periods=1).sum()
            g["goals_against_last_n"] = g["goals_against"].shift(1).rolling(rolling_window, min_periods=1).sum()
            return g

        team_long = team_long.groupby("team", group_keys=False).apply(_roll)

        # Congestión: nº partidos previos en ventana fija
        counts = []
        if "team" not in team_long.columns:
            team_long["team"] = "unknown"
        for team, g in team_long.groupby("team"):
            dates = g["match_date"].tolist()
            vals = []
            for i, d in enumerate(dates):
                lower = d - pd.Timedelta(days=congestion_window_days)
                vals.append(sum(1 for prev in dates[:i] if pd.notna(prev) and prev >= lower))
            g = g.copy()
            g["fixture_congestion"] = vals
            counts.append(g)
        team_long = pd.concat(counts, ignore_index=True)

        # Merge home/away rolling features
        home_feats = team_long[[
            "match_date", "team", "rest_days", "points_last_n", "goal_diff_last_n",
            "goals_for_last_n", "goals_against_last_n", "fixture_congestion"
        ]].copy()
        home_feats.columns = [
            "match_date", "home_team", "home_rest_days", "home_points_last_n", "home_goal_diff_last_n",
            "home_goals_for_last_n", "home_goals_against_last_n", "fixture_congestion_home"
        ]
        away_feats = team_long[[
            "match_date", "team", "rest_days", "points_last_n", "goal_diff_last_n",
            "goals_for_last_n", "goals_against_last_n", "fixture_congestion"
        ]].copy()
        away_feats.columns = [
            "match_date", "away_team", "away_rest_days", "away_points_last_n", "away_goal_diff_last_n",
            "away_goals_for_last_n", "away_goals_against_last_n", "fixture_congestion_away"
        ]

        df = df.merge(home_feats, on=["match_date", "home_team"], how="left")
        df = df.merge(away_feats, on=["match_date", "away_team"], how="left")

    # Missing players
    if missing_players is not None and not missing_players.empty:
        mp = missing_players.copy()
        mp_date = _pick_col(mp, ["date", "match_date", "game_date"])
        mp_team = _pick_col(mp, ["team", "team_name"])
        match_home = _pick_col(mp, ["home_team", "team_home"])
        match_away = _pick_col(mp, ["away_team", "team_away"])

        if mp_date and mp_team:
            mp["match_date"] = _safe_to_datetime(mp, mp_date)
            mp["team"] = mp[mp_team].astype(str)
            agg = mp.groupby(["match_date", "team"]).size().reset_index(name="missing_players_count")

            df = df.merge(
                agg.rename(columns={"team": "home_team", "missing_players_count": "missing_players_count_home"}),
                on=["match_date", "home_team"],
                how="left",
            )
            df = df.merge(
                agg.rename(columns={"team": "away_team", "missing_players_count": "missing_players_count_away"}),
                on=["match_date", "away_team"],
                how="left",
            )
        elif mp_date and match_home and match_away:
            mp["match_date"] = _safe_to_datetime(mp, mp_date)
            agg = mp.groupby(["match_date", match_home, match_away]).size().reset_index(name="missing_players_count_total")
            agg = agg.rename(columns={match_home: "home_team", match_away: "away_team"})
            df = df.merge(agg, on=["match_date", "home_team", "away_team"], how="left")

    # ELO
    if elo_df is not None and not elo_df.empty:
        elo = elo_df.copy()
        elo_team_col = _pick_col(elo, ["team", "club", "name"])
        elo_val_col = _pick_col(elo, ["elo", "rating"])
        if elo_team_col and elo_val_col:
            elo["team"] = elo[elo_team_col].astype(str)
            elo["elo"] = pd.to_numeric(elo[elo_val_col], errors="coerce")
            elo_simple = elo[["team", "elo"]].dropna().drop_duplicates(subset=["team"])
            df = df.merge(elo_simple.rename(columns={"team": "home_team", "elo": "home_elo"}), on="home_team", how="left")
            df = df.merge(elo_simple.rename(columns={"team": "away_team", "elo": "away_elo"}), on="away_team", how="left")
            df["elo_diff"] = df["home_elo"] - df["away_elo"]

    # xG y mispricing a partir de shot events si están disponibles
    if shot_events is not None and not shot_events.empty:
        se = shot_events.copy()
        se_team_col = _pick_col(se, ["team", "team_name"])
        se_date_col = _pick_col(se, ["date", "match_date", "game_date"])
        se_xg_col = _pick_col(se, ["xg", "xG"])
        if se_team_col and se_date_col and se_xg_col:
            se["team"] = se[se_team_col].astype(str)
            se["match_date"] = _safe_to_datetime(se, se_date_col)
            se["xg"] = pd.to_numeric(se[se_xg_col], errors="coerce")
            xg_game = se.groupby(["match_date", "team"], as_index=False)["xg"].sum()
            xg_game = xg_game.sort_values(["team", "match_date"])
            xg_game["xg_last_n"] = xg_game.groupby("team")["xg"].shift(1).rolling(rolling_window, min_periods=1).sum().reset_index(level=0, drop=True)

            df = df.merge(
                xg_game[["match_date", "team", "xg_last_n"]].rename(columns={"team": "home_team", "xg_last_n": "home_xg_last_n"}),
                on=["match_date", "home_team"],
                how="left",
            )
            df = df.merge(
                xg_game[["match_date", "team", "xg_last_n"]].rename(columns={"team": "away_team", "xg_last_n": "away_xg_last_n"}),
                on=["match_date", "away_team"],
                how="left",
            )
            df["xg_diff_last_n"] = df["home_xg_last_n"] - df["away_xg_last_n"]

    # Features de draw spot / mispricing
    if "elo_diff" in df.columns:
        df["abs_elo_diff"] = df["elo_diff"].abs()
        df["draw_elo_close_flag"] = (df["abs_elo_diff"] <= draw_elo_threshold).astype("Int64")

    if {"home_goals_for_last_n", "home_goals_against_last_n", "away_goals_for_last_n", "away_goals_against_last_n"}.issubset(df.columns):
        df["expected_total_proxy"] = (
            df["home_goals_for_last_n"].fillna(0)
            + df["home_goals_against_last_n"].fillna(0)
            + df["away_goals_for_last_n"].fillna(0)
            + df["away_goals_against_last_n"].fillna(0)
        ) / max(rolling_window * 2, 1)
        df["low_total_goals_flag"] = (df["expected_total_proxy"] <= low_total_goals_threshold).astype("Int64")

    if {"draw_elo_close_flag", "low_total_goals_flag"}.issubset(df.columns):
        df["draw_spot_flag"] = ((df["draw_elo_close_flag"] == 1) & (df["low_total_goals_flag"] == 1)).astype("Int64")

    # Diferencias home-away para el modelo
    pairs = [
        ("points_last_n", "points_diff_last_n"),
        ("goal_diff_last_n", "goal_diff_form_diff"),
        ("rest_days", "rest_days_diff"),
        ("missing_players_count", "missing_players_diff"),
    ]
    for base_name, new_name in pairs:
        h = f"home_{base_name}"
        a = f"away_{base_name}"
        if h in df.columns and a in df.columns:
            df[new_name] = df[h] - df[a]

    # NaNs razonables
    fill_zero_cols = [c for c in df.columns if c.endswith("_last_n") or c.endswith("_diff") or "congestion" in c or "missing_players" in c]
    for col in fill_zero_cols:
        df[col] = df[col].fillna(0)

    return df.sort_values("match_date").reset_index(drop=True)
