from __future__ import annotations

import json
import re
from pathlib import Path
from datetime import datetime, timezone
from typing import Any

import pandas as pd

from soccer_scraper.collectors.clubelo import ClubEloCollector
from soccer_scraper.collectors.fbref import FBrefCollector
from soccer_scraper.collectors.referees import RefereeCollector, RefereeCollectorConfig
from soccer_scraper.collectors.sofascore import SofascoreCollector
from soccer_scraper.collectors.understat import UnderstatCollector
from soccer_scraper.collectors.whoscored import WhoScoredCollector
from soccer_scraper.canonical_export import export_canonical_json
from soccer_scraper.dataset_builder import build_final_dataset
from soccer_scraper.features.engineering import build_match_features
from soccer_scraper.utils.io import ensure_dir, read_parquet_if_exists, write_parquet
from soccer_scraper.utils.logging import get_logger


logger = get_logger(__name__)


def _load_table(path: Path) -> pd.DataFrame:
    df = read_parquet_if_exists(path)
    return pd.DataFrame() if df is None else df


def _pct(n: int, d: int) -> float:
    return round((n / d) * 100, 1) if d else 0.0


def _build_validation_report(curated_dir: Path) -> dict[str, Any]:
    facts_dir = curated_dir / "facts"
    match_wide = _load_table(curated_dir / "match_wide.parquet")
    lineups = _load_table(facts_dir / "fact_lineups.parquet")
    player_stats = _load_table(facts_dir / "fact_player_match_stats.parquet")

    if not player_stats.empty:
        if "entity_type" in player_stats.columns:
            player_stats = player_stats[player_stats["entity_type"].fillna("player").eq("player")].copy()
        if "player" in player_stats.columns:
            player_stats = player_stats[~player_stats["player"].astype(str).str.endswith("Players")].copy()

    stats_cols = [c for c in ["match_id", "team_id", "player_id", "rating", "passes_completed", "passes_attempted", "dribbles_completed", "dribbles_attempted", "unnamed_5_level_0_min"] if c in player_stats.columns]
    lineup_cols = [c for c in ["match_id", "season", "team_id", "player_id", "player", "team", "played", "is_starter", "minute_on", "minute_off", "position_start", "position_start_source", "formation"] if c in lineups.columns]
    played = pd.DataFrame()
    if lineup_cols:
        played = lineups.loc[:, lineup_cols].copy()
        if "played" in played.columns:
            played = played[played["played"].fillna(False)].copy()
    merged = played.merge(player_stats.loc[:, stats_cols].drop_duplicates() if stats_cols else pd.DataFrame(), on=[c for c in ["match_id", "team_id", "player_id"] if c in played.columns and c in player_stats.columns], how="left") if not played.empty else pd.DataFrame()

    matches_processed = int(match_wide["match_id"].nunique()) if not match_wide.empty and "match_id" in match_wide.columns else 0
    enriched_match_ids: set[Any] = set()
    if not lineups.empty and "position_start_source" in lineups.columns:
        enriched_match_ids.update(lineups.loc[lineups["position_start_source"].eq("whoscored"), "match_id"].dropna().astype(str).tolist())
    if not player_stats.empty and "rating" in player_stats.columns:
        enriched_match_ids.update(player_stats.loc[player_stats["rating"].notna(), "match_id"].dropna().astype(str).tolist())
    matches_successfully_enriched = len(enriched_match_ids)
    matches_failed = max(matches_processed - matches_successfully_enriched, 0)

    coverage_summary_per_season: dict[str, dict[str, Any]] = {}
    if not merged.empty and "season" in merged.columns:
        for season, group in merged.groupby("season", dropna=False):
            season_key = str(season)
            coverage_summary_per_season[season_key] = {
                "players_played": int(len(group)),
                "players_with_rating": int(group["rating"].notna().sum()) if "rating" in group.columns else 0,
                "players_with_passes": int(group["passes_completed"].notna().sum()) if "passes_completed" in group.columns else 0,
                "players_with_dribbles": int(group["dribbles_completed"].notna().sum()) if "dribbles_completed" in group.columns else 0,
            }
            coverage_summary_per_season[season_key].update(
                {
                    "rating_pct": _pct(coverage_summary_per_season[season_key]["players_with_rating"], coverage_summary_per_season[season_key]["players_played"]),
                    "passes_pct": _pct(coverage_summary_per_season[season_key]["players_with_passes"], coverage_summary_per_season[season_key]["players_played"]),
                    "dribbles_pct": _pct(coverage_summary_per_season[season_key]["players_with_dribbles"], coverage_summary_per_season[season_key]["players_played"]),
                }
            )

    starter_count_issues = 0
    invalid_formations = 0
    passes_violations = 0
    dribbles_violations = 0
    minutes_issues = 0

    if not lineups.empty and {"match_id", "team", "is_starter"}.issubset(lineups.columns):
        starter_counts = lineups[lineups["is_starter"].fillna(False)].groupby(["match_id", "team"]).size()
        starter_count_issues = int((starter_counts != 11).sum())
    if not match_wide.empty and "home_formation" in match_wide.columns and "away_formation" in match_wide.columns:
        valid = re.compile(r"^\d{2,4}$")
        invalid_formations = int((~match_wide["home_formation"].astype(str).str.match(valid) | ~match_wide["away_formation"].astype(str).str.match(valid)).sum())
    if not player_stats.empty and {"passes_completed", "passes_attempted"}.issubset(player_stats.columns):
        passes_violations = int((player_stats["passes_completed"].notna() & player_stats["passes_attempted"].notna() & (player_stats["passes_completed"] > player_stats["passes_attempted"])).sum())
    if not player_stats.empty and {"dribbles_completed", "dribbles_attempted"}.issubset(player_stats.columns):
        dribbles_violations = int((player_stats["dribbles_completed"].notna() & player_stats["dribbles_attempted"].notna() & (player_stats["dribbles_completed"] > player_stats["dribbles_attempted"])).sum())
    if not merged.empty and {"minute_on", "minute_off"}.issubset(merged.columns) and "match_id" in merged.columns:
        minutes_issues = int(
            sum(
                1
                for _, row in merged.iterrows()
                if pd.notna(row.get("unnamed_5_level_0_min"))
                and pd.notna(row.get("minute_on"))
                and pd.notna(row.get("minute_off"))
                and abs(float(row.get("unnamed_5_level_0_min")) - (float(row.get("minute_off")) - float(row.get("minute_on")))) > 1
            )
        )

    return {
        "matches_processed": matches_processed,
        "matches_successfully_enriched": matches_successfully_enriched,
        "matches_failed": matches_failed,
        "coverage_summary_per_season": coverage_summary_per_season,
        "validation_summary": {
            "starter_count_issues": starter_count_issues,
            "invalid_formations": invalid_formations,
            "passes_violations": passes_violations,
            "dribbles_violations": dribbles_violations,
            "minutes_issues": minutes_issues,
        },
    }


def run_collection(config: dict) -> None:
    project = config["project"]
    coll = config["collection"]
    selenium_cfg = config.get("selenium", {})
    raw_dir = Path(project["raw_dir"])
    ensure_dir(raw_dir)
    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")

    leagues = coll["leagues"]
    seasons = coll["seasons"]
    sources = coll["sources"]

    if sources.get("fbref", False):
        fb_cfg = config.get("fbref", {})
        browser_cfg = fb_cfg.get("browser", {})
        collector = FBrefCollector(
            data_dir=project["data_dir"],
            leagues=leagues,
            seasons=seasons,
            no_cache=fb_cfg.get("no_cache", False),
            no_store=fb_cfg.get("no_store", False),
            profile_root=browser_cfg.get("profile_root", project.get("chrome_profiles_dir", "sessions")),
            profile_name=browser_cfg.get("profile_name", "fbref_manual"),
            headless=browser_cfg.get("headless", True),
            chrome_binary=browser_cfg.get("chrome_binary"),
            user_agent=browser_cfg.get("user_agent"),
            wait_seconds=browser_cfg.get("wait_seconds", 12),
            cache_html_dir=browser_cfg.get("cache_html_dir"),
            max_matches_per_season=browser_cfg.get("max_matches_per_season"),
        )
        collector.save_outputs(collector.collect(), "raw/fbref", run_id=run_id, source_name="fbref")

        referee_cfg = config.get("referees", {})
        referee_collector = RefereeCollector(
            data_dir=project["data_dir"],
            config=RefereeCollectorConfig(
                whoscored_url_template=referee_cfg.get("whoscored_url_template"),
                whoscored_feed_template=referee_cfg.get("whoscored_feed_template"),
                cache_root=project.get("cache_dir"),
                min_match_confidence=referee_cfg.get("min_match_confidence", 0.85),
            ),
        )
        referee_collector.save_outputs(
            referee_collector.collect(run_id=run_id),
            "raw/referees",
            run_id=run_id,
            source_name="referees",
        )

    if sources.get("whoscored", False):
        ws_cfg = config.get("whoscored", {})
        path_to_browser = ws_cfg.get("path_to_browser") or selenium_cfg.get("chrome_binary")
        headless = ws_cfg.get("headless", selenium_cfg.get("headless", True))
        collector = WhoScoredCollector(
            data_dir=project["data_dir"],
            leagues=leagues,
            seasons=seasons,
            no_cache=ws_cfg.get("no_cache", False),
            no_store=ws_cfg.get("no_store", False),
            profile_root=ws_cfg.get("profile_root", project.get("chrome_profiles_dir", "sessions")),
            profile_name=ws_cfg.get("profile_name", "whoscored_manual"),
            path_to_browser=path_to_browser,
            driver_version=ws_cfg.get("driver_version"),
            version_main=ws_cfg.get("version_main"),
            headless=headless,
        )
        collector.save_outputs(collector.collect(), "raw/whoscored", run_id=run_id, source_name="whoscored")

    if sources.get("understat", False):
        us_cfg = config.get("understat", {})
        collector = UnderstatCollector(
            data_dir=project["data_dir"],
            leagues=leagues,
            seasons=seasons,
            no_cache=us_cfg.get("no_cache", False),
            no_store=us_cfg.get("no_store", False),
        )
        collector.save_outputs(collector.collect(), "raw/understat", run_id=run_id, source_name="understat")

    if sources.get("clubelo", False):
        collector = ClubEloCollector(data_dir=project["data_dir"])
        collector.save_outputs(collector.collect(), "raw/clubelo", run_id=run_id, source_name="clubelo")

    if sources.get("sofascore", False):
        collector = SofascoreCollector(
            data_dir=project["data_dir"],
            leagues=leagues,
            seasons=seasons,
        )
        collector.save_outputs(collector.collect(), "raw/sofascore", run_id=run_id, source_name="sofascore")

    logger.info("Scraping finalizado con run_id=%s", run_id)


def summarize_match_counts(config: dict) -> dict[str, Any]:
    project = config["project"]
    base = Path(project["data_dir"])
    final_root = Path(project.get("final_dir", base / "final")) / "final_dataset"

    def _count_match_dirs(root: Path) -> int:
        if not root.exists():
            return 0
        ids: set[str] = set()
        for p in root.rglob("*"):
            if p.is_dir() and p.name.startswith("match_id="):
                ids.add(p.name.split("=", 1)[-1])
        return len(ids)

    fbref = _count_match_dirs(base / "raw" / "fbref")
    whoscored = _count_match_dirs(base / "raw" / "whoscored")
    understat = _count_match_dirs(base / "raw" / "understat")
    final = read_parquet_if_exists(final_root / "match_wide.parquet")
    if final is None:
        final = pd.DataFrame()

    counts = {
        "fbref": fbref,
        "whoscored": whoscored,
        "understat": understat,
        "final": int(final["match_id"].dropna().astype(str).nunique()) if not final.empty and "match_id" in final.columns else 0,
    }

    report: dict[str, Any] = {
        "counts": counts,
        "common_match_ids": 0,
        "missing_by_source": {},
    }
    return report


def _first_existing(paths: list[Path]) -> pd.DataFrame | None:
    for p in paths:
        df = read_parquet_if_exists(p)
        if df is not None:
            return df
    return None


def _latest_existing(root: Path, filename: str) -> pd.DataFrame | None:
    candidates = [p for p in root.rglob(filename) if p.is_file()]
    if not candidates:
        return None
    latest = max(candidates, key=lambda p: p.stat().st_mtime)
    return read_parquet_if_exists(latest)


def run_feature_engineering(config: dict) -> Path:
    project = config["project"]
    feat_cfg = config["feature_engineering"]
    base = Path(project["data_dir"]) / "raw"
    final_base = Path(project.get("final_dir", Path(project["data_dir"]) / "final"))
    final_dir = ensure_dir(final_base)

    matches = read_parquet_if_exists(final_base / "final_dataset" / "match_wide.parquet")
    if matches is None:
        matches = _latest_existing(base / "fbref", "schedule.parquet")
    if matches is None:
        raise FileNotFoundError("No he encontrado schedule.parquet en ninguna fuente raw.")

    team_match_stats = _latest_existing(base / "fbref", "team_match_stats.parquet")
    shot_events = _latest_existing(base / "fbref", "shot_events.parquet")
    if shot_events is None:
        shot_events = _latest_existing(base / "understat", "shot_events.parquet")
    missing_players = _latest_existing(base / "whoscored", "missing_players.parquet")
    elo_df = _latest_existing(base / "clubelo", "elo_by_date.parquet")

    features = build_match_features(
        matches=matches,
        team_match_stats=team_match_stats,
        shot_events=shot_events,
        missing_players=missing_players,
        elo_df=elo_df,
        rolling_window=feat_cfg.get("rolling_window", 5),
        congestion_window_days=feat_cfg.get("congestion_window_days", 14),
        draw_elo_threshold=feat_cfg.get("draw_elo_threshold", 35),
        low_total_goals_threshold=feat_cfg.get("low_total_goals_threshold", 2.35),
    )

    out_path = final_dir / "features_model.parquet"
    write_parquet(features, out_path)
    logger.info("Features guardadas en %s (%s filas)", out_path, len(features))
    return out_path


def run_dataset_build(config: dict) -> dict[str, Path]:
    out = build_final_dataset(config)
    manifest_path = out.get("manifest")
    if manifest_path is not None:
        curated_dir = manifest_path.parent
        json_path = export_canonical_json(curated_dir, curated_dir / "canonical_dataset.json")
        out["canonical_json"] = json_path
        validation_report = _build_validation_report(curated_dir)
        validation_path = curated_dir / "validation_report.json"
        validation_path.write_text(json.dumps(validation_report, ensure_ascii=False, indent=2), encoding="utf-8")
        out["validation_report"] = validation_path
    logger.info("Dataset final generado con %s artefactos", len(out))
    return out
