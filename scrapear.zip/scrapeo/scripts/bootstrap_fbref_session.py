import sys
from pathlib import Path

import typer

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "src"))

from soccer_scraper.utils.selenium_session import ChromePersistentSession

DEFAULT_SESSION_ROOT = r"D:\Proyectos\soccer_scraper_sessions"


def main(
    profile_name: str = "fbref_manual",
    profile_root: str = DEFAULT_SESSION_ROOT,
    url: str = "https://fbref.com/en/comps/12/La-Liga-Stats",
    headless: bool = False,
    chrome_binary: str | None = None,
) -> None:
    sess = ChromePersistentSession(
        profile_root=profile_root,
        profile_name=profile_name,
        headless=headless,
        chrome_binary=chrome_binary,
    )
    sess.bootstrap(url=url)


if __name__ == "__main__":
    typer.run(main)
