import re
import json
from pathlib import Path
from datetime import datetime
from bs4 import BeautifulSoup

import pandas as pd


DATA_DIR = Path(r"D:\Proyectos\soccer_scraper_project_b\data")
HTML_ROOT = DATA_DIR / "html" / "whoscored"


def normalize_date_text(text: str) -> str | None:
    text = text.strip()
    for fmt in ["%A, %b %d %Y", "%a, %b %d %Y", "%d %b %Y"]:
        try:
            return datetime.strptime(text, fmt).date().isoformat()
        except Exception:
            pass
    return None


def extract_matches_from_html(html_path: Path) -> list[dict]:
    if not html_path.exists():
        return []
    
    html = html_path.read_text(encoding="utf-8", errors="ignore")
    soup = BeautifulSoup(html, "html.parser")
    matches = []
    seen_ids = set()
    
    fixture_container = soup.find("div", {"data-hypernova-key": "tournamentfixtures"})
    if not fixture_container:
        return matches
    
    accordions = fixture_container.find_all("div", class_=lambda x: x and "Accordion-module_accordion" in x)
    
    for accordion in accordions:
        header = accordion.find("div", class_=lambda x: x and "Accordion-module_header" in x)
        if not header:
            continue
        date_span = header.find("span")
        if not date_span:
            continue
        date_text = date_span.get_text(strip=True)
        match_date = normalize_date_text(date_text)
        
        children = accordion.find("div", class_=lambda x: x and "Accordion-module_children" in x)
        if not children:
            continue
        
        match_divs = children.find_all("div", class_=lambda x: x and "Match-module_match" in x)
        for match_div in match_divs:
            match_data = extract_match_info(match_div, match_date)
            if match_data and match_data["game_id"] not in seen_ids:
                seen_ids.add(match_data["game_id"])
                matches.append(match_data)
    
    return matches


def extract_match_info(match_div: BeautifulSoup, date: str) -> dict | None:
    scoreboard = match_div.find("div", class_=lambda x: x and "Match-module_scoreBoard" in x)
    if not scoreboard:
        return None
    
    teams_div = scoreboard.find("div", class_=lambda x: x and "Match-module_teams" in x)
    home_team = None
    away_team = None
    
    if teams_div:
        team_links = teams_div.find_all("a", class_=lambda x: x and "Match-module_teamNameText" in x)
        if len(team_links) >= 2:
            home_team = team_links[0].get_text(strip=True)
            away_team = team_links[1].get_text(strip=True)
    
    if not home_team or not away_team:
        return None
    
    scores_span = scoreboard.find("div", class_=lambda x: x and "Match-module_scores" in x)
    home_score = None
    away_score = None
    match_id = None
    match_url = None
    
    if scores_span:
        score_link = scores_span.find("a", class_=lambda x: x and "Match-module_score" in x)
        if score_link:
            match_url = score_link.get("href", "")
            match_id_match = re.search(r"/matches/(\d+)/", match_url)
            if match_id_match:
                match_id = int(match_id_match.group(1))
            score_spans = score_link.find_all("span")
            if len(score_spans) >= 2:
                try:
                    home_score = int(score_spans[0].get_text(strip=True))
                    away_score = int(score_spans[1].get_text(strip=True))
                except ValueError:
                    pass
    
    return {
        "game_id": match_id,
        "date": date,
        "home_team": home_team,
        "away_team": away_team,
        "home_score": home_score,
        "away_score": away_score,
        "match_url": match_url,
    }


def main():
    all_matches = []
    
    for season in ["2022-2023", "2023-2024", "2024-2025"]:
        calendar_dir = HTML_ROOT / "matches" / season / "calendario"
        if not calendar_dir.exists():
            print(f"Skipping {season} (not found)")
            continue
        
        html_files = sorted(calendar_dir.glob("*.html"))
        print(f"Processing {season}: {len(html_files)} files")
        
        seen_ids = set()
        
        for html_file in html_files:
            matches = extract_matches_from_html(html_file)
            for m in matches:
                if m["game_id"] and m["game_id"] not in seen_ids:
                    seen_ids.add(m["game_id"])
                    all_matches.append({
                        "game_id": m["game_id"],
                        "date": m["date"],
                        "home_team": m["home_team"],
                        "away_team": m["away_team"],
                        "home_score": m["home_score"],
                        "away_score": m["away_score"],
                        "match_url": m["match_url"],
                        "season": season,
                        "league": "ESP-La Liga",
                    })
            print(f"  {html_file.name}: {len(matches)} matches")
    
    print(f"\nTotal unique matches: {len(all_matches)}")
    
    df = pd.DataFrame(all_matches)
    
    for season in ["2022-2023", "2023-2024", "2024-2025"]:
        df_season = df[df["season"] == season].copy()
        df_season = df_season.sort_values("date")
        csv_path = HTML_ROOT / "matches" / season / "schedule.csv"
        csv_path.parent.mkdir(parents=True, exist_ok=True)
        df_season.to_csv(csv_path, index=False)
        print(f"Saved {len(df_season)} matches to: {csv_path}")


if __name__ == "__main__":
    main()