from __future__ import annotations

from pathlib import Path
from typing import Any

import pandas as pd
import soccerdata as sd

from soccer_scraper.collectors.base import BaseCollector


class SofascoreCollector(BaseCollector):
    def __init__(
        self,
        data_dir: str | Path,
        leagues: list[str],
        seasons: list[str | int],
    ) -> None:
        super().__init__(data_dir)
        self.reader = sd.Sofascore(
            leagues=leagues,
            seasons=seasons,
            data_dir=Path(data_dir) / "cache" / "Sofascore",
        )

    def collect(self, **kwargs: Any) -> dict[str, pd.DataFrame]:
        self.logger.info("Leyendo Sofascore schedule")
        schedule = self.reader.read_schedule().reset_index()

        self.logger.info("Leyendo Sofascore league table")
        table = self.reader.read_league_table().reset_index()

        return {
            "schedule": schedule,
            "league_table": table,
        }
