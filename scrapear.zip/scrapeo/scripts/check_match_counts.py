from pathlib import Path
import sys

import typer

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from soccer_scraper.config import load_config
from soccer_scraper.pipeline import summarize_match_counts


def main(config: str = "config/config.yml") -> None:
    cfg = load_config(config)
    report = summarize_match_counts(cfg)
    print(report)


if __name__ == "__main__":
    typer.run(main)
