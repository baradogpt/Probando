# Scrapeo

Proyecto core de scraping, normalización y feature engineering.

## Estructura

```text
scrapeo/
├── config/
├── src/soccer_scraper/
├── tests/
├── pyproject.toml
└── README.md
```

## Datos esperados

- `data/raw/` para artefactos crudos
- `data/html/` para HTMLs cacheados
- `data/final/final_dataset/` para el dataset final

## Comandos

```bash
py -3 -m pip install -e .
py -3 scripts/run_collection.py
py -3 -m soccer_scraper.cli build-dataset --config config/config.yml
py -3 scripts/sync_whoscored_artifacts.py
py -3 scripts/build_features.py
py -3 -m soccer_scraper.cli check-match-counts --config config/config.yml
```
