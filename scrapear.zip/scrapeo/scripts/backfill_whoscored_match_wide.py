from __future__ import annotations

from pathlib import Path
import re
import unicodedata

import pandas as pd


ROOT = Path("data")
CURATED = ROOT / "curated" / "final_dataset"
CLEAN = ROOT / "clean" / "final_dataset"


TEAM_COLS = [
    "cornersTotal",
    "cornersAccurate",
    "passesTotal",
    "passesAccurate",
    "passSuccess",
    "passesKey",
    "shotsTotal",
    "shotsOnTarget",
    "shotsBlocked",
    "possession",
    "touches",
    "dribblesWon",
    "dribblesAttempted",
    "dribblesLost",
    "dribbleSuccess",
    "dribbledPast",
    "tacklesTotal",
    "tackleSuccessful",
    "tackleUnsuccesful",
    "tackleSuccess",
    "aerialsWon",
    "aerialsTotal",
    "aerialSuccess",
    "offensiveAerials",
    "defensiveAerials",
    "clearances",
    "interceptions",
    "offsidesCaught",
    "foulsCommited",
    "errors",
]

ALIASES = {
    "deportivo_alaves": "alaves",
    "real_valladolid": "valladolid",
    "real_oviedo": "oviedo",
    "leganes": "leganes",
}


def _key(value: object) -> str:
    text = unicodedata.normalize("NFKD", str(value).strip())
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    text = text.lower().replace("&", " and ")
    text = re.sub(r"[^a-z0-9]+", "_", text)
    out = text.strip("_")
    return ALIASES.get(out, out)


def _latest(root: Path, filename: str) -> Path:
    candidates = list(root.rglob(filename))
    if not candidates:
        raise FileNotFoundError(f"No encuentro {filename} en {root}")
    return max(candidates, key=lambda p: p.stat().st_mtime)


def _match_level(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return df
    out = df.copy()
    out["match_id"] = out["match_id"].astype(str)
    out["date_key"] = pd.to_datetime(out["match_date"], errors="coerce").dt.strftime("%Y-%m-%d")
    out["home_key"] = out["home_team"].map(_key)
    out["away_key"] = out["away_team"].map(_key)
    home = out.loc[out["side"].astype(str).str.lower().eq("home")].copy()
    away = out.loc[out["side"].astype(str).str.lower().eq("away")].copy()
    if home.empty or away.empty:
        return pd.DataFrame()
    home_cols = ["date_key", "home_key", "away_key"] + [c for c in TEAM_COLS if c in home.columns]
    away_cols = ["date_key", "home_key", "away_key"] + [c for c in TEAM_COLS if c in away.columns]
    home = home.loc[:, home_cols].rename(columns={c: f"ws_home_{c}" for c in TEAM_COLS if c in home.columns})
    away = away.loc[:, away_cols].rename(columns={c: f"ws_away_{c}" for c in TEAM_COLS if c in away.columns})
    return home.merge(away, on=["date_key", "home_key", "away_key"], how="inner")


def main() -> None:
    match_wide = pd.read_parquet(CURATED / "match_wide.parquet")
    whoscored = pd.read_parquet(CLEAN / "whoscored_team_match_stats.parquet")

    wide = match_wide.copy()
    wide = wide.drop(columns=[c for c in wide.columns if c.startswith("ws_")], errors="ignore")
    wide["match_id"] = wide["match_id"].astype(str)
    wide["date_key"] = pd.to_datetime(wide["date"], errors="coerce").dt.strftime("%Y-%m-%d")
    wide["home_key"] = wide["home"].map(_key)
    wide["away_key"] = wide["away"].map(_key)

    home_ws = whoscored.loc[whoscored["side"].astype(str).str.lower().eq("home")].copy()
    away_ws = whoscored.loc[whoscored["side"].astype(str).str.lower().eq("away")].copy()
    for frame, prefix in [(home_ws, "ws_home"), (away_ws, "ws_away")]:
        if not frame.empty:
            frame["match_id"] = frame["match_id"].astype(str)
            rename = {c: f"{prefix}_{c}" for c in TEAM_COLS if c in frame.columns}
            frame = frame.rename(columns=rename)
            link_col = "home_whoscored_match_id" if prefix == "ws_home" else "away_whoscored_match_id"
            if link_col in wide.columns:
                wide = wide.merge(
                    frame[["match_id"] + list(rename.values())],
                    left_on=link_col,
                    right_on="match_id",
                    how="left",
                    suffixes=("", "_drop"),
                )
                if "match_id_drop" in wide.columns:
                    wide = wide.drop(columns=["match_id_drop"])
                if "match_id_y" in wide.columns:
                    wide = wide.drop(columns=["match_id_y"])

    # Fallback by normalized team names and date for rows without WhoScored ids.
    ws = _match_level(whoscored)
    if not ws.empty:
        wide = wide.merge(ws, on=["date_key", "home_key", "away_key"], how="left")
    wide = wide.drop(columns=[c for c in ["date_key", "home_key", "away_key"] if c in wide.columns])

    CLEAN.mkdir(parents=True, exist_ok=True)
    wide.to_parquet(CURATED / "match_wide.parquet", index=False)
    wide.to_csv(CURATED / "match_wide.csv", index=False)
    wide.to_parquet(CLEAN / "match_wide.parquet", index=False)
    wide.to_csv(CLEAN / "match_wide.csv", index=False)
    print(f"Updated match_wide with {len([c for c in wide.columns if c.startswith('ws_')])} WhoScored columns")


if __name__ == "__main__":
    main()
