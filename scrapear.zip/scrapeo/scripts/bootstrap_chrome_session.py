import typer

from soccer_scraper.utils.selenium_session import ChromePersistentSession

DEFAULT_SESSION_ROOT = r"D:\Proyectos\soccer_scraper_sessions"


def main(
    profile_name: str = "whoscored_manual",
    profile_root: str = DEFAULT_SESSION_ROOT,
    url: str = "https://www.whoscored.com/",
    headless: bool = False,
    chrome_binary: str | None = None,
) -> None:
    sess = ChromePersistentSession(
        profile_root=profile_root,
        profile_name=profile_name,
        headless=headless,
        chrome_binary=chrome_binary,
    )
    sess.bootstrap(url=url)


if __name__ == "__main__":
    typer.run(main)
