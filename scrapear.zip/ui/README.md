# UI

Interfaz web de consulta del dataset final.

## Ejecutar

```bash
py -3 -m pip install -e .
py -3 -m pip install -e ../scrapeo
streamlit run src/app.py
```

## Dependencia del core

La UI carga utilidades desde `../scrapeo/src`, así que el core debe existir en la carpeta hermana `scrapeo/`.
