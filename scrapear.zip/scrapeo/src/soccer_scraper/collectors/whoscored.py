from __future__ import annotations

import re
import json
import time
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Optional

import pandas as pd
import soccerdata as sd
import soccerdata._common as sd_common
import undetected_chromedriver as uc
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.support.ui import WebDriverWait
from webdriver_manager.chrome import ChromeDriverManager

from soccer_scraper.collectors.base import BaseCollector

DEFAULT_SESSION_ROOT = Path(r"D:\Proyectos\soccer_scraper_sessions")


MATCH_ROW_XPATH = "//div[contains(@class,'Match-module_match__')]"
ACCORDION_XPATH = "ancestor::div[contains(@class,'Accordion-module_accordion__')][1]"
STATUS_TOKENS = {"FT", "AET", "ET", "PEN", "HT", "LIVE", "1H", "2H", "ET HT", "ET FT"}


def _season_label_to_key(label: str) -> str:
    text = str(label).strip()
    return text.replace("/", "-")


def _slug_text(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(value).strip().lower()).strip("_")


class WhoScoredCollector(BaseCollector):
    def __init__(
        self,
        data_dir: str | Path,
        leagues: list[str],
        seasons: list[str | int],
        no_cache: bool = False,
        no_store: bool = False,
        profile_root: str | Path = DEFAULT_SESSION_ROOT,
        profile_name: str = "whoscored_manual",
        path_to_browser: Optional[str] = None,
        driver_version: Optional[str] = None,
        version_main: Optional[int] = None,
        headless: bool = False,
        reset_checkpoint: bool = False,
    ) -> None:
        super().__init__(data_dir)
        self.leagues = leagues
        self.seasons = seasons
        browser_path = Path(path_to_browser) if path_to_browser else None
        profile_dir = (Path(profile_root) / profile_name).resolve()
        profile_dir.mkdir(parents=True, exist_ok=True)
        if driver_version is None and version_main is not None:
            driver_version = str(version_main)
        driver_path = ChromeDriverManager(driver_version=driver_version).install() if driver_version is not None else None

        # soccerdata uses undetected_chromedriver internally; pin the driver to
        # the local Chrome major version so the browser/session can start.
        if version_main is not None or browser_path is not None:
            original_uc = sd_common.uc
            original_chrome = original_uc.Chrome

            class PinnedChrome(original_chrome):
                def __init__(self, *args: Any, **kwargs: Any):
                    if version_main is not None and kwargs.get("version_main") is None:
                        kwargs["version_main"] = version_main
                    if browser_path is not None and kwargs.get("browser_executable_path") is None:
                        kwargs["browser_executable_path"] = str(browser_path)
                    if kwargs.get("user_data_dir") is None:
                        kwargs["user_data_dir"] = str(profile_dir)
                    if driver_path is not None and kwargs.get("driver_executable_path") is None:
                        kwargs["driver_executable_path"] = driver_path
                    super().__init__(*args, **kwargs)

            class UCProxy:
                ChromeOptions = original_uc.ChromeOptions

                def __init__(self, chrome_cls: type):
                    self.Chrome = chrome_cls

                def __getattr__(self, name: str):
                    return getattr(original_uc, name)

            sd_common.uc = UCProxy(PinnedChrome)

        self.reader = sd.WhoScored(
            leagues=leagues,
            seasons=seasons,
            no_cache=no_cache,
            no_store=no_store,
            data_dir=Path(data_dir) / "html" / "whoscored",
            path_to_browser=browser_path,
            headless=headless,
        )
        original_parse_season_stages = self.reader._parse_season_stages

        def _safe_parse_season_stages() -> list[Any]:
            try:
                return original_parse_season_stages()
            except TimeoutException:
                return []

        self.reader._parse_season_stages = _safe_parse_season_stages  # type: ignore[method-assign]
        self.reset_checkpoint = reset_checkpoint
        self.html_root = Path(data_dir) / "html" / "whoscored"
        self.html_root.mkdir(parents=True, exist_ok=True)

    def _save_html(self, rel_path: str, html: str) -> None:
        path = self.html_root / rel_path
        path.parent.mkdir(parents=True, exist_ok=True)
        try:
            path.write_text(html or "", encoding="utf-8")
        except Exception:
            pass

    def _save_active_section(self, rel_path: str) -> None:
        try:
            html = self.reader._driver.execute_script(
                """
                const sel = window.location.hash;
                if (!sel) return document.documentElement.outerHTML;
                const el = document.querySelector(sel);
                return el ? el.outerHTML : document.documentElement.outerHTML;
                """
            )
            self._save_html(rel_path, html if isinstance(html, str) else str(html))
        except Exception:
            self._save_html(rel_path, self.reader._driver.page_source or "")

    def _click_tab_and_save(self, label: str, rel_path: str) -> bool:
        candidates = [
            f"//a[normalize-space()='{label}']",
            f"//button[normalize-space()='{label}']",
            f"//*[self::li or self::span][normalize-space()='{label}']",
        ]
        for xpath in candidates:
            try:
                el = self.reader._driver.find_element(By.XPATH, xpath)
                self.reader._driver.execute_script("arguments[0].click();", el)
                time.sleep(2)
                self._save_html(rel_path, self.reader._driver.page_source or "")
                return True
            except Exception:
                continue
        return False

    def _click_tab(self, label: str) -> bool:
        candidates = []
        if label.startswith("#"):
            candidates.append(f"//a[@href='{label}']")
        candidates.extend([
            f"//a[normalize-space()='{label}']",
            f"//button[normalize-space()='{label}']",
            f"//*[self::li or self::span][normalize-space()='{label}']",
        ])
        for xpath in candidates:
            try:
                el = self.reader._driver.find_element(By.XPATH, xpath)
                self.reader._driver.execute_script("arguments[0].click();", el)
                time.sleep(2)
                return True
            except Exception:
                continue
        return False

    def _save_visible_whoscored_states(self, match_root: str, base_name: str, tabs: list[str], filters: list[str]) -> None:
        self._save_html(f"{match_root}/{base_name}.html", self.reader._driver.page_source or "")
        for tab in tabs:
            if not self._click_tab(tab):
                continue
            self._save_active_section(f"{match_root}/{base_name}_{_slug_text(tab)}.html")
            for flt in filters:
                if self._click_tab(flt):
                    self._save_active_section(f"{match_root}/{base_name}_{_slug_text(tab)}_{_slug_text(flt)}.html")

    def _season_from_match_url(self, match_url: str) -> str:
        m = re.search(r"(\d{4}-\d{4})", match_url)
        if m:
            return m.group(1)
        return "unknown-season"

    def _normalize_whoscored_url(self, url: str) -> str:
        text = str(url).strip()
        if text.startswith("http://"):
            return "https://" + text[len("http://"):]
        if text.startswith("https://"):
            return text
        if text.startswith("//"):
            return f"https:{text}"
        if text.startswith("/"):
            return f"https://www.whoscored.com{text}"
        if text:
            return f"https://www.whoscored.com/{text.lstrip('/')}"
        return text

    def _extract_match_links_from_html(self, html: str) -> list[tuple[int, str]]:
        links: list[tuple[int, str]] = []
        seen: set[int] = set()
        for match in re.finditer(r'href="([^"]*/matches/(\d+)/show/[^"]*)"', html):
            match_id = int(match.group(2))
            if match_id in seen:
                continue
            seen.add(match_id)
            links.append((match_id, match.group(1)))
        return links

    def scrape_one_match(self, match_id: int, match_url: str) -> dict[str, Path]:
        season_slug = self._season_from_match_url(match_url)
        match_root = f"matches/{season_slug}/{match_id}"
        match_url = self._normalize_whoscored_url(match_url)
        show_url = match_url if "/show/" in match_url else match_url.replace("/live/", "/show/")
        live_url = show_url.replace("/show/", "/live/")
        livestats_url = show_url.replace("/show/", "/livestatistics/")
        teamstats_url = show_url.replace("/show/", "/teamstatistics/")
        self.reader._driver.get(show_url)
        self._save_visible_whoscored_states(match_root, "show", [], [])
        try:
            self.reader._driver.get(teamstats_url)
            self._save_html(f"{match_root}/teamstatistics.html", self.reader._driver.page_source or "")
        except Exception as exc:
            self.logger.warning("teamstatistics failed for %s: %s", match_id, exc)
        try:
            self.reader._driver.get(livestats_url)
            self._save_html(f"{match_root}/livestatistics.html", self.reader._driver.page_source or "")
            for side in ["home", "away"]:
                for tab in ["summary", "offensive", "defensive", "passing"]:
                    frag = f"#live-player-{side}-{tab}"
                    if self._click_tab(frag):
                        time.sleep(2)
                    self._save_active_section(f"{match_root}/livestatistics_{side}_{tab}.html")
        except Exception as exc:
            self.logger.warning("livestatistics failed for %s: %s", match_id, exc)
        try:
            self.reader._driver.get(live_url)
            self._save_visible_whoscored_states(match_root, "live", [], [])
        except Exception as exc:
            self.logger.warning("live failed for %s: %s", match_id, exc)
        return {
            "show_html": self.html_root / f"{match_root}/show.html",
            "team_html": self.html_root / f"{match_root}/teamstatistics.html",
            "player_html": self.html_root / f"{match_root}/livestatistics.html",
            "live_html": self.html_root / f"{match_root}/live.html",
        }

    def scrape_season_html_only(self) -> list[Path]:
        schedule = self._scrape_schedule_rows()
        if schedule.empty:
            return []
        saved: list[Path] = []
        existing_ids = {int(p.name) for p in (self.html_root / "matches").glob("*/*") if p.is_dir() and p.name.isdigit()}
        for _, row in schedule.iterrows():
            match_id = row.get("game_id")
            match_url = row.get("url")
            if pd.isna(match_id) or not match_url:
                continue
            match_id_int = int(match_id)
            if match_id_int in existing_ids:
                continue
            self.logger.info("Scraping HTML match %s", match_id_int)
            try:
                out = self.scrape_one_match(match_id_int, str(match_url))
            except Exception as exc:
                self.logger.warning("Skipping match %s: %s", match_id_int, exc)
                continue
            saved.extend(out.values())
            existing_ids.add(match_id_int)
        return saved

    def _local_season_catalog(self, league: str) -> dict[str, str]:
        candidates = [
            Path(self.data_dir) / "html" / "whoscored" / "seasons" / f"{league}.html",
            Path(self.data_dir).parent / "data" / "html" / "whoscored" / "seasons" / f"{league}.html",
        ]
        html_path = next((p for p in candidates if p.exists()), None)
        if html_path is None:
            return {}
        html = html_path.read_text(encoding="utf-8", errors="ignore")
        matches = re.findall(r'<option[^>]*value="([^"]+)"[^>]*>(\d{4}/\d{4})</option>', html)
        catalog: dict[str, str] = {}
        for url, label in matches:
            catalog[_season_label_to_key(label)] = url
        return catalog

    def _local_fixtures_url(self, league: str, season: str | int) -> str | None:
        candidates = [
            Path(self.data_dir) / "html" / "whoscored" / "seasons" / f"{league}.html",
            Path(self.data_dir).parent / "data" / "html" / "whoscored" / "seasons" / f"{league}.html",
        ]
        html_path = next((p for p in candidates if p.exists()), None)
        if html_path is None:
            return None
        html = html_path.read_text(encoding="utf-8", errors="ignore")
        season_key = _season_label_to_key(season)
        m = re.search(rf'<a[^>]*href="([^"]*/fixtures/[^"]*{re.escape(season_key)}[^"]*)"[^>]*class=""', html)
        if m:
            return m.group(1)
        m = re.search(r'<a[^>]*id="link-fixtures"[^>]*href="([^"]+)"', html)
        return m.group(1) if m else None

    def _scrape_schedule_rows(self) -> pd.DataFrame:
        all_rows: list[dict[str, Any]] = []
        seen_game_ids: set[int] = set()
        league_catalogs = {league: self._local_season_catalog(league) for league in self.leagues}
        current_league: str | None = None
        current_season: str | int | None = None

        def _normalize_date_text(text: str) -> str | None:
            text = text.strip()
            for fmt in ["%A, %b %d %Y", "%a, %b %d %Y", "%d %b %Y"]:
                try:
                    return __import__("datetime").datetime.strptime(text, fmt).date().isoformat()
                except Exception:
                    pass
            return None

        def _parse_match_card(text: str) -> dict[str, Any] | None:
            lines = [line.strip() for line in text.splitlines() if line.strip()]
            if len(lines) < 5:
                return None
            date_text = _normalize_date_text(lines[0]) or lines[0]
            noise = {"1", "X", "2", "-"}
            odds_re = re.compile(r"^\d+(?:\.\d+)?$")
            time_re = re.compile(r"^\d{1,2}:\d{2}$")
            team_candidates: list[str] = []
            time_text: str | None = None
            for token in lines[1:]:
                if time_text is None and time_re.match(token):
                    time_text = token
                    continue
                if token in noise or odds_re.match(token):
                    continue
                if token.isdigit():
                    continue
                if token not in team_candidates:
                    team_candidates.append(token)
                if len(team_candidates) >= 2:
                    break
            if len(team_candidates) < 2:
                return None
            start_time = None
            if date_text and time_text:
                start_time = f"{date_text}T{time_text}:00"
            return {
                "date": date_text,
                "start_time": start_time,
                "home_team": team_candidates[0],
                "away_team": team_candidates[1],
            }

        def _open_page(url: str):
            self.reader._driver.get(url)
            try:
                WebDriverWait(self.reader._driver, 30, poll_frequency=1).until(
                    ec.presence_of_element_located((By.CSS_SELECTOR, '[data-hypernova-key="tournamentfixtures"]'))
                )
            except TimeoutException:
                time.sleep(5)

        def _save_current_fixture_page(league: str, season: str | int, label: str) -> None:
            safe_label = re.sub(r"[^A-Za-z0-9._-]+", "_", label).strip("_") or "page"
            season_str = str(season)
            dom_html = self.reader._driver.execute_script("return document.documentElement.outerHTML")
            self._save_html(f"matches/{season_str}/calendario/{safe_label}.html", dom_html or "")
            time.sleep(1)

        def _extract_from_dom(league: str, season: str | int) -> list[dict[str, Any]]:
            rows: list[dict[str, Any]] = []
            cards = self.reader._driver.execute_script(
                r"""
                const anchors = Array.from(document.querySelectorAll('a[href*="/matches/"][href*="/show/"]'));
                return anchors.map(a => {
                  const match = a.href.match(/\/matches\/(\d+)\/show\//);
                  const card = a.closest('div[class*="Match-module_match__"]');
                  const panel = a.closest('div[class*="Accordion-module_accordion__"]');
                  return {
                    href: a.href,
                    text: (card ? card.innerText : a.innerText) || '',
                    dateText: (panel ? panel.innerText : '') || '',
                    matchId: match ? match[1] : null,
                  };
                });
                """
            ) or []
            for card in cards:
                mid_raw = card.get("matchId")
                href = str(card.get("href") or "")
                if not mid_raw:
                    continue
                game_id = int(mid_raw)
                if game_id in seen_game_ids:
                    continue
                parsed = _parse_match_card(str(card.get("text") or "")) or {}
                date_text = str(card.get("dateText") or "").splitlines()[0].strip() if card.get("dateText") else ""
                date = _normalize_date_text(date_text) or date_text
                start_time = parsed.get("start_time")
                home_team = parsed.get("home_team")
                away_team = parsed.get("away_team")
                if not home_team or not away_team:
                    continue
                rows.append(
                    {
                        "date": date,
                        "home_team": home_team,
                        "away_team": away_team,
                        "game_id": game_id,
                        "url": href,
                        "start_time": start_time,
                        "score": None,
                        "league": league,
                        "season": season,
                    }
                )
                seen_game_ids.add(game_id)
            return rows

        def _current_label() -> str:
            try:
                return self.reader._driver.find_element(By.CSS_SELECTOR, "#toggleCalendar span.toggleDatePicker").text.strip()
            except Exception:
                return ""

        def _collect_direction(button_id: str, league: str, season: str | int) -> None:
            seen_labels: set[str] = set()
            while True:
                label = _current_label()
                if label and label in seen_labels:
                    break
                if label:
                    seen_labels.add(label)
                    _save_current_fixture_page(league, season, label)
                rows = _extract_from_dom(league, season)
                if rows:
                    all_rows.extend(rows)
                try:
                    btn = self.reader._driver.find_element(By.ID, button_id)
                except Exception:
                    break
                if btn.get_attribute("disabled"):
                    break
                prev_label = label
                self.reader._driver.execute_script("arguments[0].click();", btn)
                try:
                    WebDriverWait(self.reader._driver, 30, poll_frequency=1).until(lambda d: _current_label() != prev_label)
                except TimeoutException:
                    break

        for league in self.leagues:
            season_catalog = league_catalogs.get(league, {})
            for season in self.seasons:
                season_key = _season_label_to_key(season)
                fixtures_url = self._local_fixtures_url(league, season)
                season_url = season_catalog.get(season_key)
                if not fixtures_url and not season_url:
                    continue
                current_league = league
                current_season = season
                url = f"https://www.whoscored.com{fixtures_url or season_url}"
                _open_page(url)
                self._save_html(f"seasons/{league}.html", self.reader._driver.page_source or "")
                _collect_direction("dayChangeBtn-prev", league, season)
                _open_page(url)
                self._save_html(f"seasons/{league}.html", self.reader._driver.page_source or "")
                _collect_direction("dayChangeBtn-next", league, season)

        if not all_rows:
            return pd.DataFrame()

        return pd.DataFrame(all_rows)

    def _extract_json_array(self, html: str, key: str) -> list[dict[str, Any]]:
        needle = f"{key}: JSON.parse("
        start = html.find(needle)
        if start == -1:
            return []
        start = start + len(needle)
        quote = html[start]
        end = html.find(quote, start + 1)
        if end == -1:
            return []
        try:
            return json.loads(html[start + 1:end])
        except Exception:
            return []

    def _extract_match_centre_data(self, html: str) -> dict[str, Any]:
        needle = "matchCentreData: "
        start = html.find(needle)
        if start == -1:
            return {}
        start += len(needle)
        level = 0
        in_str = False
        esc = False
        end = None
        for i, ch in enumerate(html[start:], start):
            if in_str:
                if esc:
                    esc = False
                elif ord(ch) == 92:
                    esc = True
                elif ch == '"':
                    in_str = False
            else:
                if ch == '"':
                    in_str = True
                elif ch == '{':
                    level += 1
                elif ch == '}':
                    level -= 1
                    if level == 0:
                        end = i + 1
                        break
        if end is None:
            return {}
        try:
            return json.loads(html[start:end])
        except Exception:
            return {}

    def _extract_team_stat_value(self, team_data: dict[str, Any], key: str) -> int | float | None:
        def _sum_numeric(obj: Any) -> int | float | None:
            if isinstance(obj, (int, float)):
                return obj
            if isinstance(obj, dict):
                values = [v for v in obj.values() if isinstance(v, (int, float))]
                return sum(values) if values else None
            if isinstance(obj, list):
                values = [v for v in obj if isinstance(v, (int, float))]
                return sum(values) if values else None
            return None

        for container in [team_data, team_data.get("stats") if isinstance(team_data, dict) else None, team_data.get("teamStats") if isinstance(team_data, dict) else None]:
            if not isinstance(container, dict):
                continue
            if key in container:
                value = _sum_numeric(container.get(key))
                if value is not None:
                    return value
        return None

    def _checkpoint_path(self) -> Path:
        path = Path(self.data_dir) / "cache" / "WhoScored" / "exact_match_checkpoint.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        return path

    def _load_checkpoint(self) -> set[int]:
        if self.reset_checkpoint:
            return set()
        path = self._checkpoint_path()
        if not path.exists():
            return set()
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            return set(int(x) for x in payload.get("processed_game_ids", []))
        except Exception:
            return set()

    def _save_checkpoint(self, processed_game_ids: set[int]) -> None:
        path = self._checkpoint_path()
        payload = {
            "processed_game_ids": sorted(processed_game_ids),
        }
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    def _html_checkpoint_path(self) -> Path:
        path = Path(self.data_dir) / "cache" / "WhoScored" / "html_match_checkpoint.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        return path

    def _load_html_checkpoint(self) -> set[int]:
        path = self._html_checkpoint_path()
        if not path.exists():
            return set()
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            return set(int(x) for x in payload.get("processed_game_ids", []))
        except Exception:
            return set()

    def _save_html_checkpoint(self, processed_game_ids: set[int]) -> None:
        path = self._html_checkpoint_path()
        payload = {
            "processed_game_ids": sorted(processed_game_ids),
        }
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    def _scrape_exact_match_player_stats(self, schedule: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
        rows: list[dict[str, Any]] = []
        team_rows: list[dict[str, Any]] = []
        if schedule.empty:
            return pd.DataFrame(), pd.DataFrame()

        processed_game_ids = self._load_checkpoint()

        for _, match in schedule.iterrows():
            match_url = str(match.get("url") or "")
            if not match_url:
                continue
            if match_url.startswith("/"):
                match_url = f"https://www.whoscored.com{match_url}"
            show_url = match_url
            live_url = match_url.replace("/show/", "/live/")
            teamstats_url = match_url.replace("/show/", "/teamstatistics/")
            playerstats_url = match_url.replace("/show/", "/playerstatistics/")
            game_id = int(match.get("game_id")) if pd.notna(match.get("game_id")) else None
            if game_id is not None and game_id in processed_game_ids:
                continue
            self.reader._driver.get(show_url)
            show_html = self.reader._driver.page_source
            if game_id is not None:
                self._save_html(f"matches/{game_id}_show.html", show_html or "")
            self.reader._driver.get(teamstats_url)
            team_html = self.reader._driver.page_source
            if game_id is not None:
                self._save_html(f"matches/{game_id}_teamstatistics.html", team_html or "")
            self.reader._driver.get(playerstats_url)
            player_html = self.reader._driver.page_source
            if game_id is not None:
                self._save_html(f"matches/{game_id}_playerstatistics.html", player_html or "")
            self.reader._driver.get(live_url)
            live_html = self.reader._driver.page_source
            if game_id is not None:
                self._save_html(f"matches/{game_id}_live.html", live_html or "")
            show_players = self._extract_json_array(show_html, "homePlayers") + self._extract_json_array(show_html, "awayPlayers")
            show_ratings = {p.get("PlayerId"): p.get("Rating") for p in show_players if p.get("PlayerId") is not None}
            match_date = match.get("date") or match.get("match_date") or match.get("Date")
            league_name = match.get("league")
            season_name = match.get("season")
            home_name = match.get("home_team") or match.get("home") or match.get("Home")
            away_name = match.get("away_team") or match.get("away") or match.get("Away")

            # Match-level team summary from the team statistics page.
            try:
                from bs4 import BeautifulSoup
                soup = BeautifulSoup(team_html or "", "html.parser")
                summary = soup.select_one("#ws-team-stats-summary-content")
                if summary is not None:
                    played = [x.get_text(" ", strip=True) for x in summary.select("li.played")]
                    if len(played) >= 2:
                        for side, text in [("home", played[0]), ("away", played[1])]:
                            team_rows.append(
                                {
                                    "match_id": game_id,
                                    "match_url": match_url,
                                    "match_date": match_date,
                                    "home_team": home_name,
                                    "away_team": away_name,
                                    "league": league_name,
                                    "season": season_name,
                                    "team": home_name if side == "home" else away_name,
                                    "side": side,
                                    "metric": "played",
                                    "value_raw": text.replace("Played:", "").strip(),
                                    "value": pd.to_numeric(text.split(":", 1)[-1].strip(), errors="coerce"),
                                    "source": "whoscored",
                                    "source_table": "match_team_stats",
                                }
                            )
                    for stat in summary.select("div.stat"):
                        vals = stat.select("span.stat-value span.pulsable")
                        label_node = stat.select_one("span.stat-label")
                        if len(vals) < 2 or label_node is None:
                            continue
                        label = label_node.get_text(" ", strip=True)
                        home_val = vals[0].get_text(" ", strip=True)
                        away_val = vals[1].get_text(" ", strip=True)
                        for side, value in [("home", home_val), ("away", away_val)]:
                            team_rows.append(
                                {
                                    "match_id": game_id,
                                    "match_url": match_url,
                                    "match_date": match_date,
                                    "home_team": home_name,
                                    "away_team": away_name,
                                    "league": league_name,
                                    "season": season_name,
                                    "team": home_name if side == "home" else away_name,
                                    "side": side,
                                    "metric": _slug_text(label),
                                    "value_raw": value,
                                    "value": pd.to_numeric(str(value).replace("%", ""), errors="coerce"),
                                    "source": "whoscored",
                                    "source_table": "match_team_stats",
                                }
                            )
            except Exception:
                pass

            match_data = self._extract_match_centre_data(live_html)
            # Match-level player rows from the head-to-head player list.
            for p in show_players:
                player_id = p.get("PlayerId")
                side = "home" if p.get("Field") == 0 else "away"
                rows.append(
                    {
                        "match_id": game_id,
                        "match_url": match_url,
                        "match_date": match_date,
                        "home_team": home_name,
                        "away_team": away_name,
                        "league": league_name,
                        "season": season_name,
                        "team": home_name if side == "home" else away_name,
                        "side": side,
                        "player_id_ws": player_id,
                        "player_name_ws": p.get("Name") or p.get("KnownName") or p.get("PlayerName"),
                        "rating": p.get("Rating"),
                        "source": "whoscored",
                        "source_table": "match_player_stats",
                    }
                )

            if (rows or team_rows) and game_id is not None:
                processed_game_ids.add(game_id)
                self._save_checkpoint(processed_game_ids)

        return pd.DataFrame(rows), pd.DataFrame(team_rows)

    def collect(self, **kwargs: Any) -> dict[str, pd.DataFrame]:
        self.logger.info("Leyendo WhoScored schedule")
        schedule = self._scrape_schedule_rows()
        exact_match_player_stats, exact_match_team_stats = self._scrape_exact_match_player_stats(schedule)
        if not schedule.empty:
            if "game_id" in schedule.columns and "game" not in schedule.columns:
                try:
                    from soccerdata.whoscored import make_game_id

                    schedule["game"] = schedule.apply(make_game_id, axis=1)
                except Exception:
                    pass
            if {"league", "season", "game"}.issubset(schedule.columns):
                schedule = schedule.set_index(["league", "season", "game"]).sort_index().reset_index()
            self.reader.read_schedule = lambda *args, **kwargs: schedule.set_index(["league", "season", "game"]).sort_index() if {"league", "season", "game"}.issubset(schedule.columns) else schedule  # type: ignore[method-assign]

        return {
            "schedule": schedule,
            "match_player_stats": exact_match_player_stats,
            "match_team_stats": exact_match_team_stats,
        }
