from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import datetime, timezone
from hashlib import sha1
from pathlib import Path
from typing import Any

import pandas as pd

from soccer_scraper.utils.io import ensure_dir, write_parquet
from soccer_scraper.utils.logging import get_logger


class BaseCollector(ABC):
    def __init__(self, data_dir: str | Path) -> None:
        self.data_dir = Path(data_dir)
        ensure_dir(self.data_dir)
        self.logger = get_logger(self.__class__.__name__)

    @abstractmethod
    def collect(self, **kwargs: Any) -> dict[str, pd.DataFrame]:
        raise NotImplementedError

    def _artifact_path(self, source_name: str, artifact_name: str) -> Path:
        if source_name == "fbref":
            if "__" in artifact_name:
                page, rest = artifact_name.split("__", 1)
                return Path(page) / f"{rest}.parquet"
            if artifact_name.startswith("match_"):
                return Path("matches") / f"{artifact_name}.parquet"
            if artifact_name.startswith("player_season_stats_") or artifact_name.startswith("team_season_stats"):
                return Path("season") / f"{artifact_name}.parquet"
            if artifact_name in {"schedule", "schedule_matches", "home_away_results", "team_match_stats", "match_bundle", "match_pages", "match_team_summary", "match_team_stats", "match_player_stats", "match_keeper_stats", "match_lineups", "match_officials"}:
                return Path("matches") / f"{artifact_name}.parquet"
        if source_name == "understat":
            if artifact_name in {"schedule", "team_match_stats", "player_match_stats", "lineups", "shot_events"}:
                return Path("matches") / f"{artifact_name}.parquet"
            if artifact_name in {"player_season_stats"}:
                return Path("season") / f"{artifact_name}.parquet"
        return Path("tables") / f"{artifact_name}.parquet"

    def _cache_key(self, source_name: str, artifact_name: str, run_id: str) -> str:
        raw = f"{source_name}|{artifact_name}|{run_id}"
        return f"cache_{sha1(raw.encode('utf-8')).hexdigest()[:16]}"

    def _ensure_match_id(self, df: pd.DataFrame, source_name: str) -> pd.DataFrame:
        out = df.copy()
        if "match_id" in out.columns:
            return out
        for candidate in ["game_id", "gameid", "fixture_id", "match_report_id"]:
            if candidate in out.columns:
                out["match_id"] = out[candidate].astype(str).map(lambda x: f"{source_name}_{sha1(x.encode('utf-8')).hexdigest()[:12]}")
                return out
        return out

    def _add_metadata(
        self,
        df: pd.DataFrame,
        *,
        source_name: str,
        artifact_name: str,
        run_id: str,
        source_url: str | None = None,
    ) -> pd.DataFrame:
        out = df.copy()
        scraped_at = datetime.now(timezone.utc).isoformat()
        cache_key = self._cache_key(source_name, artifact_name, run_id)
        if "source" not in out.columns:
            out["source"] = source_name
        if "source_table" not in out.columns:
            out["source_table"] = artifact_name
        if "scraped_at" not in out.columns:
            out["scraped_at"] = scraped_at
        if "run_id" not in out.columns:
            out["run_id"] = run_id
        if "cache_key" not in out.columns:
            out["cache_key"] = cache_key
        if source_url is not None and "source_url" not in out.columns:
            out["source_url"] = source_url
        if "parser_version" not in out.columns:
            out["parser_version"] = "1"
        if "parse_success" not in out.columns:
            out["parse_success"] = True
        if "data_complete" not in out.columns:
            out["data_complete"] = True
        return out

    def save_outputs(self, outputs: dict[str, pd.DataFrame], subdir: str, *, run_id: str | None = None, source_name: str | None = None) -> dict[str, Path]:
        return {}
