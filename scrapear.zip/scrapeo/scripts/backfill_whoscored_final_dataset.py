from __future__ import annotations

from pathlib import Path

import pandas as pd


ROOT = Path("data")
CLEAN = ROOT / "clean" / "final_dataset"
CURATED = ROOT / "curated" / "final_dataset"


TEAM_RENAME = {
    "cornersTotal": "corners",
    "passesTotal": "passes_attempted",
    "passesAccurate": "passes_completed",
    "passSuccess": "pass_cmp_pct",
    "passesKey": "key_passes",
    "dribblesWon": "dribbles_completed",
    "dribblesAttempted": "dribbles_attempted",
    "tacklesTotal": "tackles_total",
    "tackleSuccessful": "tackles_won",
    "tackleSuccess": "tackle_success_pct",
    "aerialsTotal": "aerials_total",
    "aerialsWon": "aerials_won",
    "aerialSuccess": "aerial_success_pct",
    "clearances": "clearances",
    "claimsHigh": "claims_high",
    "errors": "errors",
    "interceptions": "interceptions",
    "offsidesCaught": "offsides_caught",
    "foulsCommited": "fouls_committed",
    "shotsTotal": "shots_total",
    "shotsOnTarget": "shots_on_target",
}


def _date_key(series: pd.Series) -> pd.Series:
    return pd.to_datetime(series, errors="coerce").dt.strftime("%Y-%m-%d")


def _latest(path: Path, name: str) -> Path:
    candidates = list(path.rglob(name))
    if not candidates:
        raise FileNotFoundError(f"No encuentro {name} en {path}")
    return max(candidates, key=lambda p: p.stat().st_mtime)


def _load_all(root: Path, filename: str) -> pd.DataFrame:
    frames = []
    for path in root.rglob(filename):
        try:
            df = pd.read_parquet(path)
        except Exception:
            continue
        if not df.empty:
            frames.append(df)
    if not frames:
        return pd.DataFrame()
    return pd.concat(frames, ignore_index=True, sort=False)


def _side_wide(team_stats: pd.DataFrame, side: str) -> pd.DataFrame:
    out = team_stats.loc[team_stats["side"].astype(str).str.lower().eq(side)].copy()
    if out.empty:
        return out
    out["date_key"] = _date_key(out["match_date"])
    rename = {k: f"{side}_{v}" for k, v in TEAM_RENAME.items() if k in out.columns}
    keep = [c for c in ["date_key", "home_team", "away_team", "team"] if c in out.columns] + [c for c in out.columns if c in TEAM_RENAME]
    out = out.loc[:, keep].rename(columns=rename)
    return out


def _match_level_wide(team_stats: pd.DataFrame) -> pd.DataFrame:
    if team_stats.empty:
        return pd.DataFrame()
    ws = team_stats.copy()
    ws["date_key"] = _date_key(ws["match_date"])
    rows = []
    for (date_key, home_team), group in ws.groupby(["date_key", "away_team"], dropna=False):
        home_row = group.loc[group["side"].astype(str).str.lower().eq("home")]
        away_row = group.loc[group["side"].astype(str).str.lower().eq("away")]
        if home_row.empty or away_row.empty:
            continue
        home_row = home_row.iloc[0]
        away_row = away_row.iloc[0]
        base = {"date_key": date_key, "home_team": home_team, "away_team": away_row.get("team")}
        for prefix, row in [("home", home_row), ("away", away_row)]:
            for raw_key, clean_key in TEAM_RENAME.items():
                if raw_key in row.index:
                    base[f"{prefix}_{clean_key}"] = row.get(raw_key)
        rows.append(base)
    return pd.DataFrame(rows)


def main() -> None:
    CLEAN.mkdir(parents=True, exist_ok=True)
    CURATED.mkdir(parents=True, exist_ok=True)

    raw_root = ROOT / "raw" / "whoscored" / "run_id=20260404T064906Z"
    whoscored_team = pd.read_parquet(raw_root / "tables" / "match_team_stats.parquet")
    whoscored_player = pd.read_parquet(raw_root / "tables" / "match_player_stats.parquet")
    match_wide = pd.read_parquet(CURATED / "match_wide.parquet")

    whoscored_team.to_parquet(CLEAN / "whoscored_team_match_stats.parquet", index=False)
    whoscored_player.to_parquet(CLEAN / "whoscored_player_match_stats.parquet", index=False)

    if not match_wide.empty and not whoscored_team.empty:
        mw = match_wide.copy()
        mw["date_key"] = _date_key(mw["date"])
        ws_match = _match_level_wide(whoscored_team)
        if not ws_match.empty:
            mw = mw.merge(ws_match, on=["date_key", "home_team", "away_team"], how="left")
        mw = mw.drop(columns=[c for c in ["date_key"] if c in mw.columns])
        mw.to_parquet(CURATED / "match_wide.parquet", index=False)
        mw.to_csv(CURATED / "match_wide.csv", index=False)


if __name__ == "__main__":
    main()
