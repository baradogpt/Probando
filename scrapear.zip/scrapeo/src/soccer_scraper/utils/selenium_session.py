from __future__ import annotations

from pathlib import Path
from typing import Optional

from selenium import webdriver
from selenium.webdriver import ChromeOptions
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

DEFAULT_SESSION_ROOT = Path(r"D:\Proyectos\soccer_scraper_sessions")


class ChromePersistentSession:
    """
    Utilidad para abrir Chrome con perfil persistente.

    No evade protecciones. Sirve para:
    - guardar sesión/cookies en perfil local
    - hacer login manual si una web lo requiere
    - reutilizar ese perfil en Selenium posteriormente
    """

    def __init__(
        self,
        profile_root: str | Path = DEFAULT_SESSION_ROOT,
        profile_name: str = "default",
        headless: bool = False,
        chrome_binary: Optional[str] = None,
        user_agent: Optional[str] = None,
        extra_args: Optional[list[str]] = None,
    ) -> None:
        self.profile_root = Path(profile_root)
        self.profile_name = profile_name
        self.headless = headless
        self.chrome_binary = chrome_binary
        self.user_agent = user_agent
        self.extra_args = extra_args or []
        self.profile_dir = self.profile_root / profile_name
        self.profile_dir.mkdir(parents=True, exist_ok=True)

    def build_driver(self) -> webdriver.Chrome:
        options = ChromeOptions()
        options.add_argument(f"--user-data-dir={self.profile_dir.resolve()}")
        options.add_argument("--profile-directory=Default")
        options.add_argument("--start-maximized")
        options.add_argument("--disable-dev-shm-usage")
        options.add_argument("--no-sandbox")
        options.add_argument("--disable-blink-features=AutomationControlled")
        options.add_argument("--disable-notifications")
        options.add_argument("--no-first-run")
        options.add_argument("--no-default-browser-check")

        if self.user_agent:
            options.add_argument(f"--user-agent={self.user_agent}")

        for arg in self.extra_args:
            options.add_argument(arg)

        if self.headless:
            options.add_argument("--headless=new")
            options.add_argument("--window-size=1600,1200")

        if self.chrome_binary:
            options.binary_location = self.chrome_binary

        service = Service(ChromeDriverManager().install())
        return webdriver.Chrome(service=service, options=options)

    def bootstrap(self, url: str = "https://www.whoscored.com/") -> None:
        driver = self.build_driver()
        driver.get(url)
        print("Chrome abierto con perfil persistente.")
        print("Haz login o validación manual si la web lo requiere.")
        print("Pulsa Enter aquí cuando termines para cerrar el navegador.")
        try:
            input()
        finally:
            try:
                driver.quit()
            except Exception:
                pass
