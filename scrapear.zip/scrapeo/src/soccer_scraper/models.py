from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any


@dataclass(slots=True)
class SourceMeta:
    source: str
    scraped_at: datetime
    league: str | None = None
    season: str | int | None = None


@dataclass(slots=True)
class DatasetArtifact:
    name: str
    rows: int
    path: str
    extra: dict[str, Any] | None = None
