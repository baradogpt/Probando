from __future__ import annotations

from pathlib import Path
from typing import Any

import pandas as pd
import soccerdata as sd

from soccer_scraper.collectors.base import BaseCollector


class ClubEloCollector(BaseCollector):
    def __init__(self, data_dir: str | Path) -> None:
        super().__init__(data_dir)
        self.reader = sd.ClubElo(data_dir=Path(data_dir) / "cache" / "ClubElo")

    def collect(self, **kwargs: Any) -> dict[str, pd.DataFrame]:
        date_str = kwargs.get("date", None)
        if date_str:
            elo_by_date = self.reader.read_by_date(date_str).reset_index()
        else:
            elo_by_date = self.reader.read_by_date().reset_index()

        self.logger.info("Leyendo ClubElo team history")
        # Equipo opcional, si no se indica no podemos descargar todos los históricos a la vez.
        team = kwargs.get("team")
        if team:
            team_history = self.reader.read_team_history(team).reset_index()
        else:
            team_history = pd.DataFrame()

        return {
            "elo_by_date": elo_by_date,
            "team_history": team_history,
        }
