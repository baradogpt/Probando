from __future__ import annotations

import re
from io import StringIO
from pathlib import Path
from typing import Any, cast
import time
from urllib.parse import urljoin
from hashlib import sha1

import pandas as pd
from bs4 import BeautifulSoup
from bs4.element import Tag
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select, WebDriverWait

from soccer_scraper.collectors.base import BaseCollector
from soccer_scraper.utils.selenium_session import ChromePersistentSession

DEFAULT_SESSION_ROOT = Path(r"D:\Proyectos\soccer_scraper_sessions")


FBREF_COMPETITIONS = {
    "ENG-Premier League": {"comp_id": 9, "slug": "Premier-League"},
    "ESP-La Liga": {"comp_id": 12, "slug": "La-Liga"},
    "ITA-Serie A": {"comp_id": 11, "slug": "Serie-A"},
    "GER-Bundesliga": {"comp_id": 20, "slug": "Bundesliga"},
    "FRA-Ligue 1": {"comp_id": 13, "slug": "Ligue-1"},
}


def _season_label(season: str | int) -> str:
    s = str(season).strip()
    if "-" in s:
        return s
    year = int(s)
    return f"{year}-{year + 1}"


class FBrefCollector(BaseCollector):
    def __init__(
        self,
        data_dir: str | Path,
        leagues: list[str],
        seasons: list[str | int],
        no_cache: bool = False,
        no_store: bool = False,
        profile_root: str | Path = DEFAULT_SESSION_ROOT,
        profile_name: str = "fbref_manual",
        headless: bool = False,
        chrome_binary: str | None = None,
        user_agent: str | None = None,
        wait_seconds: int = 12,
        cache_html_dir: str | Path | None = None,
        max_matches_per_season: int | None = None,
    ) -> None:
        super().__init__(data_dir)
        self.leagues = leagues
        self.seasons = seasons
        self.no_cache = no_cache
        self.no_store = no_store
        self.wait_seconds = wait_seconds
        self.max_matches_per_season = max_matches_per_season
        self.cache_html_dir = Path(cache_html_dir) if cache_html_dir is not None else self.data_dir / "html" / "fbref"
        self.cache_html_dir.mkdir(parents=True, exist_ok=True)
        self.session = ChromePersistentSession(
            profile_root=profile_root,
            profile_name=profile_name,
            headless=headless,
            chrome_binary=chrome_binary,
            user_agent=user_agent,
            extra_args=["--lang=en-US,en"],
        )

    def _fbref_checkpoint_path(self) -> Path:
        path = self.data_dir / "raw" / "fbref" / "processed_match_ids.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        return path

    def _load_processed_match_ids(self) -> set[str]:
        ids: set[str] = set()
        ck = self._fbref_checkpoint_path()
        if ck.exists():
            try:
                payload = pd.read_json(ck, typ="series")
                ids.update(str(v) for v in payload.get("processed_match_ids", []))
            except Exception:
                try:
                    import json

                    payload = json.loads(ck.read_text(encoding="utf-8"))
                    ids.update(str(v) for v in payload.get("processed_match_ids", []))
                except Exception:
                    pass

        # Seed from already curated/raw artifacts so reruns don't revisit completed matches.
        for path in [
            self.data_dir / "final" / "final_dataset" / "match_wide.parquet",
            self.data_dir / "final" / "final_dataset" / "facts" / "fact_lineups.parquet",
            self.data_dir / "curated" / "final_dataset" / "match_wide.parquet",
            self.data_dir / "curated" / "final_dataset" / "facts" / "fact_lineups.parquet",
        ]:
            if path.exists():
                try:
                    df = pd.read_parquet(path)
                    if "match_id" in df.columns:
                        ids.update(df["match_id"].dropna().astype(str).tolist())
                except Exception:
                    pass
        for path in self.data_dir.joinpath("raw", "fbref").rglob("match_bundle.parquet"):
            try:
                df = pd.read_parquet(path)
                if "match_id" in df.columns:
                    ids.update(df["match_id"].dropna().astype(str).tolist())
            except Exception:
                pass
        return ids

    def _save_processed_match_ids(self, ids: set[str]) -> None:
        ck = self._fbref_checkpoint_path()
        ck.write_text(pd.Series({"processed_match_ids": sorted(ids)}).to_json(), encoding="utf-8")

    def _competition_url(self, league: str) -> str | None:
        meta = FBREF_COMPETITIONS.get(league)
        if meta is None:
            self.logger.warning("Liga no mapeada para FBref: %s", league)
            return None
        return f"https://fbref.com/en/comps/{meta['comp_id']}/{meta['slug']}-Stats"

    def _season_base_url(self, league: str, season_label: str) -> str | None:
        meta = FBREF_COMPETITIONS.get(league)
        if meta is None:
            return None
        return f"https://fbref.com/en/comps/{meta['comp_id']}/{season_label}/{season_label}-{meta['slug']}-Stats"

    def _page_url(self, league: str, season_label: str, page: str) -> str | None:
        base = self._season_base_url(league, season_label)
        if base is None:
            return None
        if page == "overview":
            return base
        if page == "schedule":
            meta = FBREF_COMPETITIONS.get(league)
            if meta is None:
                return None
            return f"https://fbref.com/en/comps/{meta['comp_id']}/{season_label}/schedule/{season_label}-{meta['slug']}-Scores-and-Fixtures"
        return base.replace(f"/{season_label}-", f"/{page}/{season_label}-")

    def _wait_for_real_page(self, driver) -> None:
        # Let the page breathe and re-check a couple of times if Cloudflare/cookie interstitials show up.
        for _ in range(4):
            title = (driver.title or "").lower()
            body = ""
            try:
                body = driver.find_element(By.TAG_NAME, "body").text.lower()
            except Exception:
                pass
            if "un momento" not in title and "just a moment" not in title and "un momento" not in body and "just a moment" not in body:
                return
            self.logger.info("FBref todavía en interstitial; esperando %ss", self.wait_seconds)
            driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            driver.refresh()
            time.sleep(self.wait_seconds)

    def _try_select_season(self, driver, season_label: str) -> bool:
        selectors = ["select"]
        for css in selectors:
            try:
                selects = driver.find_elements(By.CSS_SELECTOR, css)
            except Exception:
                continue
            for element in selects:
                try:
                    sel = Select(element)
                    options = [opt.text.strip() for opt in sel.options]
                    for opt in options:
                        if season_label in opt:
                            sel.select_by_visible_text(opt)
                            return True
                except Exception:
                    continue
        return False

    def _navigate_to_schedule_month(self, driver, season_label: str) -> None:
        try:
            if not self.leagues:
                return
            url = self._page_url(self.leagues[0], season_label, "schedule")
            if url is None:
                return
            driver.get(url)
        except Exception:
            return

        try:
            self._wait_for_real_page(driver)
        except Exception:
            pass

        # Use FBref's built-in month selector if present.
        for _ in range(18):
            try:
                month_controls = driver.find_elements(By.CSS_SELECTOR, "div.section_heading a, div.section_heading button, div#switcher_schedule .dropdown, button[data-month]")
            except Exception:
                month_controls = []
            if month_controls:
                break
            time.sleep(1)

        current_html = driver.page_source
        if season_label in current_html:
            return

        # Fallback: try to click date controls if they exist.
        for _ in range(24):
            try:
                next_btns = driver.find_elements(By.XPATH, "//button[contains(., 'Next') or contains(@aria-label, 'Next')]")
            except Exception:
                next_btns = []
            if not next_btns:
                break
            try:
                driver.execute_script("arguments[0].click();", next_btns[0])
            except Exception:
                break
            time.sleep(2)

    def _extract_schedule_rows_from_html(self, html: str, league: str, season_label: str) -> pd.DataFrame:
        tables = self._parse_tables_with_ids(html)
        schedule_df = tables.get("sched") or tables.get("schedule")
        if schedule_df is None or schedule_df.empty:
            schedule_df = self._parse_tables(html).get("schedule", pd.DataFrame())
        if schedule_df is None or schedule_df.empty:
            return pd.DataFrame()
        out = schedule_df.copy()
        out = out.rename(columns={c: str(c).strip() for c in out.columns})
        out["league"] = league
        out["season"] = season_label
        if "Match Report" in out.columns and "match_report_url" not in out.columns:
            out["match_report_url"] = out["Match Report"].map(lambda v: urljoin("https://fbref.com", str(v)) if str(v).startswith("/") else v)
        if "Home" in out.columns and "home_team" not in out.columns:
            out["home_team"] = out["Home"]
        if "Away" in out.columns and "away_team" not in out.columns:
            out["away_team"] = out["Away"]
        if "Date" in out.columns and "date" not in out.columns:
            out["date"] = pd.to_datetime(out["Date"], errors="coerce").dt.strftime("%Y-%m-%d")
        if "Score" in out.columns and "score" not in out.columns:
            out["score"] = out["Score"]
        if "match_id" not in out.columns:
            out["match_id"] = out["match_report_url"].map(lambda v: self._match_id_from_url(str(v)) if pd.notna(v) and str(v).strip() else None)
        return out

    def _parse_tables(self, html: str) -> dict[str, pd.DataFrame]:
        try:
            tables = pd.read_html(StringIO(html))
        except ValueError:
            return {}

        parsed = []
        for i, df in enumerate(tables):
            if df is None or df.empty:
                continue
            parsed.append((i, df))

        schedule_frames = []
        stats_frames = []
        for i, df in parsed:
            cols = [str(c).lower() for c in df.columns]
            if {"date", "home", "away"}.issubset(set(cols)) or ("date" in cols and ("score" in cols or "result" in cols)):
                out = df.copy()
                out["_fbref_table_idx"] = i
                schedule_frames.append(out)
                continue

            if any(c in cols for c in ["squad", "team", "player"]):
                out = df.copy()
                out["_fbref_table_idx"] = i
                stats_frames.append(out)

        return {
            "schedule": pd.concat(schedule_frames, ignore_index=True) if schedule_frames else pd.DataFrame(),
            "team_match_stats": pd.concat(stats_frames, ignore_index=True) if stats_frames else pd.DataFrame(),
            "shot_events": pd.DataFrame(),
            "events": pd.DataFrame(),
            "lineup": pd.DataFrame(),
        }

    def _parse_tables_with_ids(self, html: str) -> dict[str, pd.DataFrame]:
        soup = BeautifulSoup(html, "html.parser")
        out: dict[str, pd.DataFrame] = {}
        for table_node in soup.find_all("table"):
            table_any: Any = table_node
            attrs = getattr(table_any, "attrs", {})
            table_id = cast(str | None, attrs.get("id") if isinstance(attrs, dict) else None)
            if not table_id:
                continue
            try:
                parsed = pd.read_html(StringIO(str(table_any)))[0]
            except Exception:
                continue
            if parsed is None or parsed.empty:
                continue
            out[table_id] = parsed
        return out

    def _sanitize_name(self, value: str) -> str:
        return re.sub(r"[^A-Za-z0-9_.-]+", "_", value).strip("_")

    def _match_id_from_url(self, url: str) -> str:
        digest = sha1(url.encode("utf-8")).hexdigest()[:12]
        return f"fbref_{digest}"

    def _load_or_scrape(self, driver, url: str, cache_path: Path) -> str:
        if not self.no_cache and cache_path.exists():
            cached = cache_path.read_text(encoding="utf-8", errors="ignore")
            if len(cached) > 5000 and ("fbref" in cached.lower() or "data-stat" in cached.lower()):
                return cached
        driver.get(url)
        WebDriverWait(driver, self.wait_seconds).until(EC.presence_of_element_located((By.TAG_NAME, "body")))
        self._wait_for_real_page(driver)
        html = driver.page_source
        self._save_html(cache_path, html)
        return html

    def _flatten_columns(self, df: pd.DataFrame) -> pd.DataFrame:
        out = df.copy()
        if isinstance(out.columns, pd.MultiIndex):
            out.columns = ["_".join([str(x) for x in col if str(x) != "Unnamed: 0_level_0"]).strip("_") for col in out.columns]
        out.columns = [self._sanitize_name(str(c)).lower() for c in out.columns]
        return out

    def _extract_team_summary(self, html: str, match_id: str, home_team: str | None, away_team: str | None) -> pd.DataFrame:
        tables = pd.read_html(StringIO(html))
        if len(tables) <= 11:
            return pd.DataFrame()
        df = tables[11].copy()
        if df.empty:
            return pd.DataFrame()
        home_col, away_col = df.columns[:2]
        rows = []
        metric_pairs = [
            (0, "possession"),
            (2, "shots_on_target"),
            (4, "saves"),
            (6, "cards"),
        ]
        for idx, metric in metric_pairs:
            if idx >= len(df):
                continue
            rows.append({
                "match_id": match_id,
                "home_team": home_team,
                "away_team": away_team,
                "metric": metric,
                "home_value": df.iloc[idx, 0],
                "away_value": df.iloc[idx, 1],
            })
        return pd.DataFrame(rows)

    def _extract_match_entities(self, html: str, match_id: str, home_team: str | None, away_team: str | None) -> dict[str, pd.DataFrame]:
        tables = pd.read_html(StringIO(html))
        soup = BeautifulSoup(html, "html.parser")
        table_nodes = list(soup.find_all("table"))

        lineups_rows: list[dict[str, Any]] = []
        player_rows: list[dict[str, Any]] = []
        keeper_rows: list[dict[str, Any]] = []
        officials_rows: list[dict[str, Any]] = []

        officials_text = ""
        officials_node = soup.find(string=re.compile(r"Officials", re.I))
        if officials_node is not None:
            parent = getattr(officials_node, "parent", None)
            officials_text = parent.get_text(" ", strip=True) if parent is not None else str(officials_node)
        if officials_text:
            referee_match = re.search(r"([A-Za-zÀ-ÿ'\-\. ]+)\s*\(Referee\)", officials_text)
            if referee_match:
                officials_rows.append({
                    "match_id": match_id,
                    "role": "referee",
                    "name": referee_match.group(1).replace("\xa0", " ").strip(),
                    "raw_text": officials_text,
                })

        lineup_tables = []
        for i, t in enumerate(table_nodes):
            t_any: Any = t
            if t_any.get("id") is None and i in (9, 10):
                lineup_tables.append(i)
        for idx, table_idx in enumerate(lineup_tables):
            if table_idx >= len(tables):
                continue
            df = tables[table_idx].copy()
            if df.empty or df.shape[1] < 2:
                continue
            team = home_team if idx == 0 else away_team
            for _, row in df.iterrows():
                player = str(row.iloc[1]).strip()
                shirt = str(row.iloc[0]).strip()
                if player.lower() == "bench" or shirt.lower() == "bench":
                    continue
                lineups_rows.append({
                    "match_id": match_id,
                    "team": team,
                    "player": player,
                    "shirt_number": shirt,
                    "lineup_side": "home" if idx == 0 else "away",
                    "entity_type": "lineup",
                })

        # Player / keeper tables are the last four id'd tables in this match page.
        player_team_index = 0
        keeper_team_index = 0
        for table_idx, table_node in enumerate(table_nodes):
            table_id = cast(str | None, getattr(table_node, "attrs", {}).get("id") if hasattr(table_node, "attrs") else None)
            if not table_id:
                continue
            if table_id.startswith("stats_") and table_id.endswith("_summary"):
                df = self._flatten_columns(tables[table_idx])
                team = home_team if player_team_index == 0 else away_team
                player_team_index += 1
                for _, row in df.iterrows():
                    player_rows.append({"match_id": match_id, "team": team, "entity_type": "player", **row.to_dict()})
            elif table_id.startswith("keeper_stats_"):
                df = self._flatten_columns(tables[table_idx])
                team = home_team if keeper_team_index == 0 else away_team
                keeper_team_index += 1
                for _, row in df.iterrows():
                    keeper_rows.append({"match_id": match_id, "team": team, "entity_type": "keeper", **row.to_dict()})

        return {
            "match_lineups": pd.DataFrame(lineups_rows),
            "match_player_stats": pd.DataFrame(player_rows),
            "match_keeper_stats": pd.DataFrame(keeper_rows),
            "match_officials": pd.DataFrame(officials_rows),
        }

    def _write_table_artifact(self, league: str, season_label: str, page: str, table_id: str, df: pd.DataFrame) -> Path:
        out_dir = self.data_dir / "raw" / "fbref" / self._sanitize_name(league) / season_label / page
        out_dir.mkdir(parents=True, exist_ok=True)
        out_path = out_dir / f"{self._sanitize_name(table_id)}.csv"
        return out_path

    def _route_page_tables(self, page: str, table_id: str, df: pd.DataFrame, outputs: dict[str, list[pd.DataFrame]], league: str, season_label: str, source_url: str) -> None:
        named = df.copy()
        named["league"] = league
        named["season"] = season_label
        named["source_url"] = source_url
        named["table_id"] = table_id
        outputs.setdefault(f"{page}__{table_id}", []).append(named)

        if page == "overview":
            if table_id == "schedule":
                outputs.setdefault("schedule", []).append(named)
                return
            if table_id == "team_match_stats":
                outputs.setdefault("team_match_stats", []).append(named)
                return
            if "results" in table_id and table_id.endswith("overall"):
                outputs.setdefault("schedule", []).append(named)
            elif "results" in table_id and table_id.endswith("home_away"):
                outputs.setdefault("home_away_results", []).append(named)
            elif table_id.startswith("stats_squads_"):
                outputs.setdefault("team_season_stats", []).append(named)
        else:
            if table_id == "schedule":
                outputs.setdefault("schedule", []).append(named)
                return
            if table_id == "team_match_stats":
                outputs.setdefault("team_match_stats", []).append(named)
                return
            if table_id == "stats_standard":
                outputs.setdefault("player_season_stats_standard", []).append(named)
            elif table_id == "stats_passing":
                outputs.setdefault("player_season_stats_passing", []).append(named)
            elif table_id == "stats_passing_types":
                outputs.setdefault("player_season_stats_passing_types", []).append(named)
            elif table_id == "stats_goal_shot_creation":
                outputs.setdefault("player_season_stats_goal_shot_creation", []).append(named)
            elif table_id == "stats_defense":
                outputs.setdefault("player_season_stats_defense", []).append(named)
            elif table_id == "stats_possession":
                outputs.setdefault("player_season_stats_possession", []).append(named)
            elif table_id == "stats_keeper":
                outputs.setdefault("player_season_stats_keeper", []).append(named)
            elif table_id == "stats_keeper_adv":
                outputs.setdefault("player_season_stats_keeper_adv", []).append(named)
            elif table_id == "stats_shooting":
                outputs.setdefault("player_season_stats_shooting", []).append(named)
            elif table_id == "stats_playing_time":
                outputs.setdefault("player_season_stats_playing_time", []).append(named)
            elif table_id == "stats_misc":
                outputs.setdefault("player_season_stats_misc", []).append(named)
            elif table_id.startswith("stats_squads_"):
                outputs.setdefault("team_season_stats", []).append(named)

    def _season_cache_dir(self, league: str, season_label: str) -> Path:
        safe_league = league.replace("/", "-").replace(" ", "_")
        path = self.cache_html_dir / safe_league / season_label
        path.mkdir(parents=True, exist_ok=True)
        return path

    def _save_html(self, path: Path, html: str) -> None:
        path.write_text(html, encoding="utf-8", errors="ignore")

    def _extract_match_urls(self, html: str) -> list[str]:
        hrefs = re.findall(r'href="([^"]*?/en/matches/\d+/[^"]+)"', html)
        urls: list[str] = []
        seen: set[str] = set()
        for href in hrefs:
            url = urljoin("https://fbref.com", href)
            if url in seen:
                continue
            seen.add(url)
            urls.append(url)
        return urls

    def _extract_schedule_rows(self, html: str) -> pd.DataFrame:
        soup = BeautifulSoup(html, "html.parser")
        table_any: Tag | None = cast(Tag | None, soup.find("table", id=re.compile(r"^sched_")))
        if table_any is None:
            return pd.DataFrame()

        try:
            parsed = pd.read_html(StringIO(str(table_any)))[0]
        except Exception:
            return pd.DataFrame()

        rows: list[dict[str, Any]] = []
        tbody_any: Tag | None = cast(Tag | None, table_any.find("tbody"))
        if tbody_any is None:
            return parsed

        for idx, tr_any in enumerate(cast(list[Tag], tbody_any.find_all("tr"))):
            row: dict[str, Any] = parsed.iloc[idx].to_dict() if idx < len(parsed) else {}
            match_report = None
            match_report_cell = cast(Tag | None, tr_any.find(attrs={"data-stat": "match_report"}))
            if match_report_cell is not None:
                match_report = match_report_cell.find("a", href=True)
            if match_report is None:
                links = [cast(Tag, a) for a in tr_any.find_all("a", href=True)]
                match_report = next((a for a in links if a.get_text(" ", strip=True) == "Match Report"), None)
            if match_report is None:
                links = [cast(Tag, a) for a in tr_any.find_all("a", href=True)]
                match_report = next(
                    (
                        a
                        for a in links
                        if "/en/matches/" in str(cast(Any, a).get("href", "")) and not re.search(r"/en/matches/\d{4}-\d{2}-\d{2}$", str(cast(Any, a).get("href", "")))
                    ),
                    None,
                )
            if match_report is not None:
                row["match_report_url"] = urljoin("https://fbref.com", str(cast(Any, match_report).get("href", "")))
            rows.append(row)

        if not rows:
            return parsed
        return pd.DataFrame(rows)

    def _extract_referee_from_match_html(self, html: str) -> str | None:
        soup = BeautifulSoup(html, "html.parser")
        for strong in soup.find_all("strong"):
            label = strong.get_text(" ", strip=True).lower()
            if label == "officials":
                parent = strong.parent
                if parent is None:
                    continue
                text = parent.get_text(" ", strip=True)
                m = re.search(r"Officials\s*:\s*([^\(]+?)\s*\(Referee\)", text, re.I)
                if m:
                    return m.group(1).strip().replace("\xa0", " ")
        m = re.search(r"Officials\s*:\s*([^\(]+?)\s*\(Referee\)", html, re.I)
        return m.group(1).strip() if m else None

    def collect(self, **kwargs: Any) -> dict[str, pd.DataFrame]:
        driver = self.session.build_driver()
        skip_processed_match_ids = bool(kwargs.get("skip_processed_match_ids", True))
        try:
            outputs: dict[str, list[pd.DataFrame]] = {
                "schedule_matches": [],
                "schedule": [],
                "home_away_results": [],
                "team_season_stats": [],
                "player_season_stats_standard": [],
                "player_season_stats_passing": [],
                "player_season_stats_passing_types": [],
                "player_season_stats_goal_shot_creation": [],
                "player_season_stats_defense": [],
                "player_season_stats_possession": [],
                "player_season_stats_keeper": [],
                "player_season_stats_keeper_adv": [],
                "player_season_stats_shooting": [],
                "player_season_stats_playing_time": [],
                "player_season_stats_misc": [],
                "match_team_summary": [],
                "match_player_stats": [],
                "match_keeper_stats": [],
                "match_lineups": [],
                "match_officials": [],
                "match_bundle": [],
            }

            for league in self.leagues:
                for season in self.seasons:
                    season_label = _season_label(season)
                    season_cache_dir = self._season_cache_dir(league, season_label)
                    for page in ["overview", "stats", "passing", "passing_types", "goal_shot_creation", "defense", "possession", "keepers", "keeper_adv", "shooting", "playingtime", "misc"]:
                        url = self._page_url(league, season_label, page)
                        if url is None:
                            continue

                        self.logger.info("Abriendo FBref page=%s %s", page, url)
                        html = self._load_or_scrape(driver, url, season_cache_dir / f"{page}.html")
                        self._save_html(season_cache_dir / f"{page}.html", html)
                        table_map = self._parse_tables_with_ids(html)
                        if not table_map:
                            legacy_tables = self._parse_tables(html)
                            for legacy_name in ["schedule", "team_match_stats"]:
                                legacy_df = legacy_tables.get(legacy_name)
                                if legacy_df is not None and not legacy_df.empty:
                                    self._route_page_tables(page, legacy_name, legacy_df, outputs, league, season_label, driver.current_url)
                        for table_id, df in table_map.items():
                            table_path = self._write_table_artifact(league, season_label, page, table_id, df)
                            self.logger.info("Guardado %s (%s filas) en %s", table_id, len(df), table_path)
                            self._route_page_tables(page, table_id, df, outputs, league, season_label, driver.current_url)

                    schedule_url = self._page_url(league, season_label, "schedule")
                    if schedule_url is not None:
                        self.logger.info("Abriendo FBref page=schedule %s", schedule_url)
                        schedule_html = self._load_or_scrape(driver, schedule_url, season_cache_dir / "schedule.html")
                        schedule_rows = self._extract_schedule_rows(schedule_html)
                        if not schedule_rows.empty and "match_report_url" in schedule_rows.columns:
                            schedule_rows = schedule_rows.copy()
                            schedule_rows["match_report_url"] = schedule_rows["match_report_url"].astype(str).str.strip()
                            schedule_rows = schedule_rows[schedule_rows["match_report_url"].str.startswith("https://fbref.com/en/matches/")].copy()
                            schedule_rows = schedule_rows.drop_duplicates(subset=["match_report_url"], keep="first")
                        if season_label == "2025-2026":
                            seen_urls: set[str] = set()
                            if not schedule_rows.empty and "match_report_url" in schedule_rows.columns:
                                seen_urls.update(schedule_rows["match_report_url"].dropna().astype(str).tolist())

                            def _append_rows_from_current_page() -> None:
                                nonlocal schedule_rows, seen_urls
                                current_rows = self._extract_schedule_rows_from_html(driver.page_source, league, season_label)
                                if current_rows.empty:
                                    return
                                if "match_report_url" in current_rows.columns:
                                    current_rows = current_rows[~current_rows["match_report_url"].astype(str).isin(list(seen_urls))].copy()
                                    seen_urls.update(current_rows["match_report_url"].dropna().astype(str).tolist())
                                if not current_rows.empty:
                                    schedule_rows = pd.concat([schedule_rows, current_rows], ignore_index=True) if not schedule_rows.empty else current_rows

                            _append_rows_from_current_page()
                            for direction in ["prev", "next"]:
                                for _ in range(24):
                                    try:
                                        btns = driver.find_elements(By.XPATH, "//button[contains(., 'Next') or contains(@aria-label, 'Next') or contains(., 'Previous') or contains(@aria-label, 'Previous') or contains(., 'Prev') or contains(@aria-label, 'Prev')]")
                                    except Exception:
                                        btns = []
                                    if not btns:
                                        break
                                    candidates = [b for b in btns if direction == "next" and ("next" in (b.get_attribute("aria-label") or "").lower() or "next" in (b.text or "").lower()) or direction == "prev" and ("prev" in (b.get_attribute("aria-label") or "").lower() or "prev" in (b.text or "").lower() or "previous" in (b.get_attribute("aria-label") or "").lower() or "previous" in (b.text or "").lower())]
                                    if not candidates:
                                        break
                                    btn = candidates[0]
                                    if btn.get_attribute("disabled"):
                                        break
                                    try:
                                        driver.execute_script("arguments[0].click();", btn)
                                    except Exception:
                                        break
                                    time.sleep(2)
                                    _append_rows_from_current_page()

                        if not schedule_rows.empty:
                            schedule_rows = schedule_rows.copy()
                            schedule_rows["match_id"] = schedule_rows["match_report_url"].fillna("").map(lambda u: self._match_id_from_url(str(u)) if u else None)
                            schedule_rows["league"] = league
                            schedule_rows["season"] = season_label
                            schedule_rows["source_url"] = driver.current_url
                            outputs["schedule_matches"].append(schedule_rows)

                            processed_match_ids = self._load_processed_match_ids() if skip_processed_match_ids else set()
                            if skip_processed_match_ids and processed_match_ids:
                                schedule_rows = schedule_rows[~schedule_rows["match_id"].astype(str).isin(list(processed_match_ids))].copy()
                            season_rows = schedule_rows if not self.max_matches_per_season or self.max_matches_per_season <= 0 else schedule_rows.head(self.max_matches_per_season)
                            for match_num, (_, row) in enumerate(season_rows.iterrows(), start=1):
                                match_url = row.get("match_report_url")
                                if not match_url or pd.isna(match_url):
                                    continue
                                match_url = str(match_url).strip()
                                if match_url == "Match Report" or "match report" in match_url.lower():
                                    continue
                                if not re.search(r"/en/matches/\d+/", match_url):
                                    continue
                                if match_url.startswith("/en/matches/"):
                                    match_url = urljoin("https://fbref.com", match_url)
                                elif "/en/matches/" in match_url and not match_url.startswith("http"):
                                    match_url = urljoin("https://fbref.com", match_url)
                                match_id = str(row.get("match_id") or self._match_id_from_url(str(match_url)))
                                if match_id in processed_match_ids:
                                    continue
                                match_cache = season_cache_dir / f"match_{match_num:02d}.html"
                                self.logger.info("Abriendo FBref match %s", match_url)
                                match_html = self._load_or_scrape(driver, str(match_url), match_cache)
                                match_referee = self._extract_referee_from_match_html(match_html)
                                canonical_referee = match_referee if match_referee and " " in match_referee else str(row.get("Referee") or match_referee or "")
                                match_entities = self._extract_match_entities(match_html, match_id, str(row.get("Home")), str(row.get("Away")))
                                team_summary = self._extract_team_summary(match_html, match_id, str(row.get("Home")), str(row.get("Away")))

                                if not team_summary.empty:
                                    outputs["match_team_summary"].append(team_summary)
                                for k, entity_df in match_entities.items():
                                    if not entity_df.empty:
                                        outputs[k].append(entity_df)
                                if match_entities["match_officials"].empty and canonical_referee:
                                    outputs["match_officials"].append(
                                        pd.DataFrame(
                                            [{"match_id": match_id, "role": "referee", "name": canonical_referee, "raw_text": "schedule_referee"}]
                                        )
                                    )

                                outputs.setdefault("match_pages", []).append(
                                    pd.DataFrame(
                                        [
                                            {
                                                "match_id": match_id,
                                                "league": league,
                                                "season": season_label,
                                                "match_report_url": match_url,
                                                "cache_path": str(match_cache),
                                                "page_title": driver.title,
                                                "source_url": driver.current_url,
                                                "html_length": len(match_html),
                                                "referee": canonical_referee,
                                                "referee_from_schedule": row.get("Referee"),
                                                "home": row.get("Home"),
                                                "away": row.get("Away"),
                                                "score": row.get("Score"),
                                            }
                                        ]
                                    )
                                )

                                outputs["match_bundle"].append(
                                    pd.DataFrame(
                                        [
                                            {
                                                "match_id": match_id,
                                                "league": league,
                                                "season": season_label,
                                                "match_report_url": match_url,
                                                "home_team": row.get("Home"),
                                                "away_team": row.get("Away"),
                                                "referee": canonical_referee,
                                                "source_schedule_referee": row.get("Referee"),
                                                "source_html_path": str(match_cache),
                                                "team_summary_rows": 0 if team_summary.empty else len(team_summary),
                                                "player_rows": 0 if match_entities["match_player_stats"].empty else len(match_entities["match_player_stats"]),
                                                "keeper_rows": 0 if match_entities["match_keeper_stats"].empty else len(match_entities["match_keeper_stats"]),
                                                "lineup_rows": 0 if match_entities["match_lineups"].empty else len(match_entities["match_lineups"]),
                                            }
                                        ]
                                    )
                                )

                                processed_match_ids.add(match_id)
                                self._save_processed_match_ids(processed_match_ids)

            return {k: pd.concat(v, ignore_index=True) if v else pd.DataFrame() for k, v in outputs.items()}
        finally:
            try:
                driver.quit()
            except Exception:
                pass
