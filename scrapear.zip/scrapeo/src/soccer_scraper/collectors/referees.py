from __future__ import annotations

import json
import ssl
import re
import unicodedata
from dataclasses import dataclass
from datetime import datetime, timezone
from difflib import SequenceMatcher
from hashlib import sha1
from pathlib import Path
from typing import Any
from urllib.parse import quote_plus
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

import pandas as pd
from bs4 import BeautifulSoup

from soccer_scraper.collectors.base import BaseCollector
from soccer_scraper.utils.io import ensure_dir, read_table_if_exists, write_csv, write_parquet


PARSER_VERSION = "referee-1"


def _stable_id(*parts: Any) -> str:
    raw = "|".join("" if p is None else str(p) for p in parts)
    return f"ref_{sha1(raw.encode('utf-8')).hexdigest()[:16]}"


def normalize_name(value: Any) -> str:
    text = str(value or "").strip().lower()
    text = unicodedata.normalize("NFKD", text)
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"[^a-z0-9 ]+", "", text)
    return text.strip()


def _safe_text(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _load_latest_table(root: Path, filename: str) -> pd.DataFrame:
    candidates = [p for p in root.rglob(filename) if p.is_file()]
    if not candidates:
        return pd.DataFrame()
    latest = max(candidates, key=lambda p: p.stat().st_mtime)
    df = read_table_if_exists(latest)
    return df if df is not None else pd.DataFrame()


def _latest_fbref_run(raw_dir: Path) -> Path | None:
    runs = [p for p in (raw_dir / "fbref").glob("run_id=*") if p.is_dir()]
    if not runs:
        return None
    return max(runs, key=lambda p: p.stat().st_mtime)


def _latest_referee_run(raw_dir: Path) -> Path | None:
    runs = [p for p in (raw_dir / "referees").glob("run_id=*") if p.is_dir()]
    if not runs:
        return None
    return max(runs, key=lambda p: p.stat().st_mtime)


def _load_whoscored_stage_catalog(cache_root: Path) -> list[dict[str, Any]]:
    candidates = [
        cache_root / "WhoScored" / "seasons",
        cache_root / "seasons",
        cache_root.parent / "html" / "whoscored" / "seasons",
    ]
    season_dir = next((p for p in candidates if p.exists()), None)
    if season_dir is None:
        return []

    catalog: list[dict[str, Any]] = []
    for path in season_dir.glob("*.html"):
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue

        def _grab(pattern: str) -> str | None:
            m = re.search(pattern, text, re.I)
            return m.group(1) if m else None

        referee_link = _grab(r"refereestatistics/([^'\"\s>]+)")
        region_id = _grab(r"regionId\s*[:=]\s*(\d+)")
        tournament_id = _grab(r"tournamentId\s*[:=]\s*(\d+)")
        season_id = _grab(r"seasonId\s*[:=]\s*(\d+)")
        stage_id = _grab(r"stageId\s*[:=]\s*(\d+)")
        if not stage_id:
            continue
        catalog.append(
            {
                "path": path,
                "referee_link": referee_link,
                "region_id": region_id,
                "tournament_id": tournament_id,
                "season_id": season_id,
                "stage_id": stage_id,
                "slug": referee_link or path.stem,
                "normalized_slug": normalize_name(referee_link or path.stem),
            }
        )
    return catalog


def _pick_stage(catalog: list[dict[str, Any]], league: str | None, season: str | None) -> dict[str, Any] | None:
    if not catalog:
        return None
    league_norm = normalize_name(league)
    season_norm = normalize_name(season)
    scored: list[tuple[int, dict[str, Any]]] = []
    for item in catalog:
        score = 0
        slug = item.get("normalized_slug", "")
        file_name = normalize_name(item["path"].stem)
        if league_norm and league_norm in slug:
            score += 4
        if league_norm and league_norm in file_name:
            score += 4
        if season_norm and season_norm.replace("_", "") in slug.replace("_", ""):
            score += 2
        if season_norm and season_norm.replace("_", "") in file_name.replace("_", ""):
            score += 2
        scored.append((score, item))
    scored.sort(key=lambda x: x[0], reverse=True)
    best_score, best_item = scored[0]
    return best_item if best_score > 0 else catalog[0]


def _parse_fbref_officials(match_officials: pd.DataFrame, match_bundle: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    if match_officials.empty:
        return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

    bundle_lookup = {}
    if not match_bundle.empty and "match_id" in match_bundle.columns:
        bundle_lookup = match_bundle.drop_duplicates(subset=["match_id"]).set_index("match_id").to_dict(orient="index")

    dim_rows: dict[str, dict[str, Any]] = {}
    match_rows: list[dict[str, Any]] = []
    manifest_rows: list[dict[str, Any]] = []

    for _, row in match_officials.iterrows():
        match_id = _safe_text(row.get("match_id"))
        official_name_raw = _safe_text(row.get("name") or row.get("referee_name"))
        role = _safe_text(row.get("role")) or "referee"
        if not match_id or not official_name_raw:
            continue

        official_name_normalized = normalize_name(official_name_raw)
        official_id = _stable_id("fbref", official_name_normalized, role)
        match_info = bundle_lookup.get(match_id, {})
        match_url = _safe_text(match_info.get("match_report_url") or row.get("match_report_url") or match_info.get("source_url"))
        league = _safe_text(row.get("league") or match_info.get("league"))
        season = _safe_text(row.get("season") or match_info.get("season"))

        dim_rows.setdefault(
            official_id,
            {
                "official_id": official_id,
                "official_name": official_name_raw,
                "official_name_raw": official_name_raw,
                "official_name_normalized": official_name_normalized,
                "fbref_name": official_name_raw,
                "whoscored_name": None,
                "fbref_url": match_url,
                "whoscored_url": None,
                "country": None,
                "match_confidence": 1.0,
                "identity_review_needed": False,
                "created_at": datetime.now(timezone.utc).isoformat(),
                "updated_at": datetime.now(timezone.utc).isoformat(),
            },
        )

        match_rows.append(
            {
                "official_id": official_id,
                "match_id": match_id,
                "competition": league,
                "season": season,
                "source": "fbref",
                "source_url": match_url,
                "role": role,
                "official_name_raw": official_name_raw,
                "official_name_normalized": official_name_normalized,
                "yellow_cards_total": None,
                "red_cards_total": None,
                "fouls_total": None,
                "penalties_awarded_total": None,
                "run_id": row.get("run_id"),
                "scraped_at": row.get("scraped_at") or datetime.now(timezone.utc).isoformat(),
                "parser_version": PARSER_VERSION,
                "parse_success": bool(row.get("parse_success", True)),
                "data_complete": False,
                "validation_status": "ok",
            }
        )

        manifest_rows.append(
            {
                "official_id": official_id,
                "source": "fbref",
                "status": "cached",
                "cache_path": None,
                "scraped_at": row.get("scraped_at") or datetime.now(timezone.utc).isoformat(),
                "run_id": row.get("run_id"),
                "parser_version": PARSER_VERSION,
                "source_url": match_url,
            }
        )

    dim = pd.DataFrame(dim_rows.values()).drop_duplicates(subset=["official_id"]).reset_index(drop=True)
    match_fact = pd.DataFrame(match_rows).drop_duplicates(subset=["official_id", "match_id", "source"]).reset_index(drop=True)
    manifest = pd.DataFrame(manifest_rows)
    return dim, match_fact, manifest


def _fetch_url(url: str) -> str:
    req = Request(
        url,
        headers={
            "User-Agent": "Mozilla/5.0",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
        },
    )
    with urlopen(req, timeout=30, context=ssl._create_unverified_context()) as response:
        raw = response.read()
    return raw.decode("utf-8", errors="ignore")


def _fetch_refereesfeed(url: str) -> tuple[str | None, str]:
    try:
        return _fetch_url(url), "ok"
    except (HTTPError, URLError, TimeoutError, Exception) as exc:
        return None, f"error:{exc.__class__.__name__}"


def _resolve_whoscored_url(template: str, official_name_raw: str, official_name_normalized: str, official_id: str) -> str:
    return template.format(
        official_name_raw=quote_plus(official_name_raw),
        official_name_normalized=quote_plus(official_name_normalized),
        official_id=official_id,
    )


def _build_refereesfeed_url(stage_id: str, fetch_url_segment: str = "TournamentStatsByReferee") -> str:
    return f"https://www.whoscored.com/refereesfeed/{stage_id}/{fetch_url_segment.lower()}?fieldString=Overall"


def _build_refereesfeed_url_from_template(template: str, stage_id: str) -> str:
    return template.format(stage_id=stage_id)


def _parse_refereesfeed_payload(text: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    stripped = text.strip()
    if not stripped:
        return pd.DataFrame(), pd.DataFrame()

    if stripped.startswith("{") or stripped.startswith("["):
        try:
            payload = json.loads(stripped)
        except Exception:
            payload = None
        if isinstance(payload, dict):
            rows = payload.get("statisticsByReferee") or payload.get("statisticsByTournament") or []
            return pd.DataFrame(rows), pd.DataFrame([payload])
        if isinstance(payload, list):
            return pd.DataFrame(payload), pd.DataFrame()

    tables = []
    try:
        tables = pd.read_html(text)
    except Exception:
        tables = []

    if not tables:
        return pd.DataFrame(), pd.DataFrame()

    df = tables[0].copy()
    df.columns = [normalize_name(c) for c in df.columns]
    return df, pd.DataFrame()


def _parse_whoscored_stats_html(html: str, official_id: str, official_name_hint: str | None = None) -> tuple[pd.DataFrame, pd.DataFrame]:
    soup = BeautifulSoup(html, "html.parser")
    tables = []
    try:
        tables = pd.read_html(html)
    except Exception:
        tables = []

    dim_row: dict[str, Any] = {
        "official_id": official_id,
        "whoscored_name": official_name_hint,
        "whoscored_url": None,
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }

    stats_rows: list[dict[str, Any]] = []
    for table in tables:
        if table.empty:
            continue
        normalized = table.copy()
        normalized.columns = [str(c).strip() for c in normalized.columns]
        cols = {normalize_name(c): c for c in normalized.columns}
        metric_map = {
            "matches_officiated": ["matches_officiated", "matches", "games"],
            "fouls_pg": ["fouls_pg", "fouls per game", "fouls per match"],
            "pen_pg": ["pen_pg", "penalties per game", "penalties"],
            "yellow_cards_pg": ["yellow_cards_pg", "yellows per game", "yellow cards per game"],
            "yellow_cards_total": ["yellow_cards_total", "yellow cards"],
            "red_cards_pg": ["red_cards_pg", "red cards per game"],
            "red_cards_total": ["red_cards_total", "red cards"],
            "second_yellow_red_total": ["second_yellow_red_total", "second yellow red"],
            "fouls_per_tackle": ["fouls_per_tackle", "fouls per tackle"],
        }

        row: dict[str, Any] = {}
        for target, aliases in metric_map.items():
            for alias in aliases:
                if alias in cols:
                    value = normalized.iloc[0][cols[alias]]
                    row[target] = value
                    break
            if target not in row:
                row[target] = None

        if any(v is not None and str(v).strip() != "" for v in row.values()):
            stats_rows.append(row)
            break

    stats_df = pd.DataFrame(stats_rows)
    return pd.DataFrame([dim_row]), stats_df


def _normalize_competition(value: Any) -> str:
    return normalize_name(value).replace("_", " ")


def _find_name_column(df: pd.DataFrame) -> str | None:
    if df.empty:
        return None
    candidates = [c for c in df.columns if normalize_name(c) in {"referee", "name", "official", "official_name", "player"}]
    return candidates[0] if candidates else (df.columns[0] if len(df.columns) else None)


def _series_to_float(value: Any) -> float | None:
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return None
    text = str(value).strip().replace("%", "")
    try:
        return float(text)
    except Exception:
        return None


def _best_name_match(name_normalized: str, candidates: dict[str, str]) -> tuple[str | None, float]:
    if not name_normalized:
        return None, 0.0
    if name_normalized in candidates:
        return candidates[name_normalized], 1.0

    best_id: str | None = None
    best_score = 0.0
    for candidate_name, candidate_id in candidates.items():
        score = SequenceMatcher(None, name_normalized, candidate_name).ratio()
        if name_normalized in candidate_name or candidate_name in name_normalized:
            score = max(score, 0.92)
        if score > best_score:
            best_id = candidate_id
            best_score = score
    return best_id, best_score


def _build_competition_wide(fact_competition: pd.DataFrame) -> pd.DataFrame:
    if fact_competition.empty:
        return pd.DataFrame()
    key_cols = [c for c in ["official_id", "competition", "season", "source", "source_url", "scraped_at", "run_id", "parser_version", "parse_success", "data_complete"] if c in fact_competition.columns]
    metric_cols = [c for c in ["matches_officiated", "fouls_pg", "pen_pg", "yellow_cards_pg", "yellow_cards_total", "red_cards_pg", "red_cards_total", "second_yellow_red_total", "fouls_per_tackle"] if c in fact_competition.columns]
    out = fact_competition.loc[:, key_cols + metric_cols].copy()
    if "match_confidence" in fact_competition.columns and "match_confidence" not in out.columns:
        out["match_confidence"] = fact_competition["match_confidence"]
    if "official_name_raw" in fact_competition.columns and "official_name_raw" not in out.columns:
        out["official_name_raw"] = fact_competition["official_name_raw"]
    if "official_name_normalized" in fact_competition.columns and "official_name_normalized" not in out.columns:
        out["official_name_normalized"] = fact_competition["official_name_normalized"]
    return out.drop_duplicates(subset=[c for c in ["official_id", "competition", "season", "source"] if c in out.columns]).reset_index(drop=True)


@dataclass
class RefereeCollectorConfig:
    whoscored_url_template: str | None = None
    whoscored_feed_template: str | None = None
    cache_root: str | Path | None = None
    min_match_confidence: float = 0.85


class RefereeCollector(BaseCollector):
    def __init__(self, data_dir: str | Path, config: RefereeCollectorConfig | None = None) -> None:
        super().__init__(data_dir)
        self.config = config or RefereeCollectorConfig()
        self.raw_dir = Path(data_dir) / "raw"
        self.cache_root = Path(self.config.cache_root or (Path(data_dir) / "cache"))
        self.fbref_cache_dir = self.cache_root / "fbref" / "referees"
        self.whoscored_cache_dir = self.cache_root / "whoscored" / "referees"
        self.fbref_cache_dir.mkdir(parents=True, exist_ok=True)
        self.whoscored_cache_dir.mkdir(parents=True, exist_ok=True)

    def _latest_fbref_frames(self) -> tuple[pd.DataFrame, pd.DataFrame]:
        fbref_root = _latest_fbref_run(self.raw_dir)
        if fbref_root is None:
            return pd.DataFrame(), pd.DataFrame()
        match_officials = _load_latest_table(fbref_root, "match_officials.parquet")
        match_bundle = _load_latest_table(fbref_root, "match_bundle.parquet")
        return match_officials, match_bundle

    def _load_cached_whoscored_html(self, official_id: str) -> str | None:
        html_path = self.whoscored_cache_dir / f"{official_id}.html"
        if html_path.exists():
            return html_path.read_text(encoding="utf-8", errors="ignore")
        return None

    def _fetch_and_cache_whoscored(self, official_id: str, official_name_raw: str, official_name_normalized: str) -> tuple[str | None, str | None]:
        if not self.config.whoscored_url_template:
            return None, None
        url = _resolve_whoscored_url(self.config.whoscored_url_template, official_name_raw, official_name_normalized, official_id)
        try:
            html = _fetch_url(url)
        except Exception as exc:
            self.logger.warning("No se pudo descargar WhoScored para %s: %s", official_name_raw, exc)
            return None, url
        html_path = self.whoscored_cache_dir / f"{official_id}.html"
        html_path.write_text(html, encoding="utf-8", errors="ignore")
        return html, url

    def collect(self, **kwargs: Any) -> dict[str, pd.DataFrame]:
        match_officials, match_bundle = self._latest_fbref_frames()
        dim_referees, fact_match_stats, manifest = _parse_fbref_officials(match_officials, match_bundle)

        who_dim_frames: list[pd.DataFrame] = []
        who_fact_frames: list[pd.DataFrame] = []

        stage_catalog = _load_whoscored_stage_catalog(self.cache_root)
        competition_pairs = []
        if not fact_match_stats.empty and {"competition", "season"}.issubset(fact_match_stats.columns):
            competition_pairs = (
                fact_match_stats[["competition", "season"]]
                .dropna(how="all")
                .drop_duplicates()
                .to_dict(orient="records")
            )

        if not competition_pairs and not fact_match_stats.empty:
            competition_pairs = [{"competition": None, "season": None}]

        dim_lookup = {}
        if not dim_referees.empty:
            dim_lookup = {
                row["official_name_normalized"]: row["official_id"]
                for _, row in dim_referees.iterrows()
                if row.get("official_name_normalized") and row.get("official_id")
            }

        for pair in competition_pairs:
            competition = pair.get("competition")
            season = pair.get("season")
            stage = _pick_stage(stage_catalog, competition, season)
            if stage is None:
                continue

            feed_url = (
                _build_refereesfeed_url_from_template(self.config.whoscored_feed_template, str(stage["stage_id"]))
                if self.config.whoscored_feed_template
                else _build_refereesfeed_url(str(stage["stage_id"]))
            )
            feed_text, feed_status = _fetch_refereesfeed(feed_url)
            if feed_text is None:
                manifest = pd.concat(
                    [
                        manifest,
                        pd.DataFrame(
                            [
                                {
                                    "official_id": None,
                                    "source": "whoscored",
                                    "status": feed_status,
                                    "cache_path": str(stage["path"]),
                                    "scraped_at": datetime.now(timezone.utc).isoformat(),
                                    "run_id": kwargs.get("run_id"),
                                    "parser_version": PARSER_VERSION,
                                    "source_url": feed_url,
                                }
                            ]
                        ),
                    ],
                    ignore_index=True,
                )
                continue

            parsed_df, parsed_json = _parse_refereesfeed_payload(feed_text)
            if parsed_df.empty:
                manifest = pd.concat(
                    [
                        manifest,
                        pd.DataFrame(
                            [
                                {
                                    "official_id": None,
                                    "source": "whoscored",
                                    "status": "empty",
                                    "cache_path": str(stage["path"]),
                                    "scraped_at": datetime.now(timezone.utc).isoformat(),
                                    "run_id": kwargs.get("run_id"),
                                    "parser_version": PARSER_VERSION,
                                    "source_url": feed_url,
                                }
                            ]
                        ),
                    ],
                    ignore_index=True,
                )
                continue

            parsed_df = parsed_df.copy()
            name_col = _find_name_column(parsed_df)
            if name_col is not None:
                parsed_df["official_name_raw"] = parsed_df[name_col].astype(str)
                parsed_df["official_name_normalized"] = parsed_df["official_name_raw"].map(normalize_name)
                matched_ids = []
                confidences = []
                review_flags = []
                for normalized_name in parsed_df["official_name_normalized"]:
                    matched_id, confidence = _best_name_match(normalized_name, dim_lookup)
                    matched_ids.append(matched_id or _stable_id("whoscored", normalized_name))
                    confidences.append(confidence)
                    review_flags.append(confidence < self.config.min_match_confidence)
                parsed_df["official_id"] = matched_ids
                parsed_df["match_confidence"] = confidences
                parsed_df["identity_review_needed"] = review_flags
            else:
                parsed_df["official_id"] = None

            # Competition facts from WhoScored feed
            fact_row = {
                "official_id": None,
                "competition": competition,
                "season": season,
                "source": "whoscored",
                "source_url": feed_url,
                "run_id": kwargs.get("run_id"),
                "scraped_at": datetime.now(timezone.utc).isoformat(),
                "parser_version": PARSER_VERSION,
                "parse_success": True,
                "data_complete": True,
            }
            for _, row in parsed_df.iterrows():
                row_dict = row.to_dict()
                official_name_norm = row_dict.get("official_name_normalized") or normalize_name(row_dict.get("official_name_raw"))
                official_id = row_dict.get("official_id") or dim_lookup.get(official_name_norm) or _stable_id("whoscored", official_name_norm)
                target = dict(fact_row)
                target["official_id"] = official_id
                target["official_name_raw"] = row_dict.get("official_name_raw")
                target["official_name_normalized"] = official_name_norm
                target["match_confidence"] = row_dict.get("match_confidence", 0.8)
                target["identity_review_needed"] = bool(row_dict.get("identity_review_needed", target["match_confidence"] < self.config.min_match_confidence))

                for col in ["numgames", "foulspg", "fouls_pg", "penpg", "pen_pg", "yellowcardspg", "yellow_cards_pg", "yellowcards", "yellow_cards_total", "redcardspg", "red_cards_pg", "redcards", "red_cards_total", "secondyellowredtotal", "second_yellow_red_total", "foulstotackle", "fouls_per_tackle", "fouls", "tackles", "penaltiesawardedagainstpergame", "penalties_awarded_against_per_game", "awaywinratio", "homewinratio", "drawratio"]:
                    if col in row_dict and target.get(col) is None:
                        target[col] = row_dict[col]

                # Canonical field mapping
                target["matches_officiated"] = _series_to_float(row_dict.get("numgames") or row_dict.get("matches_officiated"))
                target["fouls_pg"] = _series_to_float(row_dict.get("foulspg") or row_dict.get("fouls_pg"))
                target["pen_pg"] = _series_to_float(row_dict.get("penpg") or row_dict.get("pen_pg"))
                target["yellow_cards_pg"] = _series_to_float(row_dict.get("yellowcardspg") or row_dict.get("yellow_cards_pg"))
                target["yellow_cards_total"] = _series_to_float(row_dict.get("yellowcards") or row_dict.get("yellow_cards_total"))
                target["red_cards_pg"] = _series_to_float(row_dict.get("redcardspg") or row_dict.get("red_cards_pg"))
                target["red_cards_total"] = _series_to_float(row_dict.get("redcards") or row_dict.get("red_cards_total"))
                target["second_yellow_red_total"] = _series_to_float(row_dict.get("secondyellowredtotal") or row_dict.get("second_yellow_red_total"))
                target["fouls_per_tackle"] = _series_to_float(row_dict.get("foulstotackle") or row_dict.get("fouls_per_tackle"))
                who_fact_frames.append(pd.DataFrame([target]))

                matched_id = row_dict.get("official_id")
                if matched_id in set(dim_referees.get("official_id", pd.Series(dtype=str))):
                    mask = dim_referees["official_id"] == matched_id
                    dim_referees.loc[mask, "whoscored_name"] = row_dict.get("official_name_raw")
                    dim_referees.loc[mask, "whoscored_url"] = feed_url
                    dim_referees.loc[mask, "match_confidence"] = row_dict.get("match_confidence", 0.8)
                    dim_referees.loc[mask, "identity_review_needed"] = row_dict.get("identity_review_needed", row_dict.get("match_confidence", 0.8) < self.config.min_match_confidence)
                elif official_name_norm in dim_lookup:
                    mask = dim_referees["official_name_normalized"] == official_name_norm
                    dim_referees.loc[mask, "whoscored_name"] = row_dict.get("official_name_raw")
                    dim_referees.loc[mask, "whoscored_url"] = feed_url
                    dim_referees.loc[mask, "match_confidence"] = row_dict.get("match_confidence", 0.8)
                    dim_referees.loc[mask, "identity_review_needed"] = row_dict.get("identity_review_needed", row_dict.get("match_confidence", 0.8) < self.config.min_match_confidence)

            manifest = pd.concat(
                [
                    manifest,
                    pd.DataFrame(
                        [
                            {
                                "official_id": None,
                                "source": "whoscored",
                                "status": "parsed",
                                "cache_path": str(stage["path"]),
                                "scraped_at": datetime.now(timezone.utc).isoformat(),
                                "run_id": kwargs.get("run_id"),
                                "parser_version": PARSER_VERSION,
                                "source_url": feed_url,
                            }
                        ]
                    ),
                ],
                ignore_index=True,
            )

        dim = dim_referees
        facts_competition = pd.concat(who_fact_frames, ignore_index=True, sort=False) if who_fact_frames else pd.DataFrame()
        if not facts_competition.empty:
            for col in ["matches_officiated", "fouls_pg", "pen_pg", "yellow_cards_pg", "yellow_cards_total", "red_cards_pg", "red_cards_total", "second_yellow_red_total", "fouls_per_tackle"]:
                if col in facts_competition.columns:
                    facts_competition[col] = pd.to_numeric(facts_competition[col], errors="coerce")
        facts_competition_wide = _build_competition_wide(facts_competition)

        outputs = {
            "dim_referees": dim,
            "fact_referee_match_stats": fact_match_stats,
            "fact_referee_competition_stats": facts_competition,
            "fact_referee_competition_stats_wide": facts_competition_wide,
            "scrape_manifest": manifest,
        }
        return outputs


def build_referee_dataset(data_dir: str | Path) -> dict[str, Path]:
    data_dir = Path(data_dir)
    raw_dir = data_dir / "raw"
    curated_dir = ensure_dir(data_dir / "final" / "referees" / "final_dataset")

    latest_run = _latest_referee_run(raw_dir)
    if latest_run is None:
        raise FileNotFoundError("No hay artefactos raw/referees para construir el dataset final.")

    dim_referees = read_table_if_exists(latest_run / "tables" / "dim_referees.parquet")
    fact_match = read_table_if_exists(latest_run / "tables" / "fact_referee_match_stats.parquet")
    fact_comp = read_table_if_exists(latest_run / "tables" / "fact_referee_competition_stats.parquet")
    fact_comp_wide = read_table_if_exists(latest_run / "tables" / "fact_referee_competition_stats_wide.parquet")
    manifest = read_table_if_exists(latest_run / "tables" / "scrape_manifest.parquet")
    dim_referees = dim_referees if dim_referees is not None else pd.DataFrame()
    fact_match = fact_match if fact_match is not None else pd.DataFrame()
    fact_comp = fact_comp if fact_comp is not None else pd.DataFrame()
    fact_comp_wide = fact_comp_wide if fact_comp_wide is not None else pd.DataFrame()
    manifest = manifest if manifest is not None else pd.DataFrame()

    tables = {
        "dim_referees": dim_referees,
        "fact_referee_match_stats": fact_match,
        "fact_referee_competition_stats": fact_comp,
        "fact_referee_competition_stats_wide": fact_comp_wide,
        "scrape_manifest": manifest,
    }

    def _records(df: pd.DataFrame) -> list[dict[str, Any]]:
        if df is None or df.empty:
            return []
        return json.loads(df.where(pd.notnull(df), None).to_json(orient="records", date_format="iso"))

    out_paths: dict[str, Path] = {}
    for name, df in tables.items():
        path = curated_dir / f"{name}.parquet"
        write_parquet(df, path)
        write_csv(df, path.with_suffix(".csv"))
        out_paths[name] = path

    manifest_rows = []
    for name, path in out_paths.items():
        manifest_rows.append({"artifact": name, "rows": 0 if tables[name].empty else len(tables[name]), "path": str(path)})
    manifest_df = pd.DataFrame(manifest_rows)
    write_parquet(manifest_df, curated_dir / "manifest.parquet")
    write_csv(manifest_df, curated_dir / "manifest.csv")
    out_paths["manifest"] = curated_dir / "manifest.parquet"

    payload = {
        "metadata": {
            "run_id": latest_run.name.replace("run_id=", ""),
            "parser_version": PARSER_VERSION,
            "validation_status": "ok",
        },
        **{name: _records(df) for name, df in tables.items()},
        "manifest": _records(manifest_df),
    }
    json_path = curated_dir / "referee_dataset.json"
    json_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    out_paths["json"] = json_path
    return out_paths
