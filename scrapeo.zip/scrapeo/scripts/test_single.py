import sys
from pathlib import Path

import undetected_chromedriver as uc

DATA_DIR = Path("../data")
HTML_ROOT = DATA_DIR / "html" / "whoscored" / "matches" / "2022-2023"

match_id = "1650596"
url = f"https://www.whoscored.com/matches/{match_id}/show/"

print(f"HTML_ROOT: {HTML_ROOT}")
print(f"Testing match: {match_id}")

profile_dir = r"D:\Proyectos\soccer_scraper_sessions\whoscored_manual_visible_2022_2023"
print(f"Profile: {profile_dir}")
print(f"Profile exists: {Path(profile_dir).exists()}")

print("Starting Chrome...")
options = uc.ChromeOptions()
options.add_argument(f"--user-data-dir={profile_dir}")

driver = uc.Chrome(options=options, version_main=146)
print(f"Driver: {driver}")

print(f"Getting {url}")
driver.get(url)

import time
time.sleep(5)

# Save show.html
match_root = match_id
save_path = HTML_ROOT / match_root / "show.html"
save_path.parent.mkdir(parents=True, exist_ok=True)

print(f"Saving to: {save_path}")
html = driver.page_source
save_path.write_text(html, encoding="utf-8")

print(f"Saved! Size: {len(html)} chars")
print(f"File exists: {save_path.exists()}")

driver.quit()