from __future__ import annotations

from pathlib import Path
import subprocess
import sys

import typer

from soccer_scraper.config import load_config
from soccer_scraper.collectors.understat import UnderstatCollector
from soccer_scraper.collectors.referees import RefereeCollector, RefereeCollectorConfig, build_referee_dataset
from soccer_scraper.collectors.whoscored import WhoScoredCollector
from soccer_scraper.pipeline import run_collection, run_dataset_build, run_feature_engineering, summarize_match_counts
from soccer_scraper.utils.selenium_session import ChromePersistentSession

DEFAULT_SESSION_ROOT = r"D:\Proyectos\soccer_scraper_sessions"

app = typer.Typer(add_completion=False, no_args_is_help=True)


@app.command("collect")
def collect(config: str = typer.Option(..., help="Ruta al config.yml")) -> None:
    cfg = load_config(config)
    run_collection(cfg)


@app.command("features")
def features(config: str = typer.Option(..., help="Ruta al config.yml")) -> None:
    cfg = load_config(config)
    out = run_feature_engineering(cfg)
    typer.echo(f"Features generadas en: {out}")


@app.command("full-run")
def full_run(config: str = typer.Option(..., help="Ruta al config.yml")) -> None:
    cfg = load_config(config)
    run_collection(cfg)
    out = run_feature_engineering(cfg)
    typer.echo(f"Pipeline completo finalizado. Features en: {out}")


@app.command("build-dataset")
def build_dataset(config: str = typer.Option(..., help="Ruta al config.yml")) -> None:
    cfg = load_config(config)
    outs = run_dataset_build(cfg)
    typer.echo(f"Dataset final generado en: {outs['manifest'].parent}")
    if "canonical_json" in outs:
        typer.echo(f"JSON canónico generado en: {outs['canonical_json']}")
    if "validation_report" in outs:
        typer.echo(f"Reporte de validación generado en: {outs['validation_report']}")


@app.command("export-json")
def export_json(config: str = typer.Option(..., help="Ruta al config.yml")) -> None:
    cfg = load_config(config)
    project = cfg["project"]
    source_dir = Path(project.get("final_dir", Path(project["data_dir"]) / "final")) / "final_dataset"
    out = source_dir / "canonical_dataset.json"
    from soccer_scraper.canonical_export import export_canonical_json

    path = export_canonical_json(source_dir, out)
    typer.echo(f"JSON canónico generado en: {path}")


@app.command("check-match-counts")
def check_match_counts(config: str = typer.Option(..., help="Ruta al config.yml")) -> None:
    cfg = load_config(config)
    report = summarize_match_counts(cfg)
    typer.echo(report)


@app.command("scrape-whoscored-html")
def scrape_whoscored_html(
    config: str = typer.Option(..., help="Ruta al config.yml"),
    season: str = typer.Option("2025-2026", help="Temporada a scrapear"),
) -> None:
    cfg = load_config(config)
    project = cfg["project"]
    wh = cfg.get("whoscored", {})
    leagues = cfg.get("collection", {}).get("leagues", ["ESP-La Liga"])
    collector = WhoScoredCollector(
        data_dir=project["data_dir"],
        leagues=leagues,
        seasons=[season],
        no_cache=wh.get("no_cache", False),
        no_store=wh.get("no_store", False),
        profile_root=project.get("chrome_profiles_dir", wh.get("profile_root", DEFAULT_SESSION_ROOT)),
        profile_name=wh.get("profile_name", "whoscored_manual_visible"),
        path_to_browser=wh.get("path_to_browser"),
        driver_version=wh.get("driver_version"),
        version_main=wh.get("version_main"),
        headless=wh.get("headless", False),
    )
    try:
        saved = collector.scrape_season_html_only()
        typer.echo(f"HTMLs guardados: {len(saved)}")
    finally:
        try:
            collector.reader._driver.quit()
        except Exception:
            pass


@app.command("scrape-understat")
def scrape_understat(
    config: str = typer.Option(..., help="Ruta al config.yml"),
    season: str = typer.Option("2025-2026", help="Temporada a scrapear"),
    league: str = typer.Option("ESP-La Liga", help="Liga a scrapear"),
    max_matches: int = typer.Option(1, help="Máximo de partidos por temporada"),
) -> None:
    cfg = load_config(config)
    project = cfg["project"]
    us = cfg.get("understat", {})
    collector = UnderstatCollector(
        data_dir=project["data_dir"],
        leagues=[league],
        seasons=[season],
        no_cache=us.get("no_cache", False),
        no_store=us.get("no_store", False),
        max_matches_per_season=max_matches,
    )
    outs = collector.save_outputs(collector.collect(), "raw/understat", source_name="understat")
    typer.echo(f"Understat guardado en: {outs.get('manifest', '')}")


@app.command("collect-referees")
def collect_referees(config: str = typer.Option(..., help="Ruta al config.yml")) -> None:
    cfg = load_config(config)
    project = cfg["project"]
    referee_cfg = cfg.get("referees", {})
    collector = RefereeCollector(
        data_dir=project["data_dir"],
        config=RefereeCollectorConfig(
            whoscored_url_template=referee_cfg.get("whoscored_url_template"),
            whoscored_feed_template=referee_cfg.get("whoscored_feed_template"),
            cache_root=project.get("cache_dir"),
            min_match_confidence=referee_cfg.get("min_match_confidence", 0.85),
        ),
    )
    outs = collector.save_outputs(collector.collect(), "raw/referees", source_name="referees")
    typer.echo(f"Árbitros generados en: {outs.get('manifest', '')}")


@app.command("build-referee-dataset")
def build_referee_dataset_cmd(config: str = typer.Option(..., help="Ruta al config.yml")) -> None:
    cfg = load_config(config)
    project = cfg["project"]
    outs = build_referee_dataset(project["data_dir"])
    typer.echo(f"Dataset de árbitros generado en: {outs['json']}")


@app.command("bootstrap-session")
def bootstrap_session(
    config: str | None = typer.Option(None, help="Ruta opcional al config.yml"),
    profile_name: str = typer.Option("whoscored_manual", help="Nombre del perfil"),
    profile_root: str = typer.Option(DEFAULT_SESSION_ROOT, help="Directorio raíz de perfiles"),
    url: str = typer.Option("https://www.whoscored.com/", help="URL inicial"),
    headless: bool = typer.Option(False, help="Abrir en headless"),
    chrome_binary: str | None = typer.Option(None, help="Ruta a Chrome/Chromium"),
) -> None:
    if config is not None:
        cfg = load_config(config)
        profile_root = str(cfg.get("project", {}).get("chrome_profiles_dir", profile_root))
        selenium_cfg = cfg.get("selenium", {})
        profile_name = selenium_cfg.get("profile_name", profile_name)
        headless = selenium_cfg.get("headless", headless)
        chrome_binary = selenium_cfg.get("chrome_binary", chrome_binary)

    sess = ChromePersistentSession(
        profile_root=Path(profile_root),
        profile_name=profile_name,
        headless=headless,
        chrome_binary=chrome_binary,
    )
    sess.bootstrap(url=url)


@app.command("ui")
def ui() -> None:
    ui_path = Path(__file__).resolve().parents[3] / "ui" / "src" / "app.py"
    subprocess.run([sys.executable, "-m", "streamlit", "run", str(ui_path)], check=False)


if __name__ == "__main__":
    app()
