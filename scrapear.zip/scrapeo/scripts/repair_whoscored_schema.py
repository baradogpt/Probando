from __future__ import annotations

from pathlib import Path

import pandas as pd


ROOT = Path("data/raw/whoscored")


def _latest_run_dir() -> Path:
    runs = [p.parent.parent for p in ROOT.glob("run_id=*/tables/match_team_stats.parquet")]
    if not runs:
        raise FileNotFoundError("No encuentro runs de WhoScored")
    return max(runs, key=lambda p: pd.read_parquet(p / "tables" / "match_team_stats.parquet").shape[0])


def _team_map(team_stats: pd.DataFrame) -> pd.DataFrame:
    ts = team_stats.copy()
    ts["match_id"] = ts["match_id"].astype(str)
    home = ts.loc[ts["side"].astype(str).str.lower().eq("home"), ["match_id", "team"]].rename(columns={"team": "home_team"})
    away = ts.loc[ts["side"].astype(str).str.lower().eq("away"), ["match_id", "team"]].rename(columns={"team": "away_team"})
    return home.merge(away, on="match_id", how="outer")


def _apply_team_map(df: pd.DataFrame, mapping: pd.DataFrame) -> pd.DataFrame:
    if df.empty or mapping.empty or "match_id" not in df.columns:
        return df
    out = df.copy()
    out["match_id"] = out["match_id"].astype(str)
    out = out.merge(mapping, on="match_id", how="left", suffixes=("", "__fix"))
    if "home_team__fix" in out.columns:
        if "home_team" in out.columns:
            out["home_team"] = out["home_team__fix"].combine_first(out["home_team"])
            out = out.drop(columns=["home_team__fix"])
        else:
            out = out.rename(columns={"home_team__fix": "home_team"})
    if "away_team__fix" in out.columns:
        if "away_team" in out.columns:
            out["away_team"] = out["away_team__fix"].combine_first(out["away_team"])
            out = out.drop(columns=["away_team__fix"])
        else:
            out = out.rename(columns={"away_team__fix": "away_team"})
    return out


def main() -> None:
    run_dir = _latest_run_dir()
    tables_dir = run_dir / "tables"
    schedule_path = tables_dir / "schedule.parquet"
    team_path = tables_dir / "match_team_stats.parquet"
    player_path = tables_dir / "match_player_stats.parquet"

    schedule = pd.read_parquet(schedule_path)
    team_stats = pd.read_parquet(team_path)
    player_stats = pd.read_parquet(player_path)

    mapping = _team_map(team_stats)
    schedule = _apply_team_map(schedule, mapping)
    team_stats = _apply_team_map(team_stats, mapping)
    player_stats = _apply_team_map(player_stats, mapping)

    schedule.to_parquet(schedule_path, index=False)
    schedule.to_csv(schedule_path.with_suffix(".csv"), index=False)
    team_stats.to_parquet(team_path, index=False)
    team_stats.to_csv(team_path.with_suffix(".csv"), index=False)
    player_stats.to_parquet(player_path, index=False)
    player_stats.to_csv(player_path.with_suffix(".csv"), index=False)

    print(f"Repaired WhoScored tables in {run_dir}")


if __name__ == "__main__":
    main()
