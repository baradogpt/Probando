from __future__ import annotations

import json
import re
from hashlib import sha1
from pathlib import Path
from typing import Any

import pandas as pd
from bs4 import BeautifulSoup

from soccer_scraper.utils.io import read_table_if_exists


def _stable_id(prefix: str, *parts: Any) -> str:
    raw = "|".join("" if p is None else str(p) for p in parts)
    digest = sha1(raw.encode("utf-8")).hexdigest()[:12]
    return f"{prefix}_{digest}"


def _norm_text(value: Any) -> str:
    text = str(value).strip().lower()
    text = text.replace("&", " and ")
    text = re.sub(r"[^a-z0-9]+", "_", text)
    return text.strip("_")


def _to_number(value: Any) -> float | int | None:
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return None
    text = str(value).strip()
    if text == "" or text.lower() == "nan":
        return None
    text = text.replace("%", "")
    try:
        if "." in text:
            return float(text)
        return int(text)
    except Exception:
        return None


def _parse_score(value: Any) -> tuple[int | None, int | None]:
    text = str(value or "")
    m = re.search(r"(\d+)\D+(\d+)", text)
    if not m:
        return None, None
    return int(m.group(1)), int(m.group(2))


def _parse_age(value: Any) -> dict[str, Any]:
    text = str(value or "").strip()
    m = re.match(r"^(\d+)-(\d+)$", text)
    if not m:
        return {"age_raw": None, "age_years": None, "age_days": None, "age_decimal": None}
    years = int(m.group(1))
    days = int(m.group(2))
    return {
        "age_raw": text,
        "age_years": years,
        "age_days": days,
        "age_decimal": round(years + (days / 365.0), 3),
    }


def _parse_nation(value: Any) -> dict[str, Any]:
    text = str(value or "").strip()
    if not text or text.lower() == "nan":
        return {"nation_raw": None, "country_code_2": None, "country_code_3": None}
    parts = text.split()
    if len(parts) >= 2:
        return {"nation_raw": text, "country_code_2": parts[0], "country_code_3": parts[-1]}
    return {"nation_raw": text, "country_code_2": None, "country_code_3": None}


def _parse_complex_metric(value: Any) -> dict[str, Any]:
    text = str(value or "").strip()
    if not text or text.lower() == "nan":
        return {"value_raw": None, "value_numeric": None, "value_made": None, "value_attempts": None, "value_pct": None}

    pct_only = re.fullmatch(r"(\d+(?:\.\d+)?)%", text)
    if pct_only:
        pct = float(pct_only.group(1)) / 100.0
        return {"value_raw": text, "value_numeric": pct, "value_made": None, "value_attempts": None, "value_pct": pct}

    ratio = re.search(r"(\d+(?:\.\d+)?)\s*of\s*(\d+(?:\.\d+)?)", text, re.I)
    pct = re.search(r"(\d+(?:\.\d+)?)%", text)
    made = float(ratio.group(1)) if ratio else None
    attempts = float(ratio.group(2)) if ratio else None
    value_pct = float(pct.group(1)) / 100.0 if pct else None
    value_numeric = made if made is not None else value_pct
    return {
        "value_raw": text,
        "value_numeric": value_numeric,
        "value_made": made,
        "value_attempts": attempts,
        "value_pct": value_pct,
    }


def _metric_group(metric: Any) -> str:
    name = _norm_text(metric)
    if name in {"possession", "pass_pct", "poss_pct"}:
        return "possession"
    if any(key in name for key in ["shot", "goal", "xg", "assist", "sot"]):
        return "attacking"
    if any(key in name for key in ["save", "keeper", "goalkeeper"]):
        return "goalkeeping"
    if any(key in name for key in ["card", "foul", "discipline"]):
        return "discipline"
    return "general"


def _load_first(root: Path, names: list[str]) -> pd.DataFrame:
    for name in names:
        for suffix in [".parquet", ".csv"]:
            candidates = list(root.rglob(f"{name}{suffix}")) if root.exists() else []
            if not candidates:
                continue
            latest = max(candidates, key=lambda p: p.stat().st_mtime)
            df = read_table_if_exists(latest)
            if df is not None and not df.empty:
                return df
    return pd.DataFrame()


def _resolve_path(path_value: Any, root: Path) -> Path | None:
    if path_value is None or (isinstance(path_value, float) and pd.isna(path_value)):
        return None
    path = Path(str(path_value))
    if path.is_absolute():
        return path if path.exists() else None
    candidate = root / path
    if candidate.exists():
        return candidate
    if path.exists():
        return path
    return None


def _read_html(path: Path | None) -> str:
    if path is None or not path.exists():
        return ""
    return path.read_text(encoding="utf-8", errors="ignore")


def _parse_officials_from_html(html: str, match_id: str, league: str, season: str, match_report_url: str | None) -> list[dict[str, Any]]:
    soup = BeautifulSoup(html, "html.parser")
    text = ""
    for strong in soup.find_all("strong"):
        if strong.get_text(" ", strip=True).lower() == "officials":
            parent = strong.parent
            if parent is not None:
                text = parent.get_text(" ", strip=True)
                break
    if not text:
        return []
    if "Officials:" in text:
        text = text.split("Officials:", 1)[1].strip()
    roles = {
        "Referee": "referee",
        "AR1": "assistant_referee_1",
        "AR2": "assistant_referee_2",
        "4th": "fourth_official",
        "VAR": "var",
    }
    rows: list[dict[str, Any]] = []
    for part in [p.strip() for p in text.split("·") if p.strip()]:
        m = re.match(r"^(.*?)\s*\(([^)]+)\)$", part)
        if not m:
            continue
        name = m.group(1).replace("\xa0", " ").strip()
        role_raw = m.group(2).strip()
        role = roles.get(role_raw, _norm_text(role_raw))
        rows.append(
            {
                "official_id": _stable_id("fbref_official", match_id, role, name),
                "match_id": match_id,
                "team_id": None,
                "team": None,
                "official_name": name,
                "role": role,
                "role_raw": role_raw,
                "source": "fbref",
                "source_url": match_report_url,
                "source_html_path": None,
                "source_table": "officials",
                "scraped_at": None,
                "run_id": None,
                "parser_version": "canonical-1",
                "cache_key": _stable_id("cache", match_id, role, name),
                "parse_success": True,
                "data_complete": True,
                "validation_status": "ok",
                "league": league,
                "season": season,
            }
        )
    return rows


def _parse_lineups_from_html(html: str, match_id: str, league: str, season: str, match_report_url: str | None, source_html_path: str | None) -> tuple[list[dict[str, Any]], dict[tuple[str, str], dict[str, Any]]]:
    soup = BeautifulSoup(html, "html.parser")
    lineups: list[dict[str, Any]] = []
    player_lookup: dict[tuple[str, str], dict[str, Any]] = {}
    for lineup_div in soup.select("div.lineup"):
        side = lineup_div.get("id")
        if side not in {"a", "b"}:
            continue
        team_header = lineup_div.find("th")
        team_name = None
        formation = None
        if team_header is not None:
            header_text = team_header.get_text(" ", strip=True)
            formation_match = re.search(r"\(([^)]+)\)", header_text)
            if formation_match:
                formation = formation_match.group(1).strip()
            team_name = header_text.split("(", 1)[0].strip()
        if not team_name:
            continue
        team_id = _stable_id("fbref_team", league, team_name)

        rows = lineup_div.find_all("tr")
        in_bench = False
        order = 0
        bench_order = 0
        for row in rows:
            if row.find("th") is not None:
                header_text = row.get_text(" ", strip=True).lower()
                if header_text == "bench":
                    in_bench = True
                continue
            tds = row.find_all("td")
            if len(tds) < 2:
                continue
            shirt_number = _to_number(tds[0].get_text(" ", strip=True))
            name_link = tds[1].find("a")
            if name_link is None:
                continue
            player_name = name_link.get_text(" ", strip=True)
            href = str(name_link.get("href", ""))
            player_key = None
            m = re.search(r"/en/players/([^/]+)/", href)
            if m:
                player_key = m.group(1)
            player_id = f"fbref_player_{player_key}" if player_key else _stable_id("fbref_player", match_id, team_name, player_name)

            icons = [cls for div in row.find_all(class_=re.compile(r"event_icon")) for cls in (div.get("class") or [])]
            is_bench = in_bench
            is_starter = not in_bench
            played = is_starter
            sub_in = any("substitute_in" in cls for cls in icons)
            if is_bench and sub_in:
                played = True

            entry = {
                "match_id": match_id,
                "team_id": team_id,
                "team": team_name,
                "side": "home" if side == "a" else "away",
                "player_id": player_id,
                "player": player_name,
                "shirt_number": shirt_number,
                "is_starter": is_starter,
                "is_bench": is_bench,
                "played": played,
                "sub_in_minute": None,
                "sub_out_minute": None,
                "starting_position": None,
                "lineup_order": order if is_starter else bench_order,
                "source": "fbref",
                "source_url": match_report_url,
                "source_html_path": source_html_path,
                "source_table": "lineups",
                "scraped_at": None,
                "run_id": None,
                "parser_version": "canonical-1",
                "cache_key": _stable_id("cache", match_id, player_id, "lineups"),
                "parse_success": True,
                "data_complete": True,
                "validation_status": "ok",
                "league": league,
                "season": season,
                "formation": formation,
            }
            lineups.append(entry)
            player_lookup[(team_name, player_name)] = entry
            if not is_bench:
                order += 1
            else:
                bench_order += 1

    return lineups, player_lookup


def _parse_events_from_html(html: str, match_id: str, league: str, season: str, home_team: str, away_team: str, match_report_url: str | None, source_html_path: str | None) -> tuple[list[dict[str, Any]], dict[tuple[str, str], dict[str, Any]]]:
    soup = BeautifulSoup(html, "html.parser")
    events_root = soup.select_one("div#events_wrap")
    if events_root is None:
        return [], {}

    events: list[dict[str, Any]] = []
    sub_minutes: dict[tuple[str, str], dict[str, Any]] = {}
    score_state = {"home": None, "away": None}

    for event in events_root.select("div.event"):
        side_class = "a" if "a" in (event.get("class") or []) else "b"
        side = "home" if side_class == "a" else "away"
        team = home_team if side == "home" else away_team
        opponent = away_team if side == "home" else home_team
        team_id = _stable_id("fbref_team", league, team)
        opponent_id = _stable_id("fbref_team", league, opponent)

        left = event.find_all("div", recursive=False)[0] if event.find_all("div", recursive=False) else None
        right = event.find_all("div", recursive=False)[1] if len(event.find_all("div", recursive=False)) > 1 else None
        minute_text = left.get_text(" ", strip=True) if left is not None else ""
        minute_match = re.search(r"(\d+)(?:\+(\d+))?", minute_text)
        minute = int(minute_match.group(1)) if minute_match else None
        stoppage_time = int(minute_match.group(2)) if minute_match and minute_match.group(2) else 0
        period = 1 if minute is not None and minute <= 45 else 2 if minute is not None and minute <= 90 else 3 if minute is not None else None

        score_text = None
        if left is not None:
            score_node = left.find("small")
            if score_node is not None:
                score_text = score_node.get_text(" ", strip=True)
        home_score_after, away_score_after = None, None
        if score_text:
            home_score_after, away_score_after = _parse_score(score_text)
            if home_score_after is not None:
                score_state["home"] = home_score_after
            if away_score_after is not None:
                score_state["away"] = away_score_after
        else:
            home_score_after, away_score_after = score_state["home"], score_state["away"]

        icon = right.find(class_=re.compile(r"event_icon")) if right is not None else None
        icon_classes = icon.get("class", []) if icon is not None else []
        icon_class = next((c for c in icon_classes if c != "event_icon"), None)
        event_type = {
            "goal": "goal",
            "penalty_goal": "penalty_goal",
            "yellow_card": "yellow_card",
            "red_card": "red_card",
            "substitute_in": "substitute_in",
        }.get(icon_class, None)
        if event_type is None:
            continue

        player_link = right.find("a") if right is not None else None
        player_name = player_link.get_text(" ", strip=True) if player_link is not None else None
        player_href = str(player_link.get("href", "")) if player_link is not None else ""
        player_key = None
        m = re.search(r"/en/players/([^/]+)/", player_href)
        if m:
            player_key = m.group(1)
        player_id = f"fbref_player_{player_key}" if player_key else _stable_id("fbref_player", match_id, team, player_name)

        assist_player_id = None
        assist_name = None
        for a in right.find_all("a") if right is not None else []:
            if a is player_link:
                continue
            assist_name = a.get_text(" ", strip=True)
            assist_href = str(a.get("href", ""))
            assist_match = re.search(r"/en/players/([^/]+)/", assist_href)
            if assist_match:
                assist_player_id = f"fbref_player_{assist_match.group(1)}"
            break

        related_player_id = None
        related_player = None
        smalls = right.find_all("small") if right is not None else []
        if smalls:
            rel_text = smalls[0].get_text(" ", strip=True)
            rel_match = re.search(r"for\s+(.*)$", rel_text, re.I)
            if rel_match:
                related_player = rel_match.group(1).strip()
                rel_anchor = smalls[0].find("a")
                if rel_anchor is not None:
                    rel_href = str(rel_anchor.get("href", ""))
                    rel_match_href = re.search(r"/en/players/([^/]+)/", rel_href)
                    if rel_match_href:
                        related_player_id = f"fbref_player_{rel_match_href.group(1)}"

        raw_text = event.get_text(" ", strip=True)
        is_penalty = event_type == "penalty_goal" or "(P)" in raw_text
        is_own_goal = "own goal" in raw_text.lower()
        is_red_card = event_type == "red_card"
        is_yellow_card = event_type == "yellow_card"

        entry = {
            "event_id": _stable_id("fbref_event", match_id, minute, event_type, player_name, raw_text),
            "match_id": match_id,
            "team_id": team_id,
            "opponent_id": opponent_id,
            "player_id": player_id,
            "assist_player_id": assist_player_id,
            "related_player_id": related_player_id,
            "team": team,
            "opponent": opponent,
            "player": player_name,
            "side": side,
            "minute": minute,
            "second": None,
            "period": period,
            "stoppage_time": stoppage_time,
            "event_type": event_type,
            "event_outcome": "success" if event_type in {"goal", "penalty_goal", "yellow_card", "red_card", "substitute_in"} else None,
            "raw_text": raw_text,
            "source": "fbref",
            "source_url": match_report_url,
            "source_html_path": source_html_path,
            "source_table": "events",
            "scraped_at": None,
            "run_id": None,
            "parser_version": "canonical-1",
            "cache_key": _stable_id("cache", match_id, event_type, minute, player_name),
            "parse_success": True,
            "data_complete": True,
            "validation_status": "ok",
            "home_score_after_event": home_score_after,
            "away_score_after_event": away_score_after,
            "is_penalty": is_penalty,
            "is_own_goal": is_own_goal,
            "is_red_card": is_red_card,
            "is_yellow_card": is_yellow_card,
            "league": league,
            "season": season,
            "assist_player": assist_name,
            "related_player": related_player,
        }
        events.append(entry)

        if event_type == "substitute_in":
            for_name = related_player or None
            if for_name:
                sub_minutes[(team, player_name)] = {"sub_in_minute": minute, "sub_out_minute": None}
                sub_minutes[(team, for_name)] = {"sub_in_minute": None, "sub_out_minute": minute}

    return events, sub_minutes


def _build_match_row(matches: pd.DataFrame, league: str, season: str, run_id: str) -> dict[str, Any]:
    row = matches.iloc[0].to_dict() if not matches.empty else {}
    home_team = row.get("home_team") or row.get("home")
    away_team = row.get("away_team") or row.get("away")
    home_score, away_score = _parse_score(row.get("score"))
    source_html_path = str(row.get("source_html_path") or "")
    match_id = str(row.get("match_id") or _stable_id("fbref_match", row.get("match_report_url"), home_team, away_team))
    competition_id = _stable_id("fbref_competition", league)
    referee = row.get("referee") or row.get("match__referee") or row.get("referee_name")
    return {
        "match_id": match_id,
        "competition_id": competition_id,
        "league": league,
        "season": season,
        "matchweek": row.get("wk") or row.get("matchweek") or row.get("round"),
        "date": row.get("date"),
        "time": row.get("time"),
        "status": row.get("status") or "finished",
        "home_team": home_team,
        "home_team_id": _stable_id("fbref_team", league, home_team),
        "away_team": away_team,
        "away_team_id": _stable_id("fbref_team", league, away_team),
        "home_score": home_score,
        "away_score": away_score,
        "venue": row.get("venue"),
        "attendance": _to_number(row.get("attendance")),
        "referee": referee,
        "referee_id": _stable_id("fbref_official", match_id, "referee", referee),
        "match_report_url": row.get("match_report_url"),
        "source_html_path": source_html_path,
        "source": row.get("source") or "fbref",
        "source_url": row.get("match_report_url") or row.get("source_url"),
        "run_id": run_id,
        "scraped_at": pd.Timestamp.utcnow().isoformat(),
        "parser_version": "canonical-1",
        "parse_success": True,
        "data_complete": True,
        "validation_status": "ok",
        "extra_time": False,
        "penalty_shootout": False,
        "neutral_venue": False,
    }


def _canonicalize_matches(matches: pd.DataFrame, run_id: str, root: Path) -> tuple[pd.DataFrame, dict[str, Any]]:
    if matches.empty:
        return pd.DataFrame(), {}
    rows = []
    meta: dict[str, Any] = {}
    for _, raw in matches.iterrows():
        league = str(raw.get("league") or "")
        season = str(raw.get("season") or "")
        row = _build_match_row(pd.DataFrame([raw]), league, season, run_id)
        html_path = _resolve_path(raw.get("source_html_path"), root)
        if html_path is not None:
            row["source_html_path"] = str(html_path)
            meta[str(row["match_id"])] = {"html_path": str(html_path), "league": league, "season": season}
        rows.append(row)
    return pd.DataFrame(rows), meta


def _canonicalize_team_stats(team_stats: pd.DataFrame, matches: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    if team_stats.empty:
        return pd.DataFrame(), pd.DataFrame()
    out_rows: list[dict[str, Any]] = []
    wide_rows: dict[tuple[str, str], dict[str, Any]] = {}

    match_lookup = matches.set_index("match_id").to_dict(orient="index") if not matches.empty and "match_id" in matches.columns else {}
    for _, row in team_stats.iterrows():
        match_id = row.get("match_id")
        match = match_lookup.get(str(match_id), {})
        team = row.get("team")
        opponent = row.get("opponent")
        side = row.get("side")
        metric = row.get("metric")
        parsed = _parse_complex_metric(row.get("value_raw") if "value_raw" in row else row.get("value"))
        value_raw = parsed["value_raw"]
        value_numeric = parsed["value_numeric"]
        if value_numeric is None:
            value_numeric = _to_number(row.get("value"))
        row_out = {
            "match_id": match_id,
            "team_id": _stable_id("fbref_team", match.get("league"), team),
            "opponent_id": _stable_id("fbref_team", match.get("league"), opponent),
            "team": team,
            "opponent": opponent,
            "side": side,
            "metric": metric,
            "metric_group": _metric_group(metric),
            "value_raw": value_raw,
            "value_numeric": value_numeric,
            "value_made": parsed["value_made"],
            "value_attempts": parsed["value_attempts"],
            "value_pct": parsed["value_pct"],
            "source": row.get("source") or "fbref",
            "source_url": row.get("source_url") or match.get("match_report_url"),
            "source_html_path": match.get("source_html_path"),
            "source_table": "team_match_stats",
            "scraped_at": match.get("scraped_at"),
            "run_id": match.get("run_id"),
            "parser_version": "canonical-1",
            "cache_key": _stable_id("cache", match_id, team, metric),
            "parse_success": True,
            "data_complete": True,
            "validation_status": "ok",
        }
        out_rows.append(row_out)

        key = (str(match_id), str(team))
        wide = wide_rows.setdefault(
            key,
            {
                "match_id": match_id,
                "team_id": _stable_id("fbref_team", match.get("league"), team),
                "opponent_id": _stable_id("fbref_team", match.get("league"), opponent),
                "team": team,
                "opponent": opponent,
                "side": side,
                "source": row.get("source") or "fbref",
                "source_url": row.get("source_url") or match.get("match_report_url"),
                "source_html_path": match.get("source_html_path"),
                "source_table": "team_match_stats_wide",
                "scraped_at": match.get("scraped_at"),
                "run_id": match.get("run_id"),
                "parser_version": "canonical-1",
                "cache_key": _stable_id("cache", match_id, team, "wide"),
                "parse_success": True,
                "data_complete": True,
                "validation_status": "ok",
            },
        )
        metric_key = _norm_text(metric)
        if parsed["value_pct"] is not None:
            wide[f"{metric_key}_pct"] = parsed["value_pct"]
        if parsed["value_made"] is not None:
            wide[f"{metric_key}_made"] = parsed["value_made"]
        if parsed["value_attempts"] is not None:
            wide[f"{metric_key}_attempts"] = parsed["value_attempts"]
        if parsed["value_numeric"] is not None:
            wide[f"{metric_key}_value"] = parsed["value_numeric"]

    return pd.DataFrame(out_rows), pd.DataFrame(list(wide_rows.values()))


def _canonicalize_lineups(lineups: pd.DataFrame, lineups_from_html: list[dict[str, Any]], sub_minutes: dict[tuple[str, str], dict[str, Any]], match: dict[str, Any]) -> pd.DataFrame:
    if not lineups_from_html:
        return pd.DataFrame()
    rows = []
    for row in lineups_from_html:
        key = (row["team"], row["player"])
        minutes = sub_minutes.get(key, {})
        item = dict(row)
        item["sub_in_minute"] = minutes.get("sub_in_minute")
        item["sub_out_minute"] = minutes.get("sub_out_minute")
        item["started_match"] = bool(item.get("is_starter"))
        item["captain"] = False
        item["position_group"] = None
        rows.append(item)
    return pd.DataFrame(rows)


def _canonicalize_player_stats(player_stats: pd.DataFrame, keeper_stats: pd.DataFrame, lineup_df: pd.DataFrame, match: dict[str, Any]) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    if player_stats.empty and keeper_stats.empty:
        return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

    lineup_lookup = {}
    if not lineup_df.empty:
        for _, row in lineup_df.iterrows():
            lineup_lookup[(row.get("team"), row.get("player"))] = row.to_dict()

    player_rows: list[dict[str, Any]] = []
    aggregates: list[dict[str, Any]] = []
    for _, row in player_stats.iterrows():
        player_name = row.get("player")
        if isinstance(player_name, str) and "players" in player_name.lower():
            aggregates.append(row.to_dict())
            continue
        team = row.get("team")
        row_out: dict[str, Any] = {
            "match_id": row.get("match_id"),
            "team_id": _stable_id("fbref_team", match.get("league"), team),
            "team": team,
            "player": player_name,
            "player_id": None,
            "shirt_number": _to_number(row.get("unnamed_1_level_0")),
            "position": row.get("unnamed_3_level_0_pos"),
            "position_group": row.get("unnamed_3_level_0_pos"),
            "source": row.get("source") or "fbref",
            "source_url": row.get("source_url") or match.get("match_report_url"),
            "source_html_path": match.get("source_html_path"),
            "source_table": "player_match_stats",
            "scraped_at": match.get("scraped_at"),
            "run_id": match.get("run_id"),
            "parser_version": "canonical-1",
            "cache_key": _stable_id("cache", row.get("match_id"), team, player_name),
            "parse_success": True,
            "data_complete": True,
            "validation_status": "ok",
        }
        row_out.update(_parse_nation(row.get("unnamed_2_level_0_nation")))
        row_out.update(_parse_age(row.get("unnamed_4_level_0_age")))
        row_out["minutes"] = _to_number(row.get("unnamed_5_level_0_min"))
        row_out["started_match"] = bool(lineup_lookup.get((team, player_name), {}).get("is_starter", False))
        row_out["sub_in_minute"] = lineup_lookup.get((team, player_name), {}).get("sub_in_minute")
        row_out["sub_out_minute"] = lineup_lookup.get((team, player_name), {}).get("sub_out_minute")
        row_out["shirt_number"] = _to_number(row.get("unnamed_1_level_0"))
        row_out["captain"] = False
        player_id = lineup_lookup.get((team, player_name), {}).get("player_id")
        row_out["player_id"] = player_id or _stable_id("fbref_player", match.get("match_id"), team, player_name)
        # Map all known raw columns into explicit semantic keys.
        metric_sources = {
            "goals": ["performance_gls", "gls"],
            "assists": ["performance_ast", "ast"],
            "shots": ["performance_sh", "sh"],
            "shots_on_target": ["performance_sot", "sot"],
            "tackles": ["performance_tklw", "tklw"],
            "interceptions": ["performance_int", "int"],
            "fouls": ["performance_fls", "fls"],
            "fouled": ["performance_fld", "fld"],
            "yellow_cards": ["performance_crdy", "crdy"],
            "red_cards": ["performance_crdr", "crdr"],
            "crosses": ["performance_crs", "crs"],
            "offsides": ["performance_off", "off"],
            "own_goals": ["performance_og", "og"],
            "penalties_made": ["performance_pk", "pk"],
            "penalties_attempted": ["performance_pkatt", "pkatt"],
            "penalties_won": ["performance_pkwon", "pkwon"],
            "crosses": ["performance_crs", "crs"],
            "offsides": ["performance_off", "off"],
            "own_goals": ["performance_og", "og"],
            "penalties_made": ["performance_pk", "pk"],
            "penalties_attempted": ["performance_pkatt", "pkatt"],
            "penalties_won": ["performance_pkwon", "pkwon"],
        }
        for metric_name, cols in metric_sources.items():
            for col in cols:
                if col in row.index and row.get(col) is not None:
                    row_out[metric_name] = _to_number(row.get(col))
                    break
        for col in [c for c in row.index if c.startswith("performance_") and _norm_text(c.replace("performance_", "")) not in {"gls", "ast", "sh", "sot", "tklw", "int", "fls", "fld", "crdy", "crdr", "crs", "off", "og", "pk", "pkatt", "pkwon"}]:
            row_out[col.replace("performance_", "")]= _to_number(row.get(col))
        player_rows.append(row_out)

    keeper_rows: list[dict[str, Any]] = []
    for _, row in keeper_stats.iterrows():
        player_name = row.get("player")
        team = row.get("team")
        row_out: dict[str, Any] = {
            "match_id": row.get("match_id"),
            "team_id": _stable_id("fbref_team", match.get("league"), team),
            "team": team,
            "player": player_name,
            "player_id": None,
            "shirt_number": _to_number(row.get("unnamed_0_level_0")) if "unnamed_0_level_0" in row.index else None,
            "started_match": bool(lineup_lookup.get((team, player_name), {}).get("is_starter", False)),
            "sub_in_minute": lineup_lookup.get((team, player_name), {}).get("sub_in_minute"),
            "sub_out_minute": lineup_lookup.get((team, player_name), {}).get("sub_out_minute"),
            "position_group": "GK",
            "source": row.get("source") or "fbref",
            "source_url": row.get("source_url") or match.get("match_report_url"),
            "source_html_path": match.get("source_html_path"),
            "source_table": "keeper_match_stats",
            "scraped_at": match.get("scraped_at"),
            "run_id": match.get("run_id"),
            "parser_version": "canonical-1",
            "cache_key": _stable_id("cache", row.get("match_id"), team, player_name, "keeper"),
            "parse_success": True,
            "data_complete": True,
            "validation_status": "ok",
        }
        row_out.update(_parse_nation(row.get("unnamed_1_level_0_nation")))
        row_out.update(_parse_age(row.get("unnamed_2_level_0_age")))
        row_out["minutes"] = _to_number(row.get("unnamed_3_level_0_min"))
        player_id = lineup_lookup.get((team, player_name), {}).get("player_id")
        row_out["player_id"] = player_id or _stable_id("fbref_player", match.get("match_id"), team, player_name)
        for col in [c for c in row.index if c.startswith("shot_stopping_")]:
            row_out[col.replace("shot_stopping_", "")]= _to_number(row.get(col))
        # Goalkeeper-specific aliases if they exist in source.
        keeper_aliases = {
            "saves": ["shot_stopping_saves", "saves"],
            "goals_conceded": ["shot_stopping_ga", "ga"],
            "save_pct": ["shot_stopping_save_pct", "save_pct"],
            "psxg": ["shot_stopping_psxg", "psxg"],
        }
        for metric_name, cols in keeper_aliases.items():
            for col in cols:
                if col in row.index and row.get(col) is not None:
                    row_out[metric_name] = _to_number(row.get(col))
                    break
        keeper_rows.append(row_out)

    aggregates_df = pd.DataFrame(aggregates)
    return pd.DataFrame(player_rows), pd.DataFrame(keeper_rows), aggregates_df


def _canonicalize_events(events: pd.DataFrame, html_events: list[dict[str, Any]], match: dict[str, Any]) -> pd.DataFrame:
    if html_events:
        return pd.DataFrame(html_events)
    if events.empty:
        return pd.DataFrame()
    out = events.copy()
    out["event_id"] = [
        _stable_id("fbref_event", row.get("match_id"), row.get("side"), row.get("minute"), row.get("player"), row.get("event_type"))
        for _, row in out.iterrows()
    ]
    out["team_id"] = out.apply(lambda r: _stable_id("fbref_team", match.get("league"), r.get("team")), axis=1)
    out["opponent_id"] = out.apply(lambda r: _stable_id("fbref_team", match.get("league"), r.get("opponent") or (match.get("away_team") if r.get("side") == "home" else match.get("home_team"))), axis=1)
    out["player_id"] = out.apply(lambda r: _stable_id("fbref_player", r.get("match_id"), r.get("team"), r.get("player")), axis=1)
    out["assist_player_id"] = out.get("assist_player_id") if "assist_player_id" in out.columns else None
    out["related_player_id"] = out.get("related_player_id") if "related_player_id" in out.columns else None
    return out


def build_canonical_dataset(source_dir: str | Path) -> dict[str, Any]:
    source_dir = Path(source_dir)
    root = source_dir.parents[2] if len(source_dir.parents) >= 3 else source_dir.parent
    run_id = pd.Timestamp.utcnow().strftime("%Y%m%dT%H%M%SZ")

    matches_raw = _load_first(source_dir, ["matches"])
    matches, match_meta = _canonicalize_matches(matches_raw, run_id, root)
    if matches.empty:
        return {"metadata": {"run_id": run_id, "validation_status": "empty"}}

    match = matches.iloc[0].to_dict()
    html_path = _resolve_path(match.get("source_html_path"), root)
    html = _read_html(html_path)

    team_stats_raw = _load_first(source_dir, ["team_match_stats"])
    player_stats_raw = _load_first(source_dir, ["player_match_stats"])
    keeper_stats_raw = _load_first(source_dir, ["keeper_match_stats"])
    events_raw = _load_first(source_dir, ["events"])
    lineups_raw = _load_first(source_dir, ["lineups"])
    officials_raw = _load_first(source_dir, ["officials"])
    whoscored_team_stats_raw = _load_first(source_dir, ["whoscored_team_match_stats", "fact_whoscored_team_match_stats"])
    whoscored_player_stats_raw = _load_first(source_dir, ["whoscored_player_match_stats", "fact_whoscored_player_match_stats"])
    understat_team_stats_raw = _load_first(source_dir, ["understat_team_match_stats", "fact_understat_team_match_stats"])
    understat_player_stats_raw = _load_first(source_dir, ["understat_player_match_stats", "fact_understat_player_match_stats"])
    understat_lineups_raw = _load_first(source_dir, ["understat_lineups", "fact_understat_lineups"])
    understat_events_raw = _load_first(source_dir, ["understat_shot_events", "fact_understat_shot_events"])
    understat_player_season_raw = _load_first(source_dir, ["understat_player_season_stats", "fact_understat_player_season_stats"])

    lineups_html, lineup_lookup = _parse_lineups_from_html(html, match["match_id"], match["league"], match["season"], match.get("match_report_url"), str(html_path) if html_path else None)
    events_html, sub_minutes = _parse_events_from_html(html, match["match_id"], match["league"], match["season"], match.get("home_team"), match.get("away_team"), match.get("match_report_url"), str(html_path) if html_path else None)

    team_stats, team_stats_wide = _canonicalize_team_stats(team_stats_raw, matches)
    lineups = _canonicalize_lineups(lineups_raw, lineups_html, sub_minutes, match)
    player_stats, keeper_stats, aggregates = _canonicalize_player_stats(player_stats_raw, keeper_stats_raw, lineups, match)

    # Ensure player rows reuse lineup-derived identifiers when possible.
    if not lineups.empty:
        lookup_df = lineups[["team", "player", "player_id", "is_starter", "played", "sub_in_minute", "sub_out_minute", "shirt_number"]].copy()
        player_stats = player_stats.merge(lookup_df, on=["team", "player"], how="left", suffixes=("", "__lineup"))
        keeper_stats = keeper_stats.merge(lookup_df, on=["team", "player"], how="left", suffixes=("", "__lineup"))

    events = _canonicalize_events(events_raw, events_html, match)

    competitions = pd.DataFrame([
        {
            "competition_id": match["competition_id"],
            "league": match["league"],
            "source": match.get("source"),
        }
    ])
    teams = pd.DataFrame([
        {"team_id": match["home_team_id"], "team": match["home_team"], "league": match["league"], "source": match.get("source")},
        {"team_id": match["away_team_id"], "team": match["away_team"], "league": match["league"], "source": match.get("source")},
    ]).drop_duplicates(subset=["team_id"]).reset_index(drop=True)

    def _safe_subset(df: pd.DataFrame, cols: list[str]) -> pd.DataFrame:
        if df.empty:
            return pd.DataFrame(columns=cols)
        present = [c for c in cols if c in df.columns]
        return df.loc[:, present].copy()

    players = pd.concat([
        _safe_subset(player_stats, ["player_id", "player", "team_id", "team", "nation_raw", "country_code_2", "country_code_3", "position", "position_group"]),
        _safe_subset(keeper_stats, ["player_id", "player", "team_id", "team", "nation_raw", "country_code_2", "country_code_3", "position_group"]),
        _safe_subset(lineups, ["player_id", "player", "team_id", "team", "shirt_number"]),
    ], ignore_index=True, sort=False)
    if not players.empty and "player_id" in players.columns:
        if not lineups.empty and "shirt_number" in lineups.columns:
            shirt_map = lineups.dropna(subset=["player_id"]).drop_duplicates(subset=["player_id"]).set_index("player_id")["shirt_number"].to_dict()
            if "shirt_number" in players.columns:
                mapped_shirts = players["player_id"].map(shirt_map)
                players["shirt_number"] = players["shirt_number"].where(players["shirt_number"].notna(), mapped_shirts)
        players = players.drop_duplicates(subset=["player_id"]).reset_index(drop=True)

    officials = pd.concat([
        pd.DataFrame(_parse_officials_from_html(html, match["match_id"], match["league"], match["season"], match.get("match_report_url"))),
        officials_raw if not officials_raw.empty else pd.DataFrame(),
    ], ignore_index=True, sort=False)
    if not officials.empty and "official_id" in officials.columns:
        officials = officials.loc[officials["official_id"].notna()].drop_duplicates(subset=["official_id"]).reset_index(drop=True)

    manifest = pd.DataFrame([
        {"artifact": "matches", "rows": len(matches), "validation_status": "ok"},
        {"artifact": "competitions", "rows": len(competitions), "validation_status": "ok"},
        {"artifact": "teams", "rows": len(teams), "validation_status": "ok"},
        {"artifact": "players", "rows": len(players), "validation_status": "ok"},
        {"artifact": "officials", "rows": len(officials), "validation_status": "ok"},
        {"artifact": "fact_team_match_stats", "rows": len(team_stats), "validation_status": "ok"},
        {"artifact": "fact_team_match_stats_wide", "rows": len(team_stats_wide), "validation_status": "ok"},
        {"artifact": "fact_player_match_stats", "rows": len(player_stats), "validation_status": "ok"},
        {"artifact": "fact_keeper_match_stats", "rows": len(keeper_stats), "validation_status": "ok"},
        {"artifact": "fact_lineups", "rows": len(lineups), "validation_status": "ok"},
        {"artifact": "fact_events", "rows": len(events), "validation_status": "ok"},
        {"artifact": "team_player_aggregates", "rows": len(aggregates), "validation_status": "ok"},
        {"artifact": "fact_understat_team_match_stats", "rows": len(understat_team_stats_raw), "validation_status": "ok"},
        {"artifact": "fact_understat_player_match_stats", "rows": len(understat_player_stats_raw), "validation_status": "ok"},
        {"artifact": "fact_understat_lineups", "rows": len(understat_lineups_raw), "validation_status": "ok"},
        {"artifact": "fact_understat_shot_events", "rows": len(understat_events_raw), "validation_status": "ok"},
        {"artifact": "fact_understat_player_season_stats", "rows": len(understat_player_season_raw), "validation_status": "ok"},
        {"artifact": "fact_whoscored_team_match_stats", "rows": len(whoscored_team_stats_raw), "validation_status": "ok"},
        {"artifact": "fact_whoscored_player_match_stats", "rows": len(whoscored_player_stats_raw), "validation_status": "ok"},
    ])

    def _records(df: pd.DataFrame) -> list[dict[str, Any]]:
        if df.empty:
            return []
        return json.loads(df.where(pd.notnull(df), None).to_json(orient="records", date_format="iso"))

    payload = {
        "metadata": {
            "run_id": run_id,
            "parser_version": "canonical-1",
            "source_dir": str(source_dir),
            "source_html_path": str(html_path) if html_path else None,
            "validation_status": "ok",
        },
        "competitions": _records(competitions),
        "matches": _records(matches),
        "teams": _records(teams),
        "players": _records(players),
        "officials": _records(officials),
        "fact_team_match_stats": _records(team_stats),
        "fact_team_match_stats_wide": _records(team_stats_wide),
        "fact_player_match_stats": _records(player_stats),
        "fact_keeper_match_stats": _records(keeper_stats),
        "fact_lineups": _records(lineups),
        "fact_events": _records(events),
        "team_player_aggregates": _records(aggregates),
        "fact_understat_team_match_stats": _records(understat_team_stats_raw),
        "fact_understat_player_match_stats": _records(understat_player_stats_raw),
        "fact_understat_lineups": _records(understat_lineups_raw),
        "fact_understat_shot_events": _records(understat_events_raw),
        "fact_understat_player_season_stats": _records(understat_player_season_raw),
        "fact_whoscored_team_match_stats": _records(whoscored_team_stats_raw),
        "fact_whoscored_player_match_stats": _records(whoscored_player_stats_raw),
        "manifest": _records(manifest),
    }
    return payload


def export_canonical_json(source_dir: str | Path, output_path: str | Path | None = None) -> Path:
    payload = build_canonical_dataset(source_dir)
    source_dir = Path(source_dir)
    output_path = Path(output_path) if output_path is not None else source_dir / "canonical_dataset.json"
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return output_path
