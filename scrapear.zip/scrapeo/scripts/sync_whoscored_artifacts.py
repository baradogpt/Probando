from __future__ import annotations

from pathlib import Path
import sys

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from soccer_scraper.canonical_export import export_canonical_json


RAW = Path("data/raw/whoscored")
CLEAN = Path("data/clean/final_dataset")
CURATED = Path("data/final/final_dataset")


def _latest_run_dir() -> Path:
    runs = [p.parent.parent for p in RAW.glob("run_id=*/tables/match_team_stats.parquet")]
    if not runs:
        raise FileNotFoundError("No encuentro un run de WhoScored")
    return max(runs, key=lambda p: pd.read_parquet(p / "tables" / "match_team_stats.parquet").shape[0])


def main() -> None:
    run_dir = _latest_run_dir()
    tables = run_dir / "tables"
    team = pd.read_parquet(tables / "match_team_stats.parquet")
    player = pd.read_parquet(tables / "match_player_stats.parquet")

    CLEAN.mkdir(parents=True, exist_ok=True)
    CURATED.mkdir(parents=True, exist_ok=True)
    (CURATED / "facts").mkdir(parents=True, exist_ok=True)

    team.to_parquet(CLEAN / "whoscored_team_match_stats.parquet", index=False)
    team.to_csv(CLEAN / "whoscored_team_match_stats.csv", index=False)
    player.to_parquet(CLEAN / "whoscored_player_match_stats.parquet", index=False)
    player.to_csv(CLEAN / "whoscored_player_match_stats.csv", index=False)

    team.to_parquet(CURATED / "facts" / "fact_whoscored_team_match_stats.parquet", index=False)
    team.to_csv(CURATED / "facts" / "fact_whoscored_team_match_stats.csv", index=False)
    player.to_parquet(CURATED / "facts" / "fact_whoscored_player_match_stats.parquet", index=False)
    player.to_csv(CURATED / "facts" / "fact_whoscored_player_match_stats.csv", index=False)

    export_canonical_json(CLEAN, CURATED / "canonical_dataset.json")
    print(f"Synced WhoScored artifacts from {run_dir}")


if __name__ == "__main__":
    main()
