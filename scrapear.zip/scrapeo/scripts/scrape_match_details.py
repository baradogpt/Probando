import sys
import time
from pathlib import Path
import re

import undetected_chromedriver as uc
from selenium.webdriver.common.by import By

DATA_DIR = Path(r"D:\Proyectos\soccer_scraper_project_b\data")

REQUIRED_FILES = [
    "show.html",
    "teamstatistics.html",
    "live.html",
    "livestatistics.html",
    "livestatistics_home_summary.html",
    "livestatistics_home_offensive.html",
    "livestatistics_home_defensive.html",
    "livestatistics_home_passing.html",
    "livestatistics_away_summary.html",
    "livestatistics_away_offensive.html",
    "livestatistics_away_defensive.html",
    "livestatistics_away_passing.html",
]


def _save_html(match_dir: Path, filename: str, html: str) -> None:
    path = match_dir / filename
    try:
        path.write_text(html or "", encoding="utf-8")
    except Exception:
        pass


def _click_tab(label: str, driver) -> bool:
    candidates = []
    if label.startswith("#"):
        candidates.append(f"//a[@href='{label}']")
    candidates.extend([
        f"//a[normalize-space()='{label}']",
        f"//button[normalize-space()='{label}']",
        f"//*[self::li or self::span][normalize-space()='{label}']",
    ])
    for xpath in candidates:
        try:
            el = driver.find_element(By.XPATH, xpath)
            driver.execute_script("arguments[0].click();", el)
            time.sleep(2)
            return True
        except Exception:
            continue
    return False


def scrape_match(match_id: int, driver, match_root: Path):
    show_url = f"https://www.whoscored.com/matches/{match_id}/show/"
    
    if not (match_root / "show.html").exists():
        print(f"  {match_id}: show")
        driver.get(show_url)
        time.sleep(3)
        _save_html(match_root, "show.html", driver.page_source)
    
    if not (match_root / "teamstatistics.html").exists():
        team_url = show_url.replace("/show/", "/teamstatistics/")
        print(f"  {match_id}: team")
        driver.get(team_url)
        time.sleep(2)
        _save_html(match_root, "teamstatistics.html", driver.page_source)
    
    if not (match_root / "livestatistics.html").exists():
        live_url = show_url.replace("/show/", "/livestatistics/")
        print(f"  {match_id}: live")
        driver.get(live_url)
        time.sleep(2)
        _save_html(match_root, "livestatistics.html", driver.page_source)
    
    for side in ["home", "away"]:
        for tab in ["summary", "offensive", "defensive", "passing"]:
            filename = f"livestatistics_{side}_{tab}.html"
            if not (match_root / filename).exists():
                frag = f"#live-player-{side}-{tab}"
                if _click_tab(frag, driver):
                    html = driver.execute_script("return document.documentElement.outerHTML")
                    _save_html(match_root, filename, html if isinstance(html, str) else str(html))
    
    if not (match_root / "live.html").exists():
        live_show = show_url.replace("/show/", "/live/")
        print(f"  {match_id}: live2")
        driver.get(live_show)
        time.sleep(2)
        _save_html(match_root, "live.html", driver.page_source)
    
    files_ok = [f for f in REQUIRED_FILES if (match_root / f).exists()]
    print(f"  {match_id} DONE ({len(files_ok)}/{len(REQUIRED_FILES)})")


def main(season: str):
    season_dir = season.replace("/", "-")
    HTML_ROOT = DATA_DIR / "html" / "whoscored" / "matches" / season_dir
    profile_map = {
        "2022-2023": r"D:\Proyectos\soccer_scraper_sessions\whoscored_manual_visible_2022_2023",
        "2023-2024": r"D:\Proyectos\soccer_scraper_sessions\whoscored_manual_visible_2023_2024",
        "2024-2025": r"D:\Proyectos\soccer_scraper_sessions\whoscored_manual_visible_2024_2025",
    }
    profile_dir = profile_map.get(season)
    if not profile_dir or not Path(profile_dir).exists():
        print(f"No profile for {season}")
        return
    
    schedule_csv = DATA_DIR / "html" / "whoscored" / "matches" / season_dir / "schedule.csv"
    if not schedule_csv.exists():
        print(f"No schedule.csv for {season}")
        return
    
    import pandas as pd
    df = pd.read_csv(schedule_csv)
    match_ids = df["game_id"].dropna().astype(int).tolist()
    
    missing = []
    for mid in match_ids:
        match_root = HTML_ROOT / str(mid)
        if not match_root.exists():
            match_root.mkdir(parents=True, exist_ok=True)
        
        files_ok = [f for f in REQUIRED_FILES if (match_root / f).exists()]
        if len(files_ok) < len(REQUIRED_FILES):
            missing.append((mid, match_root))
    
    print(f"Season {season}: {len(match_ids)} matches, {len(missing)} need scraping")
    
    if not missing:
        print("All matches complete!")
        return
    
    def create_driver(profile_dir):
        options = uc.ChromeOptions()
        options.add_argument(f"--user-data-dir={profile_dir}")
        options.add_argument("--disable-gpu")
        driver = uc.Chrome(options=options, version_main=146)
        driver.implicitly_wait(15)
        return driver
    
    done = 0
    max_retries = 3
    
    while done < len(missing):
        try:
            print("Starting Chrome...")
            driver = create_driver(profile_dir)
            
            for mid, match_root in missing[done:]:
                try:
                    scrape_match(mid, driver, match_root)
                    done += 1
                    if done % 10 == 0:
                        print(f"Progress: {done}/{len(missing)}")
                except Exception as e:
                    print(f"ERROR {mid}: {e}")
                    driver.quit()
                    if done < len(missing) - 1:
                        print("Restarting Chrome...")
                        driver = create_driver(profile_dir)
                    else:
                        break
            
            driver.quit()
            break
            
        except Exception as e:
            print(f"Chrome error: {e}")
            if done < len(missing):
                print("Retrying...")
    
    print(f"DONE: {done} matches scraped")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python scrape_match_details.py <season>")
        print("  Example: python scrape_match_details.py 2022-2023")
    else:
        main(sys.argv[1])