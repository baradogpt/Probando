from __future__ import annotations

import json
import sys
from pathlib import Path
from datetime import datetime
from urllib.parse import unquote
import re
import unicodedata
from html import escape

import pandas as pd
from bs4 import BeautifulSoup
import streamlit as st

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

PROJECT_ROOT = Path(__file__).resolve().parents[2]
SCRAPEO_SRC = PROJECT_ROOT / "scrapeo" / "src"
if str(SCRAPEO_SRC) not in sys.path:
    sys.path.insert(0, str(SCRAPEO_SRC))

from soccer_scraper.config import load_config
from soccer_scraper.utils.io import read_table_if_exists


st.set_page_config(page_title="Consulta de datos de fútbol", page_icon="⚽", layout="wide")

st.markdown(
    """
    <style>
    .block-container {
        padding-top: 1.2rem;
        padding-bottom: 2rem;
        max-width: 1500px;
    }
    h1 {
        font-size: 2.9rem !important;
        line-height: 1.05;
        letter-spacing: -0.03em;
        margin-bottom: 0.35rem !important;
    }
    .hero-shell {
        margin: 0.2rem 0 1rem 0;
        padding: 1.1rem 1.25rem 1rem 1.25rem;
        border: 1px solid rgba(49, 51, 63, 0.10);
        border-radius: 20px;
        background: linear-gradient(135deg, rgba(248, 250, 255, 0.98), rgba(239, 244, 255, 0.88));
        box-shadow: 0 10px 30px rgba(46, 61, 73, 0.05);
    }
    .meta-row {
        display: flex;
        flex-wrap: wrap;
        gap: 0.5rem;
        margin-top: 0.9rem;
    }
    .meta-pill {
        display: inline-flex;
        align-items: center;
        gap: 0.45rem;
        padding: 0.45rem 0.75rem;
        border-radius: 999px;
        background: rgba(255,255,255,0.85);
        border: 1px solid rgba(49, 51, 63, 0.09);
        color: rgba(49, 51, 63, 0.82);
        font-size: 0.88rem;
        white-space: nowrap;
    }
    .meta-pill strong {
        color: rgba(49, 51, 63, 0.95);
    }
    .football-card {
        border: 1px solid rgba(49, 51, 63, 0.12);
        border-radius: 14px;
        padding: 14px 16px 13px 16px;
        background: rgba(255, 255, 255, 0.92);
        min-height: 96px;
    }
    .football-card .label {
        font-size: 0.82rem;
        color: rgba(49, 51, 63, 0.72);
        margin-bottom: 6px;
    }
    .football-card .value {
        font-size: 1.15rem;
        line-height: 1.25;
        white-space: normal;
        overflow-wrap: anywhere;
        word-break: break-word;
    }
    .timeline {
        margin-top: 0.4rem;
        border: 1px solid rgba(49, 51, 63, 0.10);
        border-radius: 16px;
        overflow: hidden;
        background: rgba(255, 255, 255, 0.88);
    }
    .timeline-row {
        display: flex;
        gap: 1rem;
        align-items: flex-start;
        padding: 0.7rem 0.9rem;
        border-top: 1px solid rgba(49, 51, 63, 0.08);
    }
    .timeline-row:first-child {
        border-top: none;
    }
    .timeline-minute {
        min-width: 3rem;
        font-weight: 700;
        font-size: 0.92rem;
        color: rgba(255, 255, 255, 0.95);
        background: #8b909a;
        padding: 0.2rem 0.45rem;
        border-radius: 7px;
        text-align: center;
        flex-shrink: 0;
    }
    .timeline-minute small {
        display: block;
        margin-top: 0.12rem;
        font-size: 0.76rem;
        font-weight: 600;
        opacity: 0.88;
        line-height: 1;
    }
    .timeline-content {
        flex: 1;
        line-height: 1.35;
        font-size: 0.96rem;
    }
    .timeline-main {
        display: flex;
        align-items: baseline;
        gap: 0.35rem;
        flex-wrap: wrap;
    }
    .timeline-assist {
        display: block;
        font-size: 0.78rem;
        color: rgba(49, 51, 63, 0.58);
        margin-top: 0.12rem;
    }
    .timeline-sub-out {
        color: #d9534f;
    }
    .timeline-sub-in {
        color: #2ca02c;
    }
    .timeline-team {
        color: rgba(49, 51, 63, 0.85);
        font-weight: 600;
        margin-right: 0.25rem;
    }
    .timeline-period {
        display: inline-block;
        font-size: 0.78rem;
        color: rgba(49, 51, 63, 0.68);
        background: rgba(49, 51, 63, 0.06);
        border-radius: 999px;
        padding: 0.1rem 0.5rem;
        margin-top: 0.25rem;
    }
    .timeline-score {
        color: rgba(49, 51, 63, 0.76);
        font-weight: 600;
    }
    .comparison-wrap {
        margin-top: 0.25rem;
    }
    .comparison-group {
        margin-bottom: 1rem;
        border: 1px solid rgba(49, 51, 63, 0.10);
        border-radius: 16px;
        overflow: hidden;
        background: rgba(255,255,255,0.90);
    }
    .comparison-group h4 {
        margin: 0;
        padding: 0.8rem 0.95rem 0.55rem 0.95rem;
        font-size: 0.98rem;
        color: rgba(49, 51, 63, 0.88);
        border-bottom: 1px solid rgba(49, 51, 63, 0.08);
        background: rgba(248, 250, 255, 0.7);
    }
    .comparison-card {
        border: 1px solid rgba(49, 51, 63, 0.10);
        border-radius: 16px;
        background: rgba(255,255,255,0.95);
        padding: 0.9rem 0.95rem 0.85rem 0.95rem;
        box-shadow: 0 6px 18px rgba(49, 51, 63, 0.04);
        margin-bottom: 0.8rem;
    }
    .comparison-card-title {
        font-size: 0.95rem;
        font-weight: 700;
        margin-bottom: 0.55rem;
        color: rgba(49, 51, 63, 0.94);
    }
    .comparison-card-values {
        display: flex;
        justify-content: space-between;
        gap: 0.75rem;
        font-size: 0.86rem;
        color: rgba(49, 51, 63, 0.83);
        margin-bottom: 0.55rem;
        flex-wrap: wrap;
    }
    .comparison-card-side {
        display: flex;
        flex-direction: column;
        gap: 0.1rem;
        min-width: 0;
        flex: 1 1 0;
    }
    .comparison-card-team {
        font-size: 0.78rem;
        color: rgba(49, 51, 63, 0.62);
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
    .comparison-card-value {
        font-size: 2.05rem;
        line-height: 1;
        font-weight: 800;
        color: rgba(24, 28, 40, 0.95);
    }
    .comparison-card-bar {
        height: 10px;
        background: rgba(49, 51, 63, 0.06);
        border-radius: 999px;
        overflow: hidden;
        display: flex;
    }
    .comparison-card-home {
        height: 100%;
        background: linear-gradient(90deg, #5b8def, #7ca6ff);
    }
    .comparison-card-away {
        height: 100%;
        background: linear-gradient(90deg, #ff7f7f, #ff9b8f);
    }
    .comparison-row {
        padding: 0.75rem 0.95rem;
        border-top: 1px solid rgba(49, 51, 63, 0.06);
    }
    .comparison-row:first-of-type {
        border-top: none;
    }
    .comparison-head {
        display: flex;
        justify-content: space-between;
        gap: 0.75rem;
        align-items: baseline;
        margin-bottom: 0.35rem;
    }
    .comparison-label {
        font-weight: 600;
        color: rgba(49, 51, 63, 0.92);
    }
    .comparison-values {
        display: flex;
        justify-content: space-between;
        gap: 1rem;
        margin-bottom: 0.35rem;
        font-size: 0.88rem;
        color: rgba(49, 51, 63, 0.84);
    }
    .comparison-bars {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 0.4rem;
        align-items: center;
    }
    .comparison-bar-wrap {
        height: 12px;
        background: rgba(49, 51, 63, 0.06);
        border-radius: 999px;
        overflow: hidden;
    }
    .comparison-bar-home {
        height: 100%;
        background: linear-gradient(90deg, #5b8def, #7ca6ff);
        border-radius: inherit;
    }
    .comparison-bar-away {
        height: 100%;
        background: linear-gradient(90deg, #ff7f7f, #ff9b8f);
        border-radius: inherit;
    }
    .comparison-empty {
        color: rgba(49, 51, 63, 0.55);
        font-size: 0.85rem;
        padding: 0.2rem 0;
    }
    </style>
    """,
    unsafe_allow_html=True,
)


TABLE_SPECS = {
    "match_wide": [
        "match_wide.parquet",
        "match_wide.csv",
        "final_dataset/match_wide.parquet",
        "final_dataset/match_wide.csv",
    ],
    "team_stats": [
        "facts/fact_team_match_stats.parquet",
        "facts/fact_team_match_stats.csv",
        "final_dataset/facts/fact_team_match_stats.parquet",
        "final_dataset/facts/fact_team_match_stats.csv",
    ],
    "team_stats_ws": [
        "facts/fact_whoscored_team_match_stats.parquet",
        "facts/fact_whoscored_team_match_stats.csv",
        "final_dataset/facts/fact_whoscored_team_match_stats.parquet",
        "final_dataset/facts/fact_whoscored_team_match_stats.csv",
    ],
    "player_stats": [
        "facts/fact_player_match_stats.parquet",
        "facts/fact_player_match_stats.csv",
        "final_dataset/facts/fact_player_match_stats.parquet",
        "final_dataset/facts/fact_player_match_stats.csv",
    ],
    "player_stats_ws": [
        "facts/fact_whoscored_player_match_stats.parquet",
        "facts/fact_whoscored_player_match_stats.csv",
        "final_dataset/facts/fact_whoscored_player_match_stats.parquet",
        "final_dataset/facts/fact_whoscored_player_match_stats.csv",
    ],
    "keeper_stats": [
        "facts/fact_keeper_match_stats.parquet",
        "facts/fact_keeper_match_stats.csv",
        "final_dataset/facts/fact_keeper_match_stats.parquet",
        "final_dataset/facts/fact_keeper_match_stats.csv",
    ],
    "lineups": [
        "facts/fact_lineups.parquet",
        "facts/fact_lineups.csv",
        "final_dataset/facts/fact_lineups.parquet",
        "final_dataset/facts/fact_lineups.csv",
    ],
    "events": [
        "facts/fact_events.parquet",
        "facts/fact_events.csv",
        "final_dataset/facts/fact_events.parquet",
        "final_dataset/facts/fact_events.csv",
    ],
    "manifest": [
        "manifest.csv",
        "final_dataset/manifest.csv",
    ],
}


COLUMN_LABELS = {
    "match_id": "ID del partido",
    "league": "Liga",
    "season": "Temporada",
    "date": "Fecha",
    "time": "Hora",
    "home": "Local",
    "away": "Visitante",
    "home_team": "Equipo local",
    "away_team": "Equipo visitante",
    "score": "Resultado",
    "venue": "Estadio",
    "attendance": "Asistencia",
    "referee": "Árbitro",
    "referee_name": "Árbitro",
    "match_report_url": "Informe del partido",
    "source_html_path": "HTML cacheado",
    "player": "Jugador",
    "team": "Equipo",
    "team_id": "ID del equipo",
    "player_id": "ID del jugador",
    "entity_type": "Tipo de fila",
    "unnamed_1_level_0": "Jugador",
    "unnamed_2_level_0_nation": "Nacionalidad",
    "unnamed_3_level_0_pos": "Posición",
    "unnamed_4_level_0_age": "Edad",
    "unnamed_5_level_0_min": "Minutos",
    "position_start": "Posición inicial",
    "formation": "Formación",
    "is_starter": "Titular",
    "played": "Jugó",
    "minute_on": "Minuto de entrada",
    "minute_off": "Minuto de salida",
    "role": "Rol",
    "role_raw": "Rol original",
    "official_name": "Nombre del árbitro",
    "official_id": "ID del árbitro",
    "source": "Fuente",
    "source_table": "Tabla fuente",
    "scraped_at": "Fecha de descarga",
    "parse_success": "Parseo correcto",
    "data_complete": "Datos completos",
}


METRIC_LABELS = {
    "performance_gls": "Goles",
    "performance_ast": "Asistencias",
    "performance_pk": "Goles de penalti",
    "performance_pkatt": "Penaltis lanzados",
    "performance_sh": "Tiros",
    "performance_sot": "Tiros a puerta",
    "performance_crdy": "Tarjetas amarillas",
    "performance_crdr": "Tarjetas rojas",
    "performance_fls": "Faltas cometidas",
    "performance_fld": "Faltas recibidas",
    "performance_off": "Fuera de juego",
    "performance_crs": "Centros",
    "performance_tklw": "Entradas ganadas",
    "performance_int": "Intercepciones",
    "performance_og": "Autogoles",
    "performance_pkwon": "Penaltis provocados",
    "performance_pkcon": "Penaltis cometidos",
    "passes_completed": "Pases completados",
    "passes_attempted": "Pases intentados",
    "pass_cmp_pct": "% de pase completado",
    "dribbles_completed": "Regates completados",
    "dribbles_attempted": "Regates intentados",
    "rating": "Valoración",
    "goals": "Goles",
    "assists": "Asistencias",
    "shots": "Tiros",
    "shots_on_target": "Tiros a puerta",
    "possession": "Posesión",
    "saves": "Paradas",
    "clearances": "Despejes",
    "tackles": "Entradas",
}


METRIC_GLOSSARY = [
    ("Goles", "Tantos marcados por el jugador o equipo."),
    ("Asistencias", "Pases que terminan en gol."),
    ("Tiros a puerta", "Remates que van entre los tres palos."),
    ("Centros", "Balones enviados desde banda al área."),
    ("Entradas ganadas", "Duelo defensivo recuperado con éxito."),
    ("Intercepciones", "Cortes de pase antes de que llegue al rival."),
    ("Faltas cometidas", "Infracciones hechas por el jugador o equipo."),
    ("Faltas recibidas", "Veces que el rival hace falta al jugador."),
    ("Regates completados", "Dribles superados con éxito."),
    ("Paradas", "Tiros detenidos por el portero."),
    ("Posesión", "Porcentaje de tiempo con la pelota."),
]


SUMMARY_METRICS = [
    ("tiros", "Tiros", "Ataque"),
    ("tiros_a_puerta", "Tiros a puerta", "Ataque"),
    ("tiros_fuera", "Tiros fuera", "Ataque"),
    ("tiros_bloqueados", "Tiros bloqueados", "Ataque"),
    ("understat_xg", "xG", "Ataque"),
    ("understat_npxg", "xG sin pen.", "Ataque"),
    ("corners", "Corners", "Ataque"),
    ("centros", "Centros", "Ataque"),
    ("pases_clave", "Pases clave", "Ataque"),
    ("regates_completados", "Regates completados", "Ataque"),
    ("regates_intentados", "Regates intentados", "Ataque"),
    ("regates_exitosos_pct", "% regates", "Ataque"),
    ("dribbled_past", "Regates recibidos", "Ataque"),
    ("dispossessed", "Balones perdidos", "Ataque"),
    ("fueras_de_juego", "Fueras de juego", "Ataque"),
    ("intercepciones", "Intercepciones", "Defensa"),
    ("entradas", "Entradas", "Defensa"),
    ("entradas_ganadas", "Entradas ganadas", "Defensa"),
    ("tackle_exitoso_pct", "% entradas", "Defensa"),
    ("duelos_aereos_ganados", "Duelos aéreos ganados", "Defensa"),
    ("duelos_aereos_pct", "% duelos aéreos", "Defensa"),
    ("aerials_offensive", "Duelos aéreos ofensivos", "Defensa"),
    ("aerials_defensive", "Duelos aéreos defensivos", "Defensa"),
    ("despejes", "Despejes", "Defensa"),
    ("understat_xga", "xGA", "Defensa"),
    ("understat_npxga", "xGA sin pen.", "Defensa"),
    ("understat_deep_allowed", "Profundidad concedida", "Defensa"),
    ("tarjetas_amarillas", "Tarjetas amarillas", "Disciplina"),
    ("tarjetas_rojas", "Tarjetas rojas", "Disciplina"),
    ("faltas_cometidas", "Faltas cometidas", "Disciplina"),
    ("faltas_recibidas", "Faltas recibidas", "Disciplina"),
    ("paradas", "Paradas", "Portería"),
    ("goles_encajados", "Goles encajados", "Portería"),
    ("porteria_cero", "Portería a cero", "Portería"),
    ("woodwork", "Al palo", "Portería"),
    ("posesion", "Posesión", "Control"),
    ("pases_completados", "Pases completados", "Control"),
    ("pases_intentados", "Pases intentados", "Control"),
    ("porcentaje_pase", "% de pase", "Control"),
    ("toques", "Toques", "Control"),
    ("understat_xpts", "xPts", "Control"),
    ("understat_ppda", "PPDA", "Control"),
    ("understat_ppda_allowed", "PPDA permitido", "Control"),
    ("understat_deep", "Profundidad", "Control"),
    ("ratings", "Valoración media", "General"),
]


SUMMARY_GROUP_ORDER = ["Ataque", "Defensa", "Disciplina", "Portería", "Control", "General"]


TECHNICAL_COLUMNS = {
    "match_id",
    "team_id",
    "player_id",
    "official_id",
    "source",
    "source_table",
    "source_url",
    "source_html_path",
    "scraped_at",
    "run_id",
    "cache_key",
    "parser_version",
    "parse_success",
    "data_complete",
    "validation_status",
}


def _candidate_paths(root: Path, rel: str) -> list[Path]:
    return [root / rel, root / rel.replace("final_dataset/", ""), root / rel.replace("facts/", ""), root / rel.replace("dimensions/", "")]


def _load_first_table(root: Path, candidates: list[str]) -> pd.DataFrame:
    for rel in candidates:
        for path in _candidate_paths(root, rel):
            df = read_table_if_exists(path)
            if df is not None and not df.empty:
                return df.copy()
    return pd.DataFrame()


@st.cache_data(show_spinner=False)
def load_tables(root_value: str) -> dict[str, pd.DataFrame]:
    root = Path(root_value)
    return {name: _load_first_table(root, candidates) for name, candidates in TABLE_SPECS.items()}


def _default_dataset_root() -> Path:
    repo_root = Path(__file__).resolve().parents[2]
    cfg_path = repo_root / "scrapeo" / "config" / "config.yml"
    if cfg_path.exists():
        try:
            cfg = load_config(cfg_path)
            final_dir = Path(cfg["project"].get("final_dir", repo_root / "data" / "final"))
            candidate = final_dir / "final_dataset"
            if candidate.exists():
                return candidate
        except Exception:
            pass

    candidates = [
        repo_root / "data" / "final" / "final_dataset",
        Path.cwd() / "data" / "final" / "final_dataset",
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate
    return candidates[0]


def _normalize_text(value: object) -> str:
    return str(value or "").strip().lower()


def _display_label(value: object) -> str:
    if value is None:
        return "Sin datos"
    try:
        if pd.isna(value):
            return "Sin datos"
    except Exception:
        pass
    text = str(value).strip()
    return "Sin datos" if not text or text.lower() == "nan" else text


def _row_value(row: pd.Series, key: str) -> object:
    if key not in row.index:
        return None
    values = row.loc[key]
    if isinstance(values, pd.Series):
        for item in values.tolist():
            if item is not None:
                try:
                    if not pd.isna(item):
                        return item
                except Exception:
                    return item
        return None
    return values


def _first_nonempty(*values: object) -> object:
    for value in values:
        if value is None:
            continue
        try:
            if pd.isna(value):
                continue
        except Exception:
            pass
        return value
    return None


def _format_date(value: object) -> str:
    if value is None:
        return "Sin datos"
    text = str(value).strip()
    if not text or text.lower() == "nan":
        return "Sin datos"
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y"):
        try:
            return datetime.strptime(text[:10], fmt).strftime("%d/%m/%Y")
        except Exception:
            pass
    m = re.search(r"/([A-Za-z]+)-(\d{1,2})-(\d{4})-", text)
    if m:
        month_map = {
            "january": 1,
            "february": 2,
            "march": 3,
            "april": 4,
            "may": 5,
            "june": 6,
            "july": 7,
            "august": 8,
            "september": 9,
            "october": 10,
            "november": 11,
            "december": 12,
        }
        month = month_map.get(m.group(1).lower())
        if month:
            dt = datetime(int(m.group(3)), month, int(m.group(2)))
            return dt.strftime("%d/%m/%Y")
    return text


def _to_number(value: object) -> float | None:
    if value is None:
        return None
    try:
        if pd.isna(value):
            return None
    except Exception:
        pass
    text = str(value).strip().replace("%", "").replace(",", "")
    if not text or text.lower() == "nan":
        return None
    try:
        return float(text)
    except Exception:
        return None


def _format_numeric(value: object, percent: bool = False) -> str:
    num = _to_number(value)
    if num is None:
        return "N/D"
    if percent:
        return f"{num:.0f}%"
    if float(num).is_integer():
        return str(int(num))
    return f"{num:.1f}"


def _card_html(label: str, value: str) -> str:
    return f"<div class='football-card'><div class='label'>{escape(label)}</div><div class='value'>{escape(value)}</div></div>"


def _pill_html(label: str, value: str) -> str:
    return f"<span class='meta-pill'><strong>{escape(label)}:</strong> {escape(value)}</span>"


def _parse_date_from_url(url: object) -> str:
    if url is None:
        return "Sin datos"
    text = unquote(str(url))
    matches = list(re.finditer(r"([A-Za-z]+)-(\d{1,2})-(\d{4})-", text))
    if not matches:
        return "Sin datos"
    m = matches[-1]
    month_map = {
        "january": 1,
        "february": 2,
        "march": 3,
        "april": 4,
        "may": 5,
        "june": 6,
        "july": 7,
        "august": 8,
        "september": 9,
        "october": 10,
        "november": 11,
        "december": 12,
    }
    month = month_map.get(m.group(1).lower())
    if not month:
        return "Sin datos"
    try:
        return datetime(int(m.group(3)), month, int(m.group(2))).strftime("%d/%m/%Y")
    except Exception:
        return "Sin datos"


def _extract_html_metadata(source_html_path: object) -> dict[str, str]:
    path = Path(str(source_html_path or ""))
    if not path.exists():
        return {"venue": "Sin datos", "attendance": "Sin datos"}
    try:
        html = path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return {"venue": "Sin datos", "attendance": "Sin datos"}

    venue = "Sin datos"
    attendance = "Sin datos"
    m = re.search(r"<strong><small>Venue</small></strong>:\s*<small>(.*?)</small>", html, re.I | re.S)
    if m:
        venue = re.sub(r"<.*?>", "", m.group(1)).replace("&nbsp;", " ").strip() or "Sin datos"
    m = re.search(r"<strong><small>Attendance</small></strong>:\s*<small>(.*?)</small>", html, re.I | re.S)
    if m:
        attendance = re.sub(r"<.*?>", "", m.group(1)).replace("&nbsp;", " ").strip() or "Sin datos"
    return {"venue": venue, "attendance": attendance}


def _extract_html_team_extra_stats(source_html_path: object) -> dict[str, dict[str, str]]:
    path = Path(str(source_html_path or ""))
    if not path.exists():
        return {}
    try:
        html = path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return {}

    block_match = re.search(r'<div id="team_stats_extra">(.*?)</div>\s*</div>', html, re.I | re.S)
    if not block_match:
        return {}
    block = block_match.group(1)
    rows = re.findall(r'<div>(\d+)</div><div>([^<]+)</div><div>(\d+)</div>', block, re.I | re.S)
    if not rows:
        return {}

    team_headers = [h.replace("&nbsp;", " ").strip() for h in re.findall(r'<div class="th">(.*?)</div>', block, re.I | re.S)]
    non_empty_headers = [h for h in team_headers if h]
    home = non_empty_headers[0] if len(non_empty_headers) >= 1 else ""
    away = non_empty_headers[1] if len(non_empty_headers) >= 2 else ""

    out: dict[str, dict[str, str]] = {}
    for left, label, right in rows:
        key = label.strip().lower().replace(" ", "_")
        out[key] = {home: left, away: right}
    return out


def _find_fbref_match_html(match_row: pd.Series) -> Path | None:
    repo_root = Path(__file__).resolve().parents[2]
    report_url = str(_row_value(match_row, "match_report_url") or "").strip()
    source_html = Path(str(_row_value(match_row, "source_html_path") or ""))
    if source_html.exists():
        try:
            if not report_url or report_url in source_html.read_text(encoding="utf-8", errors="ignore"):
                return source_html
        except Exception:
            pass

    cache_root = repo_root / "data" / "cache" / "fbref_html"
    if not cache_root.exists():
        return source_html if source_html.exists() else None

    for path in cache_root.rglob("*.html"):
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        if report_url and report_url in text:
            return path
    return source_html if source_html.exists() else None


def _parse_fbref_match_events(html: str, home_team: str, away_team: str) -> pd.DataFrame:
    soup = BeautifulSoup(html, "html.parser")
    rows: list[dict[str, object]] = []
    for event in soup.select("div.event"):
        classes = list(event.get("class") or [])
        if not classes or len(classes) < 2:
            continue
        side = classes[1]
        icon = event.select_one("div.event_icon")
        if not icon:
            continue
        event_type = ""
        icon_classes = list(icon.get("class") or [])
        for cls in icon_classes:
            if cls != "event_icon":
                event_type = cls.strip().lower()
                break
        if event_type not in {"goal", "yellow_card", "red_card", "substitute_in", "penalty_goal"}:
            continue

        blocks = event.find_all("div", recursive=False)
        if not blocks:
            continue
        minute_text = blocks[0].get_text(" ", strip=True)
        m = re.search(r"(\d+)(?:\+\d+)?", minute_text)
        minute = float(m.group(1)) if m else None
        score_match = re.search(r"(\d+\s*[:\-]\s*\d+)", minute_text)
        score_after = score_match.group(1).replace(":", ":").strip() if score_match else ""
        anchors = [a.get_text(" ", strip=True) for a in event.find_all("a")]
        player = anchors[0] if anchors else ""
        assist = ""
        outgoing = ""
        small_text = event.find("small")
        if event_type in {"goal", "penalty_goal"} and len(anchors) > 1:
            assist = anchors[1]
        if event_type == "substitute_in" and len(anchors) > 1:
            outgoing = anchors[1]
        team_alt = ""
        img = event.select_one("img.teamlogo")
        if img and img.get("alt"):
            team_alt = str(img.get("alt", "")).replace(" Club Crest", "").strip()
        team = home_team if side == "a" else away_team if side == "b" else team_alt

        raw_text = " ".join(event.get_text(" ", strip=True).split())
        if event_type == "goal" and assist:
            raw_text = f"{minute_text} {player} Assist: {assist} Goal {score_after}"
        elif event_type == "penalty_goal":
            raw_text = f"{minute_text} {player} Penalty Goal {score_after}"
        elif event_type == "substitute_in" and outgoing:
            raw_text = f"{minute_text} {player} for {outgoing} Substitute"

        rows.append(
            {
                "minute": minute,
                "second": None,
                "period": 1 if (minute or 0) <= 45 else 2,
                "event_type": event_type,
                "team": team,
                "player": player,
                "score_after_event": score_after,
                "raw_text": raw_text,
                "home_team": home_team,
                "away_team": away_team,
            }
        )

    return pd.DataFrame(rows)


def _load_fbref_match_events(match_row: pd.Series) -> pd.DataFrame:
    info = _derive_match_info(match_row, pd.DataFrame(), pd.DataFrame())
    html_path = _find_fbref_match_html(match_row)
    if not html_path or not html_path.exists():
        return pd.DataFrame()
    try:
        html = html_path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return pd.DataFrame()
    return _parse_fbref_match_events(html, info["local"], info["visitante"])


def _find_whoscored_live_file(match_row: pd.Series) -> Path | None:
    repo_root = Path(__file__).resolve().parents[2]
    home = _normalize_text(_first_nonempty(_row_value(match_row, "home_team"), _row_value(match_row, "home")))
    away = _normalize_text(_first_nonempty(_row_value(match_row, "away_team"), _row_value(match_row, "away")))
    date = _normalize_text(_row_value(match_row, "date"))

    candidates = sorted(repo_root.joinpath("data", "cache").rglob("*.html"), key=lambda p: p.stat().st_mtime, reverse=True)
    for path in candidates:
        try:
            html = path.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        html_l = html.lower()
        if "match-centre-stat" not in html_l or "live" not in html_l:
            continue
        if home and away and home in html_l and away in html_l:
            return path
        if date and date in html_l:
            return path
    return None


def _extract_whoscored_match_stats(match_row: pd.Series) -> dict[str, dict[str, float]]:
    path = _find_whoscored_live_file(match_row)
    if path is None or not path.exists():
        return {}
    try:
        html = path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return {}

    stats: dict[str, dict[str, float]] = {}
    for match in re.finditer(
        r'data-for="([^"]+)"[^>]*>\s*<h4>([^<]+)</h4>.*?data-field="home" data-value="([0-9.]+)">([^<]+)</span>.*?data-field="away" data-value="([0-9.]+)">([^<]+)</span>',
        html,
        re.I | re.S,
    ):
        key = match.group(1).strip()
        if key in stats:
            continue
        stats[key] = {
            "home": float(match.group(3)),
            "away": float(match.group(5)),
        }
    return stats


UNDERSTAT_LEAGUE_MAP = {
    "ESP-La Liga": 4,
    "La Liga": 4,
    "La liga": 4,
}


@st.cache_data(show_spinner=False)
def _load_understat_season_json(league_id: int, year: int) -> dict[str, object] | None:
    repo_root = Path(__file__).resolve().parents[2]
    path = repo_root / "data" / "cache" / "Understat" / f"league_{league_id}_season_{year}.json"
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def _normalize_name(value: object) -> str:
    text = _display_label(value)
    text = unicodedata.normalize("NFKD", text)
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    return re.sub(r"[^a-z0-9]+", "", text.lower())


def _date_key(value: object) -> str:
    text = _display_label(value)
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y"):
        try:
            return datetime.strptime(text[:10], fmt).strftime("%Y-%m-%d")
        except Exception:
            pass
    m = re.search(r"([A-Za-z]+)-(\d{1,2})-(\d{4})", text)
    if m:
        month_map = {
            "january": 1,
            "february": 2,
            "march": 3,
            "april": 4,
            "may": 5,
            "june": 6,
            "july": 7,
            "august": 8,
            "september": 9,
            "october": 10,
            "november": 11,
            "december": 12,
        }
        month = month_map.get(m.group(1).lower())
        if month:
            return datetime(int(m.group(3)), month, int(m.group(2))).strftime("%Y-%m-%d")
    return text[:10]


def _understat_team_history(season_json: dict[str, object] | None, team_name: str, match_date: str, side: str) -> dict[str, object] | None:
    if not season_json:
        return None
    teams = season_json.get("teams", {})
    if not isinstance(teams, dict):
        return None
    team_key = None
    wanted = _normalize_name(team_name)
    for _, team in teams.items():
        if _normalize_name(team.get("title")) == wanted:
            team_key = team
            break
    if not team_key:
        return None
    history = team_key.get("history", [])
    if not isinstance(history, list):
        return None
    wanted_date = _date_key(match_date)
    for entry in history:
        if _date_key(entry.get("date")) == wanted_date and (not side or str(entry.get("h_a")) == side):
            return entry
    return None


def _understat_player_season_table(season_json: dict[str, object] | None, team_name: str, squad_players: list[str]) -> pd.DataFrame:
    if not season_json:
        return pd.DataFrame()
    players = season_json.get("players", [])
    if not isinstance(players, list):
        return pd.DataFrame()
    wanted_team = _normalize_name(team_name)
    wanted_players = {_normalize_name(p) for p in squad_players if p}
    rows = []
    for player in players:
        if _normalize_name(player.get("team_title")) != wanted_team:
            continue
        if wanted_players and _normalize_name(player.get("player_name")) not in wanted_players:
            continue
        rows.append(
            {
                "Jugador": player.get("player_name"),
                "xA": float(player.get("xA", 0) or 0),
                "xG": float(player.get("xG", 0) or 0),
                "Goles": int(float(player.get("goals", 0) or 0)),
                "Asistencias": int(float(player.get("assists", 0) or 0)),
                "Tiros": int(float(player.get("shots", 0) or 0)),
                "Pases clave": int(float(player.get("key_passes", 0) or 0)),
                "xGChain": float(player.get("xGChain", 0) or 0),
                "xGBuildup": float(player.get("xGBuildup", 0) or 0),
            }
        )
    if not rows:
        return pd.DataFrame()
    df = pd.DataFrame(rows).sort_values(by=["xA", "xG"], ascending=False)
    return df


def _understat_ppda_ratio(entry: dict[str, object] | None) -> float:
    if not entry:
        return 0.0
    ppda = entry.get("ppda", {})
    if not isinstance(ppda, dict):
        return 0.0
    attacks = float(ppda.get("att", 0) or 0)
    actions = float(ppda.get("def", 0) or 0)
    if actions <= 0:
        return 0.0
    return attacks / actions


def _understat_value(entry: dict[str, object] | None, key: str) -> object:
    if not entry:
        return None
    value = entry.get(key)
    return value if value is not None else None


def _understat_match_context(match_row: pd.Series) -> tuple[dict[str, str], dict[str, object] | None, dict[str, object] | None, dict[str, object] | None]:
    info = _derive_match_info(match_row, pd.DataFrame(), pd.DataFrame())
    league_id = UNDERSTAT_LEAGUE_MAP.get(info["liga"], 4)
    year = _match_date_year(match_row)
    if year is None:
        return info, None, None, None
    season_json = _load_understat_season_json(league_id, year)
    if not season_json:
        return info, None, None, None
    match_date = _date_key(_row_value(match_row, "date"))
    home_hist = _understat_team_history(season_json, info["local"], match_date, "h")
    away_hist = _understat_team_history(season_json, info["visitante"], match_date, "a")
    return info, season_json, home_hist, away_hist


def _attach_understat_player_metrics(match_row: pd.Series, player_stats: pd.DataFrame) -> pd.DataFrame:
    if player_stats.empty or not {"player", "team"}.issubset(player_stats.columns):
        return player_stats
    info, season_json, _, _ = _understat_match_context(match_row)
    if not season_json:
        return player_stats

    rows: list[pd.DataFrame] = []
    for team in (info["local"], info["visitante"]):
        team_players = player_stats[player_stats["team"].astype(str).str.strip().eq(team.strip())]
        if team_players.empty:
            continue
        squad_players = [p for p in team_players["player"].astype(str).tolist() if p.strip().lower() != "nan"]
        understat_team = _understat_player_season_table(season_json, team, squad_players)
        if understat_team.empty:
            continue
        understat_team = understat_team.rename(
            columns={
                "xA": "xA",
                "xG": "xG",
                "xGChain": "xGChain",
                "xGBuildup": "xGBuildup",
            }
        )
        understat_team["_join_key"] = understat_team["Jugador"].apply(_normalize_name)
        understat_team["_team_key"] = _normalize_name(team)
        rows.append(understat_team)

    if not rows:
        return player_stats

    understat_df = pd.concat(rows, ignore_index=True)
    base = player_stats.copy()
    base["_join_key"] = base["player"].apply(_normalize_name)
    base["_team_key"] = base["team"].apply(_normalize_name)
    merged = base.merge(
        understat_df[["_join_key", "_team_key", "xA", "xG", "xGChain", "xGBuildup"]],
        on=["_join_key", "_team_key"],
        how="left",
    )
    return merged.drop(columns=[c for c in ["_join_key", "_team_key"] if c in merged.columns])


def _match_date_year(match_row: pd.Series) -> int | None:
    raw = _first_nonempty(_row_value(match_row, "date"), _row_value(match_row, "date_schedule"), _parse_date_from_url(_row_value(match_row, "match_report_url")))
    text = _display_label(raw)
    for fmt in ("%d/%m/%Y", "%Y-%m-%d"):
        try:
            return datetime.strptime(text[:10], fmt).year
        except Exception:
            pass
    return None


def _extract_final_score(events: pd.DataFrame) -> str:
    if events.empty:
        return "Sin datos"
    df = events.copy()
    if "minute" in df.columns:
        df = df.sort_values(by=["minute", "second"], na_position="last")
    if "score_after_event" in df.columns:
        val = df["score_after_event"].dropna().astype(str).tail(1)
        if not val.empty:
            return val.iloc[0].replace(":", " - ")
    if {"home_score_after_event", "away_score_after_event"}.issubset(df.columns):
        last = df.iloc[-1]
        home = last.get("home_score_after_event")
        away = last.get("away_score_after_event")
        if pd.notna(home) and pd.notna(away):
            return f"{int(home)} - {int(away)}"
    return "Sin datos"


def _parse_score_pair(score_text: object) -> tuple[float | None, float | None]:
    text = str(score_text or "").strip()
    m = re.search(r"(\d+)\s*[-:]\s*(\d+)", text)
    if not m:
        return None, None
    return float(m.group(1)), float(m.group(2))


def _minute_label(row: pd.Series) -> str:
    minute = row.get("minute")
    second = row.get("second")
    if pd.isna(minute):
        return "—"
    minute_int = int(float(minute))
    label = f"{minute_int}'"
    if pd.notna(second):
        label += f":{int(float(second)):02d}"
    if bool(row.get("stoppage_time", False)):
        label += "+"
    return label


def _period_short_label(row: pd.Series) -> str:
    try:
        period = int(float(row.get("period", 0) or 0))
    except Exception:
        period = 0
    return {1: "1ª parte", 2: "2ª parte", 3: "Prórroga"}.get(period, "")


def _team_metric_value(team_stats: pd.DataFrame, team: str, metric: str) -> object:
    if team_stats.empty:
        return None
    if {"team", "metric"}.issubset(team_stats.columns):
        subset = team_stats[
            team_stats["team"].astype(str).str.strip().eq(team.strip())
            & team_stats["metric"].astype(str).str.strip().eq(metric)
        ]
        if subset.empty:
            return None
        row = subset.iloc[0]
        if metric == "possession":
            if pd.notna(row.get("value_pct")):
                return float(row.get("value_pct")) * 100
            return _to_number(row.get("value"))
        if pd.notna(row.get("value_made")):
            return row.get("value_made")
        return _to_number(row.get("value_raw")) or _to_number(row.get("value"))

    if "team" not in team_stats.columns:
        return None
    subset = team_stats[team_stats["team"].astype(str).str.strip().eq(team.strip())]
    if subset.empty:
        return None
    row = subset.iloc[0]
    mapping = {
        "corners": "corners",
        "passes_completed": "passes_completed",
        "passes_attempted": "passes_attempted",
        "pass_cmp_pct": "pass_cmp_pct",
        "key_passes": "key_passes",
        "dribbles_completed": "dribbles_completed",
        "dribbles_attempted": "dribbles_attempted",
        "tackles_total": "tackles_total",
        "tackles_won": "tackles_won",
        "tackle_success_pct": "tackle_success_pct",
        "aerials_total": "aerials_total",
        "aerials_won": "aerials_won",
        "aerial_success_pct": "aerial_success_pct",
        "clearances": "clearances",
        "interceptions": "interceptions",
        "offsides_caught": "offsides_caught",
        "fouls_committed": "fouls_committed",
        "shots_total": "shots_total",
        "shots_on_target": "shots_on_target",
        "errors": "errors",
        "claims_high": "claims_high",
        "possession": "possession",
        "saves": "saves",
    }
    col = mapping.get(metric)
    if not col or col not in row.index:
        return None
    value = row.get(col)
    if metric == "possession" and pd.notna(value):
        if isinstance(value, str) and value.endswith("%"):
            return _to_number(value)
        return float(value) * 100 if 0 <= float(value) <= 1 else _to_number(value)
    if metric in {"pass_cmp_pct", "tackle_success_pct", "aerial_success_pct"} and pd.notna(value):
        return value * 100 if isinstance(value, (int, float)) and value <= 1 else _to_number(value)
    return _to_number(value)


def _player_metric_sum(player_stats: pd.DataFrame, team: str, metric: str) -> float | None:
    if player_stats.empty or not {"team", metric}.issubset(player_stats.columns):
        return None
    subset = player_stats[player_stats["team"].astype(str).str.strip().eq(team.strip())]
    if subset.empty:
        return None
    series = pd.to_numeric(subset[metric], errors="coerce")
    total = float(series.fillna(0).sum())
    return total


def _player_ws_metric_sum(player_stats_ws: pd.DataFrame, team: str, metric: str) -> float | None:
    if player_stats_ws.empty or not {"team", metric}.issubset(player_stats_ws.columns):
        return None
    subset = player_stats_ws[player_stats_ws["team"].astype(str).str.strip().eq(team.strip())]
    if subset.empty:
        return None
    series = pd.to_numeric(subset[metric], errors="coerce")
    return float(series.fillna(0).sum())


def _player_ws_metric_mean(player_stats_ws: pd.DataFrame, team: str, metric: str) -> float | None:
    if player_stats_ws.empty or not {"team", metric}.issubset(player_stats_ws.columns):
        return None
    subset = player_stats_ws[player_stats_ws["team"].astype(str).str.strip().eq(team.strip())]
    if subset.empty:
        return None
    series = pd.to_numeric(subset[metric], errors="coerce")
    series = series.dropna()
    if series.empty:
        return None
    return float(series.mean())


def _team_ws_value(team_stats_ws: pd.DataFrame, team: str, metric: str) -> object:
    if team_stats_ws.empty or "team" not in team_stats_ws.columns or metric not in team_stats_ws.columns:
        return None
    subset = team_stats_ws[team_stats_ws["team"].astype(str).str.strip().eq(team.strip())]
    if subset.empty:
        return None
    return _to_number(subset.iloc[0].get(metric))


def _build_whoscored_match_stats(team_stats_ws: pd.DataFrame, player_stats_ws: pd.DataFrame) -> dict[str, dict[str, float]]:
    stats: dict[str, dict[str, float]] = {}

    def put(key: str, home: object = None, away: object = None) -> None:
        if home is None and away is None:
            return
        stats[key] = {
            "home": float(_to_number(home) or 0),
            "away": float(_to_number(away) or 0),
        }

    if not team_stats_ws.empty and {"team", "side"}.issubset(team_stats_ws.columns):
        home_row = team_stats_ws[team_stats_ws["side"].astype(str).str.lower().eq("home")].head(1)
        away_row = team_stats_ws[team_stats_ws["side"].astype(str).str.lower().eq("away")].head(1)
        if not home_row.empty and not away_row.empty:
            h = home_row.iloc[0]
            a = away_row.iloc[0]
            for key, col in {
                "cornersTotal": "corners",
                "passesTotal": "passes_attempted",
                "passesAccurate": "passes_completed",
                "passSuccess": "pass_cmp_pct",
                "passesKey": "key_passes",
                "dribblesWon": "dribbles_completed",
                "dribblesAttempted": "dribbles_attempted",
                "dribbleSuccess": "dribble_success_pct",
                "tacklesTotal": "tackles_total",
                "tackleSuccessful": "tackles_won",
                "tackleSuccess": "tackle_success_pct",
                "aerialsWon": "aerials_won",
                "aerialSuccess": "aerial_success_pct",
                "interceptions": "interceptions",
                "clearances": "clearances",
                "offsidesCaught": "offsides_caught",
                "foulsCommited": "fouls_committed",
                "shotsTotal": "shots_total",
                "shotsOnTarget": "shots_on_target",
                "errors": "errors",
                "claimsHigh": "claims_high",
            }.items():
                put(key, h.get(col), a.get(col))

    if not player_stats_ws.empty and {"team", "rating"}.issubset(player_stats_ws.columns):
        home_rows = player_stats_ws[player_stats_ws["side"].astype(str).str.lower().eq("home")]
        away_rows = player_stats_ws[player_stats_ws["side"].astype(str).str.lower().eq("away")]
        home_rating = _player_ws_metric_mean(player_stats_ws, str(home_rows.iloc[0]["team"]) if not home_rows.empty else "", "rating")
        away_rating = _player_ws_metric_mean(player_stats_ws, str(away_rows.iloc[0]["team"]) if not away_rows.empty else "", "rating")
        put("ratings", home_rating, away_rating)

    return stats


def _merge_whoscored_player_view(base_players: pd.DataFrame, ws_players: pd.DataFrame) -> pd.DataFrame:
    if base_players.empty or ws_players.empty:
        return base_players
    if not {"team", "player"}.issubset(base_players.columns):
        return base_players
    if not {"team", "player_name_ws"}.issubset(ws_players.columns):
        return base_players

    base = base_players.copy()
    base["_team_key"] = base["team"].astype(str).map(_normalize_name)
    base["_player_key"] = base["player"].astype(str).map(_normalize_name)

    extra = ws_players.copy()
    extra = extra.rename(columns={"player_name_ws": "player"})
    extra["_team_key"] = extra["team"].astype(str).map(_normalize_name)
    extra["_player_key"] = extra["player"].astype(str).map(_normalize_name)

    keep_cols = [c for c in ["_team_key", "_player_key", "rating", "passes_completed", "passes_attempted", "key_passes", "dribbles_completed", "dribbles_attempted", "position_start", "starting_position", "is_starter"] if c in extra.columns]
    extra = extra[keep_cols].drop_duplicates(subset=["_team_key", "_player_key"], keep="first")
    merged = base.merge(extra, on=["_team_key", "_player_key"], how="left")
    return merged.drop(columns=[c for c in ["_team_key", "_player_key"] if c in merged.columns])


def _event_count(events: pd.DataFrame, team: str, event_types: set[str]) -> int | None:
    if events.empty or not {"team", "event_type"}.issubset(events.columns):
        return None
    subset = events[
        events["team"].astype(str).str.strip().eq(team.strip())
        & events["event_type"].astype(str).str.strip().isin(event_types)
    ]
    return int(len(subset))


def _dedupe_events(events: pd.DataFrame) -> pd.DataFrame:
    if events.empty:
        return events
    df = events.copy()
    if "event_id" in df.columns:
        return df.drop_duplicates(subset=["event_id"], keep="first")
    subset_cols = [c for c in ["match_id", "minute", "second", "period", "event_type", "team", "player", "score_after_event", "raw_text"] if c in df.columns]
    if subset_cols:
        return df.drop_duplicates(subset=subset_cols, keep="first")
    return df


def _filter_events_to_roster(events: pd.DataFrame, player_stats: pd.DataFrame, keeper_stats: pd.DataFrame, lineups: pd.DataFrame) -> pd.DataFrame:
    if events.empty:
        return events
    roster: set[str] = set()
    for frame in (player_stats, keeper_stats, lineups):
        if frame.empty or "player" not in frame.columns:
            continue
        roster.update({p for p in frame["player"].astype(str).tolist() if p.strip() and p.strip().lower() != "nan"})
    if not roster or "player" not in events.columns:
        return events
    roster_norm = {_normalize_name(name) for name in roster}
    out = events.copy()
    player_norm = out["player"].astype(str).map(_normalize_name)
    keep = out["player"].astype(str).str.strip().eq("") | player_norm.isin(roster_norm)
    return out[keep]


def _ws_value(ws_stats: dict[str, dict[str, float]], key: str, side: str | None) -> object:
    stat = ws_stats.get(key)
    if not stat:
        return None
    if side is None:
        return None
    return stat.get(side)


def _team_summary_value(team_stats: pd.DataFrame, player_stats: pd.DataFrame, keeper_stats: pd.DataFrame, events: pd.DataFrame, html_extra: dict[str, dict[str, str]], ws_stats: dict[str, dict[str, float]], team: str, key: str, side: str | None = None, score_pair: tuple[float | None, float | None] | None = None, understat_hist: dict[str, object] | None = None) -> object:
    if key == "tiros":
        return _ws_value(ws_stats, "shotsTotal", side) if side else _player_metric_sum(player_stats, team, "performance_sh")
    if key == "tiros_a_puerta":
        return _ws_value(ws_stats, "shotsOnTarget", side) if side else (_team_metric_value(team_stats, team, "shots_on_target") or _player_metric_sum(player_stats, team, "performance_sot"))
    if key == "tiros_fuera":
        shots = _team_summary_value(team_stats, player_stats, keeper_stats, events, html_extra, ws_stats, team, "tiros", side)
        sot = _team_summary_value(team_stats, player_stats, keeper_stats, events, html_extra, ws_stats, team, "tiros_a_puerta", side)
        if shots is None or sot is None:
            return None
        return max(float(shots) - float(sot), 0.0)
    if key == "tiros_bloqueados":
        value = _ws_value(ws_stats, "shotsBlocked", side) if side else None
        if value is not None:
            return value
        return None
    if key == "tarjetas_amarillas":
        return _event_count(events, team, {"yellow_card"}) or _player_metric_sum(player_stats, team, "performance_crdy")
    if key == "tarjetas_rojas":
        return _event_count(events, team, {"red_card"}) or _player_metric_sum(player_stats, team, "performance_crdr")
    if key == "faltas_cometidas":
        return _ws_value(ws_stats, "foulsCommited", side) if side else _player_metric_sum(player_stats, team, "performance_fls")
    if key == "corners":
        value = _ws_value(ws_stats, "cornersTotal", side) if side else _team_metric_value(team_stats, team, "corners")
        if value is not None:
            return value
        extra = html_extra.get("corners")
        if extra and team in extra:
            return _to_number(extra.get(team))
        return None
    if key == "centros":
        extra = html_extra.get("crosses")
        if extra and team in extra:
            return _to_number(extra.get(team))
        if not player_stats.empty and {"team", "performance_crs"}.issubset(player_stats.columns):
            subset = player_stats[player_stats["team"].astype(str).str.strip().eq(team.strip())]
            if not subset.empty:
                return pd.to_numeric(subset["performance_crs"], errors="coerce").fillna(0).sum()
        return None
    if key == "intercepciones":
        value = _ws_value(ws_stats, "interceptions", side) if side else None
        if value is not None:
            return value
        extra = html_extra.get("interceptions")
        if extra and team in extra:
            return _to_number(extra.get(team))
        if not player_stats.empty and {"team", "performance_int"}.issubset(player_stats.columns):
            subset = player_stats[player_stats["team"].astype(str).str.strip().eq(team.strip())]
            if not subset.empty:
                return pd.to_numeric(subset["performance_int"], errors="coerce").fillna(0).sum()
        return None
    if key == "entradas":
        value = _ws_value(ws_stats, "tacklesTotal", side) if side else None
        if value is not None:
            return value
        if not player_stats.empty and {"team", "performance_tklw"}.issubset(player_stats.columns):
            subset = player_stats[player_stats["team"].astype(str).str.strip().eq(team.strip())]
            if not subset.empty:
                # Fallback simple: entradas totales aproximadas por tackles won
                return pd.to_numeric(subset["performance_tklw"], errors="coerce").fillna(0).sum()
        return None
    if key == "entradas_ganadas":
        value = _ws_value(ws_stats, "tackleSuccessful", side) if side else None
        if value is not None:
            return value
        if not player_stats.empty and {"team", "performance_tklw"}.issubset(player_stats.columns):
            subset = player_stats[player_stats["team"].astype(str).str.strip().eq(team.strip())]
            if not subset.empty:
                return pd.to_numeric(subset["performance_tklw"], errors="coerce").fillna(0).sum()
        return None
    if key == "tackles_totales":
        value = _ws_value(ws_stats, "tacklesTotal", side) if side else None
        if value is not None:
            return value
        return None
    if key == "tackle_exitoso_pct":
        value = _ws_value(ws_stats, "tackleSuccess", side) if side else None
        if value is not None:
            return value
        return None
    if key == "duelos_aereos_ganados":
        value = _ws_value(ws_stats, "aerialsWon", side) if side else None
        if value is not None:
            return value
        return None
    if key == "duelos_aereos_pct":
        value = _ws_value(ws_stats, "aerialSuccess", side) if side else None
        if value is not None:
            return value
        return None
    if key == "despejes":
        value = _ws_value(ws_stats, "clearances", side) if side else None
        if value is not None:
            return value
        extra = html_extra.get("clearances")
        if extra and team in extra:
            return _to_number(extra.get(team))
        return None
    if key == "errores":
        value = _ws_value(ws_stats, "errors", side) if side else None
        if value is not None:
            return value
        return None
    if key == "fueras_de_juego":
        value = _ws_value(ws_stats, "offsidesCaught", side) if side else None
        if value is not None:
            return value
        extra = html_extra.get("offsides")
        if extra and team in extra:
            return _to_number(extra.get(team))
        if not player_stats.empty and {"team", "performance_off"}.issubset(player_stats.columns):
            subset = player_stats[player_stats["team"].astype(str).str.strip().eq(team.strip())]
            if not subset.empty:
                return pd.to_numeric(subset["performance_off"], errors="coerce").fillna(0).sum()
        return None
    if key == "paradas":
        value = _ws_value(ws_stats, "totalSaves", side) if side else None
        if value is not None:
            return value
        if not keeper_stats.empty and {"team", "shot_stopping_saves"}.issubset(keeper_stats.columns):
            subset = keeper_stats[keeper_stats["team"].astype(str).str.strip().eq(team.strip())]
            if not subset.empty:
                return pd.to_numeric(subset["shot_stopping_saves"], errors="coerce").fillna(0).sum()
        if not keeper_stats.empty and {"team", "shot_stopping_save"}.issubset(keeper_stats.columns):
            subset = keeper_stats[keeper_stats["team"].astype(str).str.strip().eq(team.strip())]
            if not subset.empty:
                return pd.to_numeric(subset["shot_stopping_save"], errors="coerce").fillna(0).sum()
        return _team_metric_value(team_stats, team, "saves")
    if key == "goles_encajados":
        if score_pair is not None and side is not None:
            home_goals, away_goals = score_pair
            if side == "home" and away_goals is not None:
                return away_goals
            if side == "away" and home_goals is not None:
                return home_goals
        value = _ws_value(ws_stats, "goalsConceded", side) if side else None
        if value is not None:
            return value
        if not keeper_stats.empty and {"team", "shot_stopping_ga"}.issubset(keeper_stats.columns):
            subset = keeper_stats[keeper_stats["team"].astype(str).str.strip().eq(team.strip())]
            if not subset.empty:
                return pd.to_numeric(subset["shot_stopping_ga"], errors="coerce").fillna(0).sum()
        return None
    if key == "porteria_cero":
        goals_against = _team_summary_value(team_stats, player_stats, keeper_stats, events, html_extra, ws_stats, team, "goles_encajados", side, score_pair)
        if goals_against is None:
            return None
        return 1 if float(goals_against) == 0 else 0
    if key == "claims_high":
        value = _ws_value(ws_stats, "claimsHigh", side) if side else None
        if value is not None:
            return value
        return None
    if key == "posesion":
        value = _ws_value(ws_stats, "possession", side) if side else None
        if value is not None:
            return value
        return _team_metric_value(team_stats, team, "possession")
    if key == "pases_completados":
        value = _ws_value(ws_stats, "passesAccurate", side) if side else None
        if value is not None:
            return value
        extra = html_extra.get("passes_completed")
        if extra and team in extra:
            return _to_number(extra.get(team))
        return None
    if key == "pases_intentados":
        value = _ws_value(ws_stats, "passesTotal", side) if side else None
        if value is not None:
            return value
        extra = html_extra.get("passes_attempted")
        if extra and team in extra:
            return _to_number(extra.get(team))
        return None
    if key == "porcentaje_pase":
        value = _ws_value(ws_stats, "passSuccess", side) if side else None
        if value is not None:
            return value
        extra = html_extra.get("pass_pct")
        if extra and team in extra:
            return _to_number(extra.get(team))
        return None
    if key == "pases_clave":
        value = _ws_value(ws_stats, "passesKey", side) if side else None
        if value is not None:
            return value
        return None
    if key == "regates_completados":
        value = _ws_value(ws_stats, "dribblesWon", side) if side else None
        if value is not None:
            return value
        return None
    if key == "regates_intentados":
        value = _ws_value(ws_stats, "dribblesAttempted", side) if side else None
        if value is not None:
            return value
        return None
    if key == "regates_exitosos_pct":
        value = _ws_value(ws_stats, "dribbleSuccess", side) if side else None
        if value is not None:
            return value
        return None
    if key == "dribbled_past":
        value = _ws_value(ws_stats, "dribbledPast", side) if side else None
        if value is not None:
            return value
        return None
    if key == "dispossessed":
        value = _ws_value(ws_stats, "dispossessed", side) if side else None
        if value is not None:
            return value
        return None
    if key == "toques":
        value = _ws_value(ws_stats, "touches", side) if side else None
        if value is not None:
            return value
        return None
    if key == "aerials_offensive":
        value = _ws_value(ws_stats, "offensiveAerials", side) if side else None
        if value is not None:
            return value
        return None
    if key == "aerials_defensive":
        value = _ws_value(ws_stats, "defensiveAerials", side) if side else None
        if value is not None:
            return value
        return None
    if key == "parried_safe":
        value = _ws_value(ws_stats, "parriedSafe", side) if side else None
        if value is not None:
            return value
        return None
    if key == "parried_danger":
        value = _ws_value(ws_stats, "parriedDanger", side) if side else None
        if value is not None:
            return value
        return None
    if key == "collected":
        value = _ws_value(ws_stats, "collected", side) if side else None
        if value is not None:
            return value
        return None
    if key == "woodwork":
        value = _ws_value(ws_stats, "shotsOnPost", side) if side else None
        if value is not None:
            return value
        return None
    if key == "ratings":
        value = _ws_value(ws_stats, "ratings", side) if side else None
        if value is not None:
            return value
        return None
    if key == "faltas_recibidas":
        if not player_stats.empty and {"team", "performance_fld"}.issubset(player_stats.columns):
            subset = player_stats[player_stats["team"].astype(str).str.strip().eq(team.strip())]
            if not subset.empty:
                return pd.to_numeric(subset["performance_fld"], errors="coerce").fillna(0).sum()
        return None
    if key == "understat_xg":
        return _understat_value(understat_hist, "xG")
    if key == "understat_npxg":
        return _understat_value(understat_hist, "npxG")
    if key == "understat_xga":
        return _understat_value(understat_hist, "xGA")
    if key == "understat_npxga":
        return _understat_value(understat_hist, "npxGA")
    if key == "understat_xpts":
        return _understat_value(understat_hist, "xpts")
    if key == "understat_ppda":
        return _understat_ppda_ratio(understat_hist)
    if key == "understat_ppda_allowed":
        return _understat_ppda_ratio({"ppda": (understat_hist or {}).get("ppda_allowed", {})})
    if key == "understat_deep":
        return _understat_value(understat_hist, "deep")
    if key == "understat_deep_allowed":
        return _understat_value(understat_hist, "deep_allowed")
    return None


def _summary_rows(match_row: pd.Series, team_stats: pd.DataFrame, player_stats: pd.DataFrame, keeper_stats: pd.DataFrame, events: pd.DataFrame, ws_stats: dict[str, dict[str, float]] | None = None) -> list[dict[str, object]]:
    info = _derive_match_info(match_row, team_stats, events)
    home = info["local"]
    away = info["visitante"]
    html_extra = {}
    ws_stats = ws_stats or {}
    score_pair = _parse_score_pair(info["resultado"])
    _, _, home_hist, away_hist = _understat_match_context(match_row)
    rows: list[dict[str, object]] = []
    for key, label, group in SUMMARY_METRICS:
        home_val = _team_summary_value(team_stats, player_stats, keeper_stats, events, html_extra, ws_stats, home, key, "home", score_pair, home_hist)
        away_val = _team_summary_value(team_stats, player_stats, keeper_stats, events, html_extra, ws_stats, away, key, "away", score_pair, away_hist)
        if key == "porteria_cero":
            home_display = "Sí" if home_val == 1 else "No" if home_val == 0 else "N/D"
            away_display = "Sí" if away_val == 1 else "No" if away_val == 0 else "N/D"
        else:
            home_display = _format_numeric(home_val, percent=(key in {"posesion", "porcentaje_pase", "regates_exitosos_pct", "tackle_exitoso_pct", "duelos_aereos_pct"}))
            away_display = _format_numeric(away_val, percent=(key in {"posesion", "porcentaje_pase", "regates_exitosos_pct", "tackle_exitoso_pct", "duelos_aereos_pct"}))
        rows.append(
            {
                "group": group,
                "key": key,
                "label": label,
                "home_team": home,
                "away_team": away,
                "home_value": home_val,
                "away_value": away_val,
                "home_display": home_display,
                "away_display": away_display,
                "percent": key in {"posesion", "porcentaje_pase", "regates_exitosos_pct", "tackle_exitoso_pct", "duelos_aereos_pct"},
            }
        )
    return rows


def _build_team_summary_df(match_row: pd.Series, team_stats: pd.DataFrame, player_stats: pd.DataFrame, keeper_stats: pd.DataFrame, events: pd.DataFrame) -> pd.DataFrame:
    rows = _summary_rows(match_row, team_stats, player_stats, keeper_stats, events)
    if not rows:
        return pd.DataFrame()
    home = rows[0]["home_team"]
    away = rows[0]["away_team"]
    return pd.DataFrame(
        [
            {"Métrica": row["label"], home: row["home_display"], away: row["away_display"]}
            for row in rows
        ]
    )


def _build_team_comparison_html(match_row: pd.Series, team_stats: pd.DataFrame, player_stats: pd.DataFrame, keeper_stats: pd.DataFrame, events: pd.DataFrame) -> str:
    rows = _summary_rows(match_row, team_stats, player_stats, keeper_stats, events)
    if not rows:
        return ""

    parts: list[str] = ["<div class='comparison-wrap'>"]
    grouped: dict[str, list[dict[str, object]]] = {group: [] for group in SUMMARY_GROUP_ORDER}
    for metric in rows:
        grouped.setdefault(str(metric.get("group", "Otros")), []).append(metric)

    for group in SUMMARY_GROUP_ORDER:
        metrics = grouped.get(group, [])
        if not metrics:
            continue
        parts.append(f"<div class='comparison-group'><h4>{escape(group)}</h4>")
        for metric in metrics:
            home_val = _to_number(metric.get("home_value"))
            away_val = _to_number(metric.get("away_value"))
            max_val = max(home_val or 0, away_val or 0, 1)
            home_width = (home_val or 0) / max_val * 100
            away_width = (away_val or 0) / max_val * 100
            label = escape(str(metric.get("label", "")))
            home_display = escape(str(metric.get("home_display", "N/D")))
            away_display = escape(str(metric.get("away_display", "N/D")))
            home_team = escape(str(metric.get("home_team", "")))
            away_team = escape(str(metric.get("away_team", "")))
            if home_val is None and away_val is None:
                parts.append(
                    f"<div class='comparison-row'><div class='comparison-head'><div class='comparison-label'>{label}</div></div><div class='comparison-empty'>Sin datos</div></div>"
                )
                continue
            parts.append(
                "<div class='comparison-row'>"
                f"<div class='comparison-head'><div class='comparison-label'>{label}</div></div>"
                f"<div class='comparison-values'><span>{home_team}: {home_display}</span><span>{away_team}: {away_display}</span></div>"
                f"<div class='comparison-bars'><div class='comparison-bar-wrap'><div class='comparison-bar-home' style='width:{home_width:.1f}%;'></div></div>"
                f"<div class='comparison-bar-wrap'><div class='comparison-bar-away' style='width:{away_width:.1f}%;'></div></div></div>"
                "</div>"
            )
        parts.append("</div>")
    parts.append("</div>")
    return "".join(parts)


def _metric_card_html(metric: dict[str, object]) -> str:
    home_val = _to_number(metric.get("home_value"))
    away_val = _to_number(metric.get("away_value"))
    max_val = max(home_val or 0, away_val or 0, 1)
    home_width = (home_val or 0) / max_val * 100
    away_width = (away_val or 0) / max_val * 100
    label = escape(str(metric.get("label", "")))
    home_display = escape(str(metric.get("home_display", "N/D")))
    away_display = escape(str(metric.get("away_display", "N/D")))
    home_team = escape(str(metric.get("home_team", "")))
    away_team = escape(str(metric.get("away_team", "")))
    return (
        f"<div class='comparison-card'>"
        f"<div class='comparison-card-title'>{label}</div>"
        f"<div class='comparison-card-values'>"
        f"<div class='comparison-card-side'><div class='comparison-card-team'>{home_team}</div><div class='comparison-card-value'>{home_display}</div></div>"
        f"<div class='comparison-card-side' style='text-align:right;'><div class='comparison-card-team'>{away_team}</div><div class='comparison-card-value'>{away_display}</div></div>"
        f"</div>"
        f"<div class='comparison-card-bar'>"
        f"<div class='comparison-card-home' style='width:{home_width:.1f}%;'></div>"
        f"<div class='comparison-card-away' style='width:{away_width:.1f}%;'></div>"
        f"</div>"
        f"</div>"
    )


def _render_team_comparison_dashboard(match_row: pd.Series, team_stats: pd.DataFrame, player_stats: pd.DataFrame, keeper_stats: pd.DataFrame, events: pd.DataFrame, selected_group: str = "Todas", ws_stats: dict[str, dict[str, float]] | None = None) -> None:
    rows = _summary_rows(match_row, team_stats, player_stats, keeper_stats, events, ws_stats=ws_stats)
    if not rows:
        st.info("No hay datos suficientes para mostrar el comparador.")
        return

    grouped: dict[str, list[dict[str, object]]] = {group: [] for group in SUMMARY_GROUP_ORDER}
    for metric in rows:
        grouped.setdefault(str(metric.get("group", "Otros")), []).append(metric)

    groups_to_show = SUMMARY_GROUP_ORDER if selected_group == "Todas" else [selected_group]
    for group in groups_to_show:
        metrics = grouped.get(group, [])
        if not metrics:
            continue
        st.markdown(f"#### {group}")
        for i in range(0, len(metrics), 2):
            cols = st.columns(2)
            for col, metric in zip(cols, metrics[i : i + 2]):
                col.markdown(_metric_card_html(metric), unsafe_allow_html=True)


def _build_key_moments_df(events: pd.DataFrame) -> pd.DataFrame:
    if events.empty:
        return pd.DataFrame()
    events = _dedupe_events(events)
    subset = events[events["event_type"].astype(str).isin({"goal", "penalty_goal", "yellow_card", "red_card"})].copy()
    if subset.empty:
        return pd.DataFrame()
    type_map = {
        "goal": "Gol",
        "penalty_goal": "Gol de penalti",
        "yellow_card": "Tarjeta amarilla",
        "red_card": "Tarjeta roja",
    }
    subset["Minuto"] = subset.apply(_minute_label, axis=1)
    subset["Parte"] = subset["period"].map({1: "1ª parte", 2: "2ª parte", 3: "Prórroga"}).fillna("Sin datos")
    subset["Tipo"] = subset["event_type"].astype(str).map(type_map).fillna(subset["event_type"].astype(str))
    subset["Equipo"] = subset.get("team", "")
    subset["Jugador"] = subset.get("player", "")
    subset["Marcador"] = subset.get("score_after_event", "")
    subset["Detalle"] = subset.apply(
        lambda r: (
            f"Gol de {r.get('Jugador')}"
            if r.get("Tipo") in {"Gol", "Gol de penalti"}
            else f"{r.get('Tipo')} a {r.get('Jugador')}"
        ),
        axis=1,
    )
    cols = [c for c in ["Minuto", "Parte", "Equipo", "Jugador", "Tipo", "Marcador", "Detalle"] if c in subset.columns]
    return subset.loc[:, cols].sort_values(by=["Minuto"], kind="stable")


def _parse_substitution_detail(raw_text: object) -> tuple[str, str] | None:
    text = str(raw_text or "").strip()
    m = re.search(r"\bfor\s+(.+?)(?:\s+[—-]|$)", text, re.I)
    if not m:
        return None
    outgoing = m.group(1).strip()
    outgoing = re.sub(r"\s+—\s*Substitute.*$", "", outgoing, flags=re.I).strip()
    return outgoing, ""


def _extract_assist(raw_text: object) -> str:
    text = str(raw_text or "").strip()
    m = re.search(r"Assist:\s*(.+?)(?:\s+[—-]|$)", text, re.I)
    if not m:
        return ""
    return m.group(1).strip()


def _event_timeline_label(row: pd.Series) -> str:
    etype = str(row.get("event_type") or "").strip().lower()
    player = str(row.get("player") or "").strip()
    team = str(row.get("team") or "").strip()
    score = str(row.get("score_after_event") or "").strip().replace(":", "-")
    raw = str(row.get("raw_text") or "")

    if etype == "goal":
        assist = _extract_assist(raw)
        return f"⚽ {player}" + (f"||Asistencia: {assist}" if assist else "")
    if etype == "penalty_goal":
        return f"⚽ {player} (penalti)"
    if etype == "yellow_card":
        return f"🟨 {player}"
    if etype == "red_card":
        return f"🟥 {player}"
    if etype == "substitute_in":
        parsed = _parse_substitution_detail(raw)
        if parsed:
            outgoing, _ = parsed
            return f"🔄 <span class='timeline-sub-out'>{outgoing} ↓</span> <span class='timeline-sub-in'>{player} ↑</span>"
        return f"🔄 <span class='timeline-sub-in'>{player} ↑</span>"
    return f"• {player or team}"


def _build_timeline_html(events: pd.DataFrame, event_types: set[str] | None = None) -> str:
    if events.empty:
        return ""

    df = _dedupe_events(events)
    if "minute" in df.columns:
        df["_sort_minute"] = pd.to_numeric(df["minute"], errors="coerce")
    else:
        df["_sort_minute"] = 9999
    if "second" in df.columns:
        df["_sort_second"] = pd.to_numeric(df["second"], errors="coerce").fillna(0)
    else:
        df["_sort_second"] = 0
    df = df.sort_values(by=["_sort_minute", "_sort_second"], na_position="last")

    rows = []
    for _, row in df.iterrows():
        etype = str(row.get("event_type") or "").strip().lower()
        if event_types is not None and etype not in event_types:
            continue
        minute = _minute_label(row)
        period_short = _period_short_label(row)
        label = _event_timeline_label(row)
        score = str(row.get("score_after_event") or "").strip().replace(":", "-")
        team = escape(str(row.get("team") or ""))
        team_chip = f"<span class='timeline-team'>{team}</span>" if team else ""
        score_chip = f"<span class='timeline-score'>({escape(score)})</span>" if score else ""
        main_label = label
        assist_html = ""
        if "||" in label:
            main_label, assist = label.split("||", 1)
            assist_html = f"<span class='timeline-assist'>{escape(assist)}</span>"
        rows.append(
            f"<div class='timeline-row'><div class='timeline-minute'>{escape(minute)}<small>{escape(period_short)}</small></div><div class='timeline-content'>{team_chip} <span class='timeline-main'>{main_label} {score_chip}</span>{assist_html}</div></div>"
        )

    if not rows:
        return ""
    return "<div class='timeline'>" + "".join(rows) + "</div>"


def _derive_match_info(match_row: pd.Series, team_stats: pd.DataFrame, events: pd.DataFrame) -> dict[str, str]:
    league = _display_label(_row_value(match_row, "league"))
    season = _display_label(_row_value(match_row, "season"))
    home = _display_label(_first_nonempty(_row_value(match_row, "home_team"), _row_value(match_row, "home")))
    away = _display_label(_first_nonempty(_row_value(match_row, "away_team"), _row_value(match_row, "away")))
    referee = _display_label(_first_nonempty(_row_value(match_row, "referee"), _row_value(match_row, "referee_name")))
    date = _format_date(_first_nonempty(_row_value(match_row, "date"), _row_value(match_row, "date_schedule"), _parse_date_from_url(_row_value(match_row, "match_report_url"))))
    score = _display_label(_first_nonempty(_extract_final_score(events), _row_value(match_row, "score")))
    venue = _display_label(_row_value(match_row, "venue"))
    attendance = _display_label(_row_value(match_row, "attendance"))
    return {
        "liga": league,
        "temporada": season,
        "local": home,
        "visitante": away,
        "arbitro": referee,
        "fecha": date,
        "resultado": score,
        "estadio": venue,
        "asistencia": attendance,
    }


def _pretty_column(name: str) -> str:
    if name in COLUMN_LABELS:
        return COLUMN_LABELS[name]
    if name in METRIC_LABELS:
        return METRIC_LABELS[name]
    if name.startswith("performance_"):
        suffix = name.replace("performance_", "", 1)
        if suffix in METRIC_LABELS:
            return METRIC_LABELS[suffix]
        name = suffix
    return name.replace("_", " ").strip().title()


def _translate_frame(df: pd.DataFrame, hide_technical: bool) -> pd.DataFrame:
    if df.empty:
        return df
    out = df.copy()
    if hide_technical:
        out = out[[c for c in out.columns if c not in TECHNICAL_COLUMNS and not c.startswith("source_") and not c.startswith("run_") and not c.startswith("cache_") and not c.startswith("parser_")]]
    out = out.rename(columns={c: _pretty_column(c) for c in out.columns})
    deduped: list[str] = []
    seen: dict[str, int] = {}
    for col in out.columns:
        count = seen.get(col, 0) + 1
        seen[col] = count
        deduped.append(col if count == 1 else f"{col} ({count})")
    out.columns = deduped
    return out


def _match_label(row: pd.Series) -> str:
    date = _match_date_label(row)
    home = _display_label(_first_nonempty(_row_value(row, "home_team"), _row_value(row, "home")))
    away = _display_label(_first_nonempty(_row_value(row, "away_team"), _row_value(row, "away")))
    return f"{date} — {home} vs {away}" if date != "Sin datos" else f"{home} vs {away}"


def _match_date_label(row: pd.Series) -> str:
    raw = _first_nonempty(_row_value(row, "date"), _row_value(row, "date_schedule"), _parse_date_from_url(_row_value(row, "match_report_url")))
    return _format_date(raw)


def _match_date_sort_value(row: pd.Series) -> datetime | None:
    raw = _first_nonempty(_row_value(row, "date"), _row_value(row, "date_schedule"), _parse_date_from_url(_row_value(row, "match_report_url")))
    text = _display_label(raw)
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y"):
        try:
            return datetime.strptime(text[:10], fmt)
        except Exception:
            pass
    return None


def _match_season_label(row: pd.Series) -> str:
    sort_date = _match_date_sort_value(row)
    if sort_date is not None:
        year = sort_date.year
        if sort_date.month >= 7:
            return f"{year}-{year + 1}"
        return f"{year - 1}-{year}"
    return _display_label(_row_value(row, "season"))


def _is_placeholder_match_row(row: pd.Series) -> bool:
    placeholders = {"date", "home", "away", "score", "attendance", "referee", "venue", "home team", "away team"}
    fields = [
        _display_label(_first_nonempty(_row_value(row, "date"), _row_value(row, "date_schedule"))),
        _display_label(_first_nonempty(_row_value(row, "home_team"), _row_value(row, "home"))),
        _display_label(_first_nonempty(_row_value(row, "away_team"), _row_value(row, "away"))),
        _display_label(_row_value(row, "score")),
        _display_label(_row_value(row, "attendance")),
        _display_label(_row_value(row, "referee")),
        _display_label(_row_value(row, "venue")),
    ]
    return any(field.strip().lower() in placeholders for field in fields)


def _match_compact_label(row: pd.Series) -> str:
    date = _match_date_label(row)
    home = _display_label(_first_nonempty(_row_value(row, "home_team"), _row_value(row, "home")))
    away = _display_label(_first_nonempty(_row_value(row, "away_team"), _row_value(row, "away")))
    return f"{date} — {home} vs {away}" if date != "Sin datos" else f"{home} vs {away}"


def _select_options(df: pd.DataFrame, column: str) -> list[str]:
    if column not in df.columns:
        return []
    values = [v for v in df[column].dropna().astype(str).tolist() if v.strip()]
    return sorted(dict.fromkeys(values))


def _drop_summary_rows(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return df
    out = df.copy()
    if "player" in out.columns:
        out = out[~out["player"].astype(str).str.contains("Players$", case=False, na=False)]
    if "entity_type" in out.columns:
        out = out[out["entity_type"].astype(str).str.lower().eq("player")]
    return out


def _apply_search_filters(df: pd.DataFrame, search: str, team: str, player: str, position: str) -> pd.DataFrame:
    if df.empty:
        return df
    out = df.copy()
    if team and team != "Todos" and "team" in out.columns:
        out = out[out["team"].astype(str).str.strip().eq(team.strip())]
    if player and "player" in out.columns:
        out = out[out["player"].astype(str).str.contains(player, case=False, na=False)]
    if position and position != "Todas" and "unnamed_3_level_0_pos" in out.columns:
        out = out[out["unnamed_3_level_0_pos"].astype(str).str.contains(position, case=False, na=False)]
    if search:
        mask = pd.Series(False, index=out.index)
        for col in out.columns:
            if col in {"scraped_at", "source_html_path"}:
                continue
            mask = mask | out[col].astype(str).str.contains(search, case=False, na=False)
        out = out[mask]
    return out


def _select_match(matches: pd.DataFrame) -> pd.Series | None:
    if matches.empty:
        return None
    matches = matches.drop_duplicates(subset=[c for c in ["match_id"] if c in matches.columns]).copy()
    labels = matches.apply(_match_label, axis=1).tolist()
    choice = st.sidebar.selectbox("Partido", labels, index=0)
    idx = labels.index(choice)
    return matches.iloc[idx]


def _render_summary(match_row: pd.Series, events: pd.DataFrame) -> None:
    info = _derive_match_info(match_row, pd.DataFrame(), events)
    st.markdown(
        f"""
        <div class="hero-shell">
            <h1>{escape(info['local'])} vs {escape(info['visitante'])}</h1>
            <div class="meta-row">
                {_pill_html('Liga', info['liga'])}
                {_pill_html('Temporada', info['temporada'])}
                {_pill_html('Fecha', info['fecha'])}
                {_pill_html('Asistencia', info['asistencia'])}
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )
    cols = st.columns(4)
    cards = [
        ("Resultado", info["resultado"]),
        ("Fecha", info["fecha"]),
        ("Árbitro", info["arbitro"]),
        ("Estadio", info["estadio"]),
    ]
    for col, (label, value) in zip(cols, cards, strict=False):
        col.markdown(_card_html(label, value), unsafe_allow_html=True)


def _render_table(title: str, df: pd.DataFrame, hide_technical: bool) -> None:
    st.markdown(f"### {title}")
    if df.empty:
        st.info("No hay datos para mostrar con estos filtros.")
        return
    st.dataframe(_translate_frame(df, hide_technical), use_container_width=True, hide_index=True)


def _build_match_summary_df(match_row: pd.Series, events: pd.DataFrame) -> pd.DataFrame:
    info = _derive_match_info(match_row, pd.DataFrame(), events)
    rows = [
        {"Campo": "Partido", "Valor": f"{info['local']} vs {info['visitante']}"},
        {"Campo": "Resultado", "Valor": info["resultado"]},
        {"Campo": "Fecha", "Valor": info["fecha"]},
        {"Campo": "Liga", "Valor": info["liga"]},
        {"Campo": "Temporada", "Valor": info["temporada"]},
        {"Campo": "Árbitro", "Valor": info["arbitro"]},
        {"Campo": "Estadio", "Valor": info["estadio"]},
    ]
    return pd.DataFrame(rows)


def _render_glossary() -> None:
    st.markdown("### Glosario rápido")
    glossary = pd.DataFrame(METRIC_GLOSSARY, columns=["Métrica", "Qué significa"])
    st.dataframe(glossary, use_container_width=True, hide_index=True)


def main() -> None:
    st.markdown("<div style='height:0.25rem'></div>", unsafe_allow_html=True)

    default_root = _default_dataset_root()
    with st.sidebar:
        st.header("Filtros")
        root_input = st.text_input("Ruta del dataset", value=str(default_root))
        hide_technical = st.checkbox("Ocultar columnas técnicas", value=True)
        refresh = st.button("Recargar datos")

    if refresh:
        load_tables.clear()
        st.rerun()

    root = Path(root_input)
    if not root.exists():
        st.error(f"No encuentro el dataset en: {root}")
        st.stop()

    tables = load_tables(str(root))
    matches = tables["match_wide"]
    team_stats = _drop_summary_rows(tables["team_stats"])
    team_stats_ws = tables.get("team_stats_ws", pd.DataFrame()).copy()
    player_stats = _drop_summary_rows(tables["player_stats"])
    player_stats_ws = tables.get("player_stats_ws", pd.DataFrame()).copy()
    keeper_stats = tables["keeper_stats"].copy()
    lineups = tables["lineups"]
    events = tables["events"]

    if matches.empty:
        st.warning("No he encontrado `match_wide` en el dataset seleccionado.")
        st.stop()

    matches = matches.copy()
    matches["__home_name"] = matches.apply(lambda row: _display_label(_first_nonempty(_row_value(row, "home_team"), _row_value(row, "home"))), axis=1)
    matches["__away_name"] = matches.apply(lambda row: _display_label(_first_nonempty(_row_value(row, "away_team"), _row_value(row, "away"))), axis=1)
    if "match_id" in matches.columns:
        matches = matches[matches["match_id"].astype(str).str.strip().ne("") & matches["match_id"].astype(str).str.lower().ne("nan")]
    matches = matches[(matches["__home_name"] != "Sin datos") & (matches["__away_name"] != "Sin datos")]
    matches = matches[~matches.apply(_is_placeholder_match_row, axis=1)]
    matches["__season_key"] = matches.apply(_match_season_label, axis=1)
    matches["__sort_date"] = matches.apply(_match_date_sort_value, axis=1)

    seasons_available = sorted([s for s in matches["__season_key"].dropna().astype(str).unique().tolist() if s], reverse=True)
    with st.sidebar:
        season_filter = st.selectbox("Temporada", seasons_available if seasons_available else ["Todas"], index=0 if seasons_available else 0, key="season_select")

    if season_filter != "Todas":
        matches = matches[matches["__season_key"].astype(str).eq(season_filter)]

    if matches.empty:
        st.warning("No hay partidos para la temporada seleccionada.")
        st.stop()

    matches_for_select = matches.drop_duplicates(subset=[c for c in ["match_id"] if c in matches.columns]).copy()
    if "__sort_date" in matches_for_select.columns:
        matches_for_select = matches_for_select.sort_values(by=["__sort_date", "__season_key"], na_position="last")
    labels = matches_for_select.apply(_match_compact_label, axis=1).tolist()
    match_index = st.sidebar.selectbox(
        "Partido",
        list(range(len(labels))),
        index=0,
        format_func=lambda i: labels[int(i)],
        key=f"match_select_{season_filter}",
    )
    match_row = matches_for_select.iloc[int(match_index)]
    match_id = str(match_row.get("match_id", ""))

    if "match_id" in team_stats.columns:
        team_stats = team_stats[team_stats["match_id"].astype(str).eq(match_id)]
    if "match_id" in player_stats.columns:
        player_stats = player_stats[player_stats["match_id"].astype(str).eq(match_id)]
    if "match_id" in keeper_stats.columns:
        keeper_stats = keeper_stats[keeper_stats["match_id"].astype(str).eq(match_id)]
    if "match_id" in lineups.columns:
        lineups = lineups[lineups["match_id"].astype(str).eq(match_id)]
    if "match_id" in events.columns:
        events = events[events["match_id"].astype(str).eq(match_id)]
    events = _dedupe_events(events)

    match_home = _normalize_name(_first_nonempty(_row_value(match_row, "home_team"), _row_value(match_row, "home")))
    match_away = _normalize_name(_first_nonempty(_row_value(match_row, "away_team"), _row_value(match_row, "away")))
    match_date_key = _date_key(_row_value(match_row, "date"))
    if not team_stats_ws.empty and {"team"}.issubset(team_stats_ws.columns):
        if "match_date" in team_stats_ws.columns:
            team_stats_ws = team_stats_ws[team_stats_ws["match_date"].astype(str).map(_date_key).eq(match_date_key)]
        team_stats_ws = team_stats_ws[team_stats_ws["team"].astype(str).map(_normalize_name).isin({match_home, match_away})]
    if not player_stats_ws.empty and {"team"}.issubset(player_stats_ws.columns):
        if "match_date" in player_stats_ws.columns:
            player_stats_ws = player_stats_ws[player_stats_ws["match_date"].astype(str).map(_date_key).eq(match_date_key)]
        player_stats_ws = player_stats_ws[player_stats_ws["team"].astype(str).map(_normalize_name).isin({match_home, match_away})]
    ws_stats = _build_whoscored_match_stats(team_stats_ws, player_stats_ws)

    teams_in_match = _select_options(team_stats, "team") or _select_options(player_stats, "team")
    players_in_match = _select_options(player_stats, "player")
    positions_in_match = _select_options(player_stats, "unnamed_3_level_0_pos")

    with st.sidebar:
        team_filter = st.selectbox("Equipo", ["Todos", *teams_in_match] if teams_in_match else ["Todos"])
        player_filter = st.text_input("Buscar jugador", value="")
        position_filter = st.selectbox("Posición", ["Todas", *positions_in_match] if positions_in_match else ["Todas"])
        if players_in_match:
            st.caption("Jugadores detectados en este partido: " + ", ".join(players_in_match[:8]) + ("..." if len(players_in_match) > 8 else ""))

    player_stats_view = _apply_search_filters(player_stats, player_filter, team_filter, "", position_filter)
    player_stats_view = _merge_whoscored_player_view(player_stats_view, player_stats_ws)
    player_stats_view = _attach_understat_player_metrics(match_row, player_stats_view)
    keeper_stats_view = _apply_search_filters(keeper_stats, player_filter, team_filter, "", "")
    team_stats_view = team_stats.copy()
    if team_filter != "Todos" and "team" in team_stats_view.columns:
        team_stats_view = team_stats_view[team_stats_view["team"].astype(str).str.strip().eq(team_filter.strip())]
    lineups_view = lineups.copy()
    if team_filter != "Todos" and "team" in lineups_view.columns:
        lineups_view = lineups_view[lineups_view["team"].astype(str).str.strip().eq(team_filter.strip())]
    if player_filter and "player" in lineups_view.columns:
        lineups_view = lineups_view[lineups_view["player"].astype(str).str.contains(player_filter, case=False, na=False)]
    events_view = events.copy()
    if team_filter != "Todos" and "team" in events_view.columns:
        events_view = events_view[events_view["team"].astype(str).str.strip().eq(team_filter.strip())]
    if player_filter and "player" in events_view.columns:
        events_view = events_view[events_view["player"].astype(str).str.contains(player_filter, case=False, na=False)]
    events_view = _dedupe_events(events_view)
    events_view = _filter_events_to_roster(events_view, player_stats_view, keeper_stats_view, lineups_view)

    match_info = _derive_match_info(match_row, team_stats_view, events_view)

    _render_summary(match_row, events_view)

    tabs = st.tabs(["Datos del partido", "Momentos clave", "Estadísticas equipo", "Más datos"])

    with tabs[0]:
        _render_table("Datos del partido", _build_match_summary_df(match_row, events_view), False)

    with tabs[1]:
        moment_type = st.radio("Ver", ["Goles", "Tarjetas", "Sustituciones"], horizontal=True)

        if moment_type == "Goles":
            timeline_html = _build_timeline_html(events_view, {"goal", "penalty_goal"})
            if not timeline_html:
                st.info("No he encontrado goles en este partido.")
            else:
                st.markdown(timeline_html, unsafe_allow_html=True)

        elif moment_type == "Tarjetas":
            timeline_html = _build_timeline_html(events_view, {"yellow_card", "red_card"})
            if not timeline_html:
                st.info("No he encontrado tarjetas en este partido.")
            else:
                st.markdown(timeline_html, unsafe_allow_html=True)

        else:
            team_choice = st.radio("Equipo", ["Todos", match_info["local"], match_info["visitante"]], horizontal=True)
            if team_choice == "Todos":
                subset_events = events_view
            else:
                subset_events = events_view[events_view["team"].astype(str).str.strip().eq(team_choice)] if "team" in events_view.columns else events_view.iloc[0:0]
            timeline_html = _build_timeline_html(subset_events, {"substitute_in"})
            if not timeline_html:
                st.info("No he encontrado sustituciones para este filtro.")
            else:
                st.markdown(timeline_html, unsafe_allow_html=True)

    with tabs[2]:
        st.markdown("### Resumen por equipo")
        category_choice = st.radio("Categoría", ["Todas", *SUMMARY_GROUP_ORDER], horizontal=True)
        _render_team_comparison_dashboard(match_row, team_stats_view, player_stats_view, keeper_stats, events_view, selected_group=category_choice, ws_stats=ws_stats)

    with tabs[3]:
        st.markdown("### Más datos")
        with st.expander("Jugadores", expanded=False):
            _render_table("Estadísticas de jugadores", player_stats_view, hide_technical)
        with st.expander("Porteros", expanded=False):
            _render_table("Estadísticas de porteros", keeper_stats_view, hide_technical)
        with st.expander("Alineaciones", expanded=False):
            _render_table("Alineaciones", lineups_view, hide_technical)
        with st.expander("Eventos", expanded=False):
            _render_table("Eventos", events_view, hide_technical)
        with st.expander("Glosario", expanded=False):
            _render_glossary()


if __name__ == "__main__":
    main()
