from __future__ import annotations

from pathlib import Path
import re
import unicodedata

import pandas as pd


ROOT = Path("data")
CURATED = ROOT / "curated" / "final_dataset"
CLEAN = ROOT / "clean" / "final_dataset"

TEAM_ALIASES = {
    "deportivo_alaves": "alaves",
    "real_valladolid": "valladolid",
    "real_oviedo": "oviedo",
}

SEASON_ALIASES = {
    "2324": "2023-2024",
    "2425": "2024-2025",
    "2526": "2025-2026",
}


def _name_key(value: object) -> str:
    text = unicodedata.normalize("NFKD", str(value).strip())
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    text = text.lower().replace("&", " and ")
    text = re.sub(r"[^a-z0-9]+", "_", text)
    return TEAM_ALIASES.get(text.strip("_"), text.strip("_"))


def _season_key(value: object) -> str:
    return SEASON_ALIASES.get(str(value), str(value))


def _first_non_null(series: pd.Series):
    for value in series.tolist():
        if pd.notna(value) and str(value).strip().lower() != "nan":
            return value
    return None


def _coalesce_by_match_id(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty or "match_id" not in df.columns:
        return df
    working = df.copy()
    working["__non_nulls"] = working.notna().sum(axis=1)
    working = working.sort_values(["match_id", "__non_nulls"], ascending=[True, False])
    working = working.drop_duplicates(subset=["match_id"], keep="first")
    return working.drop(columns=["__non_nulls"]).reset_index(drop=True)


def _load_many(root: Path, filename: str) -> pd.DataFrame:
    frames: list[pd.DataFrame] = []
    for path in root.rglob(filename):
        try:
            df = pd.read_parquet(path)
        except Exception:
            continue
        if not df.empty:
            frames.append(df)
    if not frames:
        return pd.DataFrame()
    return pd.concat(frames, ignore_index=True, sort=False)


def _base_keys(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["season_key"] = out["season"].map(_season_key) if "season" in out.columns else None
    out["date_key"] = pd.to_datetime(out["date"], errors="coerce").dt.strftime("%Y-%m-%d") if "date" in out.columns else None
    out["home_key"] = out["home"].map(_name_key) if "home" in out.columns else None
    out["away_key"] = out["away"].map(_name_key) if "away" in out.columns else None
    if "home_team" in out.columns:
        home_team_key = out["home_team"].map(_name_key)
        out["home_key"] = home_team_key.where(out["home_key"].isna(), out["home_key"])
    if "away_team" in out.columns:
        away_team_key = out["away_team"].map(_name_key)
        out["away_key"] = away_team_key.where(out["away_key"].isna(), out["away_key"])
    cols = [c for c in ["match_id", "season_key", "date_key", "home_key", "away_key"] if c in out.columns]
    return out.loc[:, cols].drop_duplicates()


def _fact_keys(df: pd.DataFrame, date_col: str) -> pd.DataFrame:
    out = df.copy()
    out["season_key"] = out["season"].map(_season_key) if "season" in out.columns else None
    out["date_key"] = pd.to_datetime(out[date_col], errors="coerce", format="mixed").dt.strftime("%Y-%m-%d")
    out["home_key"] = out["home_team"].map(_name_key) if "home_team" in out.columns else None
    out["away_key"] = out["away_team"].map(_name_key) if "away_team" in out.columns else None
    return out


def _join_fact_to_base(df: pd.DataFrame, base_map: pd.DataFrame, date_col: str) -> pd.DataFrame:
    if df.empty:
        return df
    out = _fact_keys(df, date_col)
    out = out.merge(base_map, on=["date_key", "home_key", "away_key"], how="left")
    out = out.loc[out["match_id"].notna()].copy()
    return out


def _join_whoscored_to_base(df: pd.DataFrame, base_map: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return df
    out = _fact_keys(df, "match_date")
    by_date = out.merge(base_map, on=["date_key", "home_key", "away_key"], how="left")
    by_season = out.merge(base_map, on=["season_key", "home_key", "away_key"], how="left")
    merged = pd.concat([by_date, by_season], ignore_index=True, sort=False)
    merged = merged.loc[merged["match_id"].notna()].copy()
    if "whoscored_match_id" in merged.columns:
        merged = merged.sort_values(["fbref_match_id", "whoscored_match_id"]).drop_duplicates(subset=["fbref_match_id", "whoscored_match_id", "side"], keep="first")
    else:
        merged = merged.drop_duplicates(subset=["fbref_match_id", "side"], keep="first")
    return merged


def _build_wide_from_fact(df: pd.DataFrame, base_map: pd.DataFrame, date_col: str, prefix: str) -> pd.DataFrame:
    mapped = _join_fact_to_base(df, base_map, date_col)
    if mapped.empty or "side" not in mapped.columns:
        return pd.DataFrame()

    home = mapped.loc[mapped["side"].astype(str).str.lower().eq("home")].copy()
    away = mapped.loc[mapped["side"].astype(str).str.lower().eq("away")].copy()
    if home.empty or away.empty:
        return pd.DataFrame()

    id_cols = ["fbref_match_id", "whoscored_match_id", "understat_match_id"]
    keep = [c for c in id_cols if c in mapped.columns]
    metric_cols = [c for c in mapped.columns if c not in set(keep + ["side", "match_id"])]

    def _prep_side(frame: pd.DataFrame, side_prefix: str) -> pd.DataFrame:
        cols = [c for c in keep if c in frame.columns] + metric_cols
        side = frame.loc[:, cols].copy()
        side = side.drop_duplicates(subset=["fbref_match_id"], keep="first")
        side = side.rename(columns={c: f"{side_prefix}_{c}" for c in metric_cols})
        return side

    home_wide = _prep_side(home, f"{prefix}_home")
    away_wide = _prep_side(away, f"{prefix}_away")
    if home_wide.empty or away_wide.empty:
        return pd.DataFrame()

    wide = home_wide.merge(away_wide, on="fbref_match_id", how="inner", suffixes=("", "__away"))
    return wide


def main() -> None:
    match_wide = pd.read_parquet(CURATED / "match_wide.parquet")
    base = _coalesce_by_match_id(match_wide)
    base = base.drop(columns=[c for c in base.columns if c.startswith(("understat_", "home_ws_", "away_ws_", "ws_"))], errors="ignore")
    base_map = _base_keys(base).rename(columns={"match_id": "fbref_match_id"})

    understat = _load_many(ROOT / "curated" / "final_dataset" / "facts", "fact_understat_team_match_stats.parquet")
    if understat.empty:
        understat = _load_many(ROOT / "raw" / "understat", "team_match_stats.parquet")
    understat_wide = _build_wide_from_fact(understat, base_map, "date", "understat")
    if not understat_wide.empty:
        understat_wide = understat_wide.drop(columns=[c for c in ["date_key", "home_key", "away_key"] if c in understat_wide.columns])
        base = base.merge(understat_wide, left_on="match_id", right_on="fbref_match_id", how="left")
        base = base.drop(columns=[c for c in ["fbref_match_id"] if c in base.columns])

    whoscored = _load_many(ROOT / "curated" / "final_dataset" / "facts", "fact_whoscored_team_match_stats.parquet")
    if whoscored.empty:
        whoscored = _load_many(ROOT / "raw" / "whoscored", "match_team_stats.parquet")
    whoscored_wide = pd.DataFrame()
    whoscored_mapped = _join_whoscored_to_base(whoscored, base_map)
    if not whoscored_mapped.empty:
        home = whoscored_mapped.loc[whoscored_mapped["side"].astype(str).str.lower().eq("home")].copy()
        away = whoscored_mapped.loc[whoscored_mapped["side"].astype(str).str.lower().eq("away")].copy()
        if not home.empty and not away.empty:
            keep_cols = [c for c in ["fbref_match_id"] if c in whoscored_mapped.columns]
            metric_cols = [c for c in whoscored_mapped.columns if c not in set(keep_cols + ["side", "match_id"])]

            def _prep_ws(frame: pd.DataFrame, side_prefix: str) -> pd.DataFrame:
                cols = [c for c in keep_cols if c in frame.columns] + metric_cols
                side = frame.loc[:, cols].copy()
                side = side.drop_duplicates(subset=["fbref_match_id"], keep="first")
                side = side.rename(columns={c: f"{side_prefix}_{c}" for c in metric_cols})
                return side

            home_wide = _prep_ws(home, "home_ws")
            away_wide = _prep_ws(away, "away_ws")
            whoscored_wide = home_wide.merge(away_wide, on="fbref_match_id", how="inner")
        else:
            whoscored_wide = pd.DataFrame()
    if not whoscored_wide.empty:
        base = base.merge(whoscored_wide, left_on="match_id", right_on="fbref_match_id", how="left")
        base = base.drop(columns=[c for c in ["fbref_match_id"] if c in base.columns])

    base = base.drop(columns=[c for c in ["date_key", "home_key", "away_key"] if c in base.columns])

    CURATED.mkdir(parents=True, exist_ok=True)
    CLEAN.mkdir(parents=True, exist_ok=True)
    base.to_parquet(CURATED / "match_wide.parquet", index=False)
    base.to_csv(CURATED / "match_wide.csv", index=False)
    base.to_parquet(CLEAN / "match_wide.parquet", index=False)
    base.to_csv(CLEAN / "match_wide.csv", index=False)
    print(f"match_wide fixed: {len(base)} rows, {base['match_id'].nunique() if 'match_id' in base.columns else 0} unique matches")


if __name__ == "__main__":
    main()
