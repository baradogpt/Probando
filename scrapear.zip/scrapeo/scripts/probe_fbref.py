from __future__ import annotations

import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait

from soccer_scraper.utils.selenium_session import ChromePersistentSession

DEFAULT_SESSION_ROOT = r"D:\Proyectos\soccer_scraper_sessions"


def main() -> None:
    sess = ChromePersistentSession(
        profile_root=DEFAULT_SESSION_ROOT,
        profile_name="fbref_manual",
        headless=False,
        chrome_binary=None,
        user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36",
        extra_args=["--lang=en-US,en"],
    )
    driver = sess.build_driver()
    try:
        url = "https://fbref.com/en/comps/12/La-Liga-Stats"
        print(f"Opening {url}")
        driver.get(url)
        for i in range(6):
            time.sleep(3)
            title = driver.title
            print(f"[{i}] title={title!r} url={driver.current_url!r}")
            body = ""
            try:
                body = driver.find_element(By.TAG_NAME, "body").text[:400]
            except Exception:
                pass
            print(body.replace("\n", " | "))
            if title and "Un momento" not in title and "Just a moment" not in title:
                break
        try:
            WebDriverWait(driver, 10).until(lambda d: len(d.find_elements(By.TAG_NAME, "table")) > 0)
            print(f"Tables found: {len(driver.find_elements(By.TAG_NAME, 'table'))}")
        except Exception as exc:
            print(f"No tables yet: {exc}")
        print("Press Enter to close the browser...")
        input()
    finally:
        try:
            driver.quit()
        except Exception:
            pass


if __name__ == "__main__":
    main()
