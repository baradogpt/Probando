from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

import typer

from soccer_scraper.collectors.understat import UnderstatCollector


def main(
    data_dir: str = r"D:\Proyectos\soccer_scraper_project\data",
    league: str = "ESP-La Liga",
    season: str = "2025-2026",
    max_matches: int = 1,
) -> None:
    collector = UnderstatCollector(
        data_dir=data_dir,
        leagues=[league],
        seasons=[season],
        max_matches_per_season=max_matches,
    )
    outs = collector.save_outputs(collector.collect(), "raw/understat", source_name="understat")
    print(f"Understat guardado en: {outs.get('manifest', '')}")


if __name__ == "__main__":
    typer.run(main)
