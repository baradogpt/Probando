import requests

url = 'https://googlechromelabs.github.io/chrome-for-testing/latest-versions-per-metadata.json'
resp = requests.get(url).json()
print('Available ChromeDriver versions:')
for v in resp['versions']:
    print(f"  {v['version']}")