from pathlib import Path
import sys

import typer

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from soccer_scraper.config import load_config
from soccer_scraper.pipeline import run_feature_engineering


def main(config: str = "config/config.yml") -> None:
    cfg = load_config(config)
    out = run_feature_engineering(cfg)
    print(f"Features generadas en: {out}")


if __name__ == "__main__":
    typer.run(main)
