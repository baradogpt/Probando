from pathlib import Path
import json
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))

from soccer_scraper.collectors.whoscored import WhoScoredCollector, DEFAULT_SESSION_ROOT


SEASONS = [
    (
        "2024-2025",
        "/Regions/206/Tournaments/4/Seasons/10317/spain-laliga",
        "/regions/206/tournaments/4/seasons/10317/stages/23401/fixtures/spain-laliga-2024-2025",
    ),
    (
        "2023-2024",
        "/Regions/206/Tournaments/4/Seasons/9682/spain-laliga",
        "/regions/206/tournaments/4/seasons/9682/stages/22176/fixtures/spain-laliga-2023-2024",
    ),
    (
        "2022-2023",
        "/Regions/206/Tournaments/4/Seasons/9149/spain-laliga",
        "/regions/206/tournaments/4/seasons/9149/stages/21073/fixtures/spain-laliga-2022-2023",
    ),
]


def main() -> int:
    for season, season_path, fixtures_path in SEASONS:
        print(f"=== {season} ===")
        collector = None
        for attempt in range(3):
            try:
                collector = WhoScoredCollector(
                    data_dir=Path("../data"),
                    leagues=["ESP-La Liga"],
                    seasons=[season],
                    no_cache=False,
                    no_store=False,
                    profile_root=DEFAULT_SESSION_ROOT,
                    profile_name=f"whoscored_manual_visible_{season.replace('-', '_')}",
                    path_to_browser="C:/Program Files/Google/Chrome/Application/chrome.exe",
                    driver_version="146.0.7680.165",
                    version_main=146,
                    headless=False,
                )
                if not hasattr(collector.reader, "_driver"):
                    raise RuntimeError("driver not initialized")
                break
            except Exception as exc:
                print(f"INIT FAILED {season} attempt {attempt + 1}: {exc}")
                time.sleep(5)
                collector = None
        if collector is None:
            print(f"Skipping {season} because the browser could not be started")
            continue
        collector._local_season_catalog = lambda league, sp=season_path, s=season: {s: sp}
        collector._local_fixtures_url = lambda league, ss, fp=fixtures_path, s=season: fp if str(ss) == s else None

        try:
            schedule = collector._scrape_schedule_rows()
        except Exception as exc:
            print(f"SCHEDULE FAILED {season}: {exc}")
            continue
        if schedule.empty:
            print(f"No schedule found for {season}")
            continue

        links = {int(r.game_id): r.url for r in schedule.itertuples(index=False)}
        saved_dir = Path("../data/html/whoscored/matches") / season
        saved_ids = {int(p.name) for p in saved_dir.iterdir() if p.is_dir() and p.name.isdigit()} if saved_dir.exists() else set()
        missing = [mid for mid in sorted(links) if mid not in saved_ids]
        print(f"Schedule: {len(links)} | Saved: {len(saved_ids)} | Missing: {len(missing)}")

        done = 0
        for mid in missing:
            print(f"MATCH {season} {mid}")
            try:
                collector.scrape_one_match(mid, links[mid])
                done += 1
            except Exception as exc:
                print(f"FAILED {season} {mid}: {exc}")

        print(f"SCRAPED {season}: {done}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
