from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml


class Config(dict):
    """Config dict con helpers de acceso."""

    def get_path(self, *keys: str, default: str | None = None) -> Path:
        value: Any = self
        for key in keys:
            value = value.get(key, {})
        if value == {} and default is not None:
            value = default
        if value in (None, {}):
            raise KeyError(f"Ruta no encontrada para keys={keys}")
        return Path(str(value))


def load_config(path: str | Path) -> Config:
    path = Path(path)
    with path.open("r", encoding="utf-8") as f:
        data = yaml.safe_load(f)

    base = path.parent

    def _resolve(value: Any) -> Any:
        if isinstance(value, dict):
            return {k: _resolve(v) for k, v in value.items()}
        if isinstance(value, list):
            return [_resolve(v) for v in value]
        if isinstance(value, str):
            lower = value.lower()
            if lower.startswith(("http://", "https://")):
                return value
            if any(lower.endswith(suffix) for suffix in ("_dir", "/", "\\")):
                return value
        return value

    def _resolve_paths(obj: Any, parent_key: str | None = None) -> Any:
        if isinstance(obj, dict):
            resolved: dict[str, Any] = {}
            for k, v in obj.items():
                rv = _resolve_paths(v, k)
                if isinstance(rv, str) and (k.endswith("_dir") or k.endswith("_root") or k in {"chrome_binary", "path_to_browser"}):
                    p = Path(rv)
                    rv = str(p if p.is_absolute() else (base / p).resolve())
                resolved[k] = rv
            return resolved
        if isinstance(obj, list):
            return [_resolve_paths(v, parent_key) for v in obj]
        return _resolve(obj)

    return Config(_resolve_paths(data))
